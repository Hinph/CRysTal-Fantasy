from __future__ import annotations

import os
import queue
import subprocess
import sys
import threading
import webbrowser
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Optional

from bridge_core import (
    APP_NAME,
    APP_VERSION,
    MEDIA_TYPES,
    CRYSTAL_RECOMMENDED_MEDIA,
    MisterSystemCandidate,
    BatchResult,
    BatchSessionConfig,
    BridgeCore,
    PackageOptions,
    ScrapeOptions,
    SCREENSCRAPER_SIGNUP_URL,
    SystemEntry,
    SystemJob,
    analyze_smart_resume,
    count_game_entries,
    discover_folder_games,
    discover_mister_system_folders,
    detect_esde_executable,
    has_likely_game_content,
    extension_compatible_system,
    find_esde_systems_xml,
    ffmpeg_version_text,
    install_managed_esde,
    install_managed_ffmpeg,
    is_managed_esde,
    is_managed_ffmpeg,
    load_esde_systems,
    managed_esde_executable,
    managed_ffmpeg_executable,
    resolve_ffmpeg,
    uninstall_managed_esde,
    uninstall_managed_ffmpeg,
    scan_source_extensions,
    suggest_system,
)

COLORS = {
    "window": "#0e1624",
    "panel": "#172337",
    "panel2": "#20314a",
    "line": "#355477",
    "text": "#f2f7ff",
    "muted": "#a9bdd5",
    "accent": "#4aa3ff",
    "accent2": "#79c0ff",
    "green": "#79d9a7",
    "yellow": "#f2ca75",
    "red": "#ee8888",
}

MEDIA_LABELS = {
    "screenshots": "Screenshots / backgrounds",
    "titlescreens": "Title screens",
    "covers": "Box covers",
    "backcovers": "Back covers",
    "marquees": "Logos / wheels",
    "3dboxes": "3D boxes",
    "physicalmedia": "Cartridges / discs",
    "fanart": "Fan art",
    "videos": "Video previews",
    "manuals": "PDF manuals",
    "miximages": "Miximages",
}

MEDIA_PRESETS = {
    "CRysTal Recommended": CRYSTAL_RECOMMENDED_MEDIA,
    "Fast / no video": ("screenshots", "covers", "backcovers", "physicalmedia"),
    "Basic art": ("screenshots", "covers"),
    "Everything": MEDIA_TYPES,
}

REGIONS = [("USA", "us"), ("North America", "ame"), ("Europe", "eu"), ("Japan", "jp"), ("World", "wor")]
LANGUAGES = [("English", "en"), ("French", "fr"), ("German", "de"), ("Spanish", "es"), ("Italian", "it"), ("Portuguese", "pt"), ("Japanese", "ja")]

SMART_SCAN_MODES = {
    "Smart Resume — new + incomplete": "new_incomplete",
    "New games only": "new_only",
    "Full scrape — show every game": "all",
}


class CrystalScraperApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title(f"{APP_NAME} — {APP_VERSION}")
        self.root.geometry("880x750")
        self.root.minsize(800, 700)
        self.root.configure(bg=COLORS["window"])

        # Use the same bundled pixel icon for the window/taskbar and the EXE shell icon.
        # PyInstaller exposes added data under sys._MEIPASS in one-file builds.
        resource_root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
        try:
            self._window_icon = tk.PhotoImage(file=str(resource_root / "assets" / "bridge_icon.png"))
            self.root.iconphoto(True, self._window_icon)
        except (tk.TclError, OSError):
            self._window_icon = None

        self.app_root = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
        self.events: queue.Queue[tuple] = queue.Queue()
        self.core = BridgeCore(self.app_root, log=lambda text: self.events.put(("log", text)))
        self.preferences = self.core.load_preferences()
        self.systems: list[SystemEntry] = []
        self.easy_system: Optional[SystemEntry] = None
        self.pro_jobs: list[SystemJob] = []
        self.running = False
        self.esde_busy = False
        self.ffmpeg_busy = False
        self.mister_scan_busy = False
        self.mister_scan_token = 0
        self.analysis_busy = False
        self.analysis_generation = 0
        self.analysis_pending = False
        self.analysis_cache: dict[tuple, dict] = {}
        self.last_result: Optional[BatchResult] = None
        self.current_page = 0
        self.pages: list[tk.Frame] = []
        self.tab_buttons: list[tk.Button] = []

        self.mode_var = tk.StringVar(value=self.preferences.get("mode", "easy"))
        self.esde_var = tk.StringVar(value=self.preferences.get("esde", ""))
        self.ffmpeg_var = tk.StringVar(value=self.preferences.get("ffmpeg", ""))
        self.easy_rom_var = tk.StringVar(value=self.preferences.get("rom", ""))
        self.easy_system_var = tk.StringVar()
        self.easy_hint_var = tk.StringVar(value="Choose a MiSTer SD card or a ROM folder and I will identify the system.")
        self.pro_system_var = tk.StringVar()
        self.mister_root_var = tk.StringVar(value=self.preferences.get("mister_root", ""))
        self.mister_system_var = tk.StringVar()
        self.mister_candidates: list[MisterSystemCandidate] = []
        self.mister_candidate_map: dict[str, MisterSystemCandidate] = {}
        self.mister_scan_status_var = tk.StringVar(value=r"Choose the card/share root. I will list media\fat\games instantly.")
        saved_smart = self.preferences.get("smart_scan_mode", "new_incomplete")
        smart_label = next((label for label, value in SMART_SCAN_MODES.items() if value == saved_smart), "Smart Resume — new + incomplete")
        self.smart_scan_var = tk.StringVar(value=smart_label)
        self.smart_cache: dict[tuple, object] = {}

        self.use_account_var = tk.BooleanVar(value=bool(self.preferences.get("use_account", False)))
        self.username_var = tk.StringVar(value=self.preferences.get("username", ""))
        self.password_var = tk.StringVar(value=self.preferences.get("password", ""))
        self.remember_password_var = tk.BooleanVar(value=bool(self.preferences.get("remember_password", False)))
        saved_region_label = self.preferences.get("region_label", "USA")
        if saved_region_label == "United States":
            saved_region_label = "USA"
        self.region_var = tk.StringVar(value=saved_region_label)
        self.language_var = tk.StringVar(value=self.preferences.get("language_label", "English"))
        self.overwrite_var = tk.BooleanVar(value=bool(self.preferences.get("overwrite", True)))
        self.game_names_var = tk.BooleanVar(value=bool(self.preferences.get("game_names", True)))
        self.ratings_var = tk.BooleanVar(value=bool(self.preferences.get("ratings", True)))
        self.metadata_var = tk.BooleanVar(value=bool(self.preferences.get("metadata", True)))
        saved_media_value = self.preferences.get("media_types")
        saved_media = set(saved_media_value if saved_media_value is not None else MEDIA_PRESETS["CRysTal Recommended"])
        # v0.5.5 migration: users who still have the exact former Recommended
        # selection automatically receive manuals, matching the new frontend default.
        former_recommended = {"screenshots", "covers", "backcovers", "physicalmedia", "videos"}
        if saved_media == former_recommended:
            saved_media.add("manuals")
        self.media_vars = {key: tk.BooleanVar(value=key in saved_media) for key in MEDIA_TYPES}

        self.export_var = tk.StringVar(value=self.preferences.get("export_format", "crystal_fantasy"))
        if self.export_var.get() not in {"crystal_fantasy", "console_mode"}:
            self.export_var.set("crystal_fantasy")
        self.separate_output_var = tk.BooleanVar(value=bool(self.preferences.get("separate_output", False)))
        self.output_root_var = tk.StringVar(value=self.preferences.get("output_root", ""))
        self.optimize_var = tk.BooleanVar(value=bool(self.preferences.get("optimize_images", True)))
        self.gallery_var = tk.BooleanVar(value=bool(self.preferences.get("gallery", True)))

        self.stage_var = tk.StringVar(value="Ready")
        self.progress_var = tk.StringVar(value="")
        self.ready_var = tk.StringVar(value="Choose your games to begin")

        self._configure_styles()
        self._build_shell()
        self._build_games_page()
        self._build_scrape_page()
        self._build_start_page()
        self._show_page(0)
        self._auto_detect_tools()
        self._refresh_mode()
        self._refresh_all()
        self.root.after(80, self._poll_events)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _configure_styles(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TLabel", background=COLORS["window"], foreground=COLORS["text"], font=("Segoe UI", 9))
        style.configure("Muted.TLabel", background=COLORS["window"], foreground=COLORS["muted"], font=("Segoe UI", 9))
        style.configure("Panel.TLabel", background=COLORS["panel"], foreground=COLORS["text"], font=("Segoe UI", 9))
        style.configure("PanelMuted.TLabel", background=COLORS["panel"], foreground=COLORS["muted"], font=("Segoe UI", 8))
        style.configure("Section.TLabel", background=COLORS["window"], foreground=COLORS["text"], font=("Segoe UI Semibold", 14))
        style.configure("CardTitle.TLabel", background=COLORS["panel"], foreground=COLORS["accent"], font=("Segoe UI Semibold", 10))
        style.configure("TEntry", fieldbackground=COLORS["panel2"], foreground=COLORS["text"], insertcolor=COLORS["text"], padding=5)
        style.configure("TCombobox", fieldbackground=COLORS["panel2"], foreground=COLORS["text"], padding=5)
        style.map("TCombobox", fieldbackground=[("readonly", COLORS["panel2"])], foreground=[("readonly", COLORS["text"])])
        style.configure("Treeview", background=COLORS["panel2"], fieldbackground=COLORS["panel2"], foreground=COLORS["text"], rowheight=25, borderwidth=0)
        style.configure("Treeview.Heading", background=COLORS["panel"], foreground=COLORS["muted"], relief="flat", font=("Segoe UI Semibold", 8))
        style.map("Treeview", background=[("selected", COLORS["accent2"])], foreground=[("selected", "#11131c")])
        style.configure("TCheckbutton", background=COLORS["panel"], foreground=COLORS["text"], font=("Segoe UI", 9))
        style.map("TCheckbutton", background=[("active", COLORS["panel"])], foreground=[("active", COLORS["text"])])
        style.configure("Accent.Horizontal.TProgressbar", troughcolor=COLORS["panel2"], background=COLORS["accent"], bordercolor=COLORS["panel2"])

    def _button(self, parent, text, command, *, primary=False, width=None):
        return tk.Button(
            parent, text=text, command=command, cursor="hand2", bd=0,
            bg=COLORS["accent"] if primary else COLORS["panel2"],
            fg="#071827" if primary else COLORS["text"],
            activebackground="#78bdff" if primary else COLORS["line"],
            activeforeground="#071827" if primary else COLORS["text"],
            font=("Segoe UI Semibold", 9), padx=12, pady=6, width=width,
        )

    def _build_shell(self) -> None:
        header = tk.Frame(self.root, bg=COLORS["window"])
        header.pack(fill="x", padx=16, pady=(12, 7))
        title = tk.Frame(header, bg=COLORS["window"])
        title.pack(side="left")
        tk.Label(title, text="CRysTal FANTASY SCRAPER", bg=COLORS["window"], fg=COLORS["accent"], font=("Segoe UI Semibold", 16)).pack(anchor="w")
        tk.Label(title, text="ES-DE scraping without the setup nonsense", bg=COLORS["window"], fg=COLORS["muted"], font=("Segoe UI", 9)).pack(anchor="w")
        mode = tk.Frame(header, bg=COLORS["window"])
        mode.pack(side="right")
        tk.Label(mode, text="MODE", bg=COLORS["window"], fg=COLORS["muted"], font=("Segoe UI Semibold", 8)).pack(anchor="e")
        row = tk.Frame(mode, bg=COLORS["window"])
        row.pack()
        self.easy_mode_button = self._button(row, "Easy — one system", lambda: self._set_mode("easy"))
        self.easy_mode_button.pack(side="left", padx=(0, 4))
        self.pro_mode_button = self._button(row, "Pro — many systems", lambda: self._set_mode("pro"))
        self.pro_mode_button.pack(side="left")

        tabs = tk.Frame(self.root, bg=COLORS["window"])
        tabs.pack(fill="x", padx=16, pady=(0, 7))
        for i, label in enumerate(("1  Games", "2  Media & Account", "3  Start")):
            button = tk.Button(tabs, text=label, command=lambda n=i: self._show_page(n), cursor="hand2", bd=0, font=("Segoe UI Semibold", 9), padx=17, pady=7)
            button.pack(side="left", padx=(0, 5))
            self.tab_buttons.append(button)
        self._button(tabs, "Clear leftover cache", self._reset_profile).pack(side="right")

        self.page_host = tk.Frame(self.root, bg=COLORS["window"])
        self.page_host.pack(fill="both", expand=True, padx=16)
        for _ in range(3):
            frame = tk.Frame(self.page_host, bg=COLORS["window"])
            self.pages.append(frame)

        footer = tk.Frame(self.root, bg=COLORS["panel"], highlightthickness=1, highlightbackground=COLORS["line"])
        footer.pack(fill="x", padx=16, pady=(7, 12))
        ttk.Label(footer, textvariable=self.stage_var, style="Panel.TLabel").pack(side="left", padx=9, pady=6)
        ttk.Label(footer, textvariable=self.progress_var, style="PanelMuted.TLabel").pack(side="left", padx=8, pady=6)
        self.footer_scan_progressbar = ttk.Progressbar(footer, style="Accent.Horizontal.TProgressbar", maximum=100, length=150)
        self.footer_scan_progressbar.pack(side="left", padx=(4, 8), pady=6)
        tk.Label(footer, text="ROMs are never renamed, converted or deleted", bg=COLORS["panel"], fg=COLORS["green"], font=("Segoe UI Semibold", 8)).pack(side="right", padx=9)

    def _card(self, parent, title: str):
        outer = tk.Frame(parent, bg=COLORS["panel"], highlightthickness=1, highlightbackground=COLORS["line"])
        ttk.Label(outer, text=title, style="CardTitle.TLabel").pack(anchor="w", padx=11, pady=(9, 6))
        body = tk.Frame(outer, bg=COLORS["panel"])
        body.pack(fill="both", expand=True, padx=11, pady=(0, 9))
        return outer, body

    def _path_row(self, parent, label, variable, browse, detect=None):
        ttk.Label(parent, text=label, style="Panel.TLabel").pack(anchor="w", pady=(4, 2))
        row = tk.Frame(parent, bg=COLORS["panel"])
        row.pack(fill="x")
        ttk.Entry(row, textvariable=variable).pack(side="left", fill="x", expand=True)
        self._button(row, "Browse", browse).pack(side="left", padx=(5, 0))
        if detect:
            self._button(row, "Detect", detect).pack(side="left", padx=(4, 0))

    def _build_games_page(self) -> None:
        page = self.pages[0]
        ttk.Label(page, text="Choose your games", style="Section.TLabel").pack(anchor="w")
        self.games_subtitle = ttk.Label(page, text="Easy Mode walks through one system. Pro Mode lets ES-DE scrape a selected group in one run.", style="Muted.TLabel")
        self.games_subtitle.pack(anchor="w", pady=(1, 7))

        tools_card, tools = self._card(page, "Tools — install once, then forget about them")
        tools_card.pack(fill="x")
        esde_row = tk.Frame(tools, bg=COLORS["panel"]); esde_row.pack(fill="x", pady=(0, 4))
        tk.Label(esde_row, text="ES-DE", width=9, anchor="w", bg=COLORS["panel"], fg=COLORS["text"], font=("Segoe UI Semibold", 9)).pack(side="left")
        self.esde_status = tk.Label(esde_row, text="", bg=COLORS["panel"], fg=COLORS["muted"], font=("Segoe UI", 8)); self.esde_status.pack(side="left", fill="x", expand=True)
        self.esde_install_button = self._button(esde_row, "Install ES-DE", self._install_esde); self.esde_install_button.pack(side="left")
        self._button(esde_row, "Browse", self._browse_esde).pack(side="left", padx=(4, 0))
        self._button(esde_row, "Detect", self._detect_esde).pack(side="left", padx=(4, 0))
        self.esde_remove_button = self._button(esde_row, "Uninstall", self._uninstall_esde); self.esde_remove_button.pack(side="left", padx=(4, 0))
        ffmpeg_row = tk.Frame(tools, bg=COLORS["panel"]); ffmpeg_row.pack(fill="x")
        tk.Label(ffmpeg_row, text="FFmpeg", width=9, anchor="w", bg=COLORS["panel"], fg=COLORS["text"], font=("Segoe UI Semibold", 9)).pack(side="left")
        self.ffmpeg_status = tk.Label(ffmpeg_row, text="", bg=COLORS["panel"], fg=COLORS["muted"], font=("Segoe UI", 8)); self.ffmpeg_status.pack(side="left", fill="x", expand=True)
        self.ffmpeg_install_button = self._button(ffmpeg_row, "Install FFmpeg", self._install_ffmpeg); self.ffmpeg_install_button.pack(side="left")
        self._button(ffmpeg_row, "Browse", self._browse_ffmpeg).pack(side="left", padx=(4, 0))
        self._button(ffmpeg_row, "Detect", self._detect_ffmpeg).pack(side="left", padx=(4, 0))
        self.ffmpeg_remove_button = self._button(ffmpeg_row, "Uninstall", self._uninstall_ffmpeg); self.ffmpeg_remove_button.pack(side="left", padx=(4, 0))

        scan_row = tk.Frame(page, bg=COLORS["window"]); scan_row.pack(fill="x", pady=(0, 2))
        ttk.Label(scan_row, text="What should ES-DE see?", style="Muted.TLabel").pack(side="left")
        self.smart_scan_combo = ttk.Combobox(scan_row, textvariable=self.smart_scan_var, values=list(SMART_SCAN_MODES), state="readonly", width=34)
        self.smart_scan_combo.pack(side="left", padx=(7, 5))
        self.smart_scan_combo.bind("<<ComboboxSelected>>", lambda _event: self._refresh_smart_scan())
        self._button(scan_row, "Refresh scan", self._refresh_smart_scan).pack(side="left")

        self.easy_card, easy = self._card(page, "Easy Mode — one system")
        self.easy_card.pack(fill="both", expand=True, pady=(8, 0))
        sd = tk.Frame(easy, bg=COLORS["panel2"], highlightthickness=1, highlightbackground=COLORS["line"]); sd.pack(fill="x", pady=(0, 7))
        tk.Label(sd, text="MISTER SD CARD — EASIEST", bg=COLORS["panel2"], fg=COLORS["accent2"], font=("Segoe UI Semibold", 8)).pack(anchor="w", padx=8, pady=(6, 1))
        sdrow = tk.Frame(sd, bg=COLORS["panel2"]); sdrow.pack(fill="x", padx=8, pady=(2, 5))
        ttk.Entry(sdrow, textvariable=self.mister_root_var).pack(side="left", fill="x", expand=True)
        self.easy_sd_scan_button = self._button(sdrow, "Select / Scan SD card", self._browse_mister_root, primary=True)
        self.easy_sd_scan_button.pack(side="left", padx=(5, 0))
        self.mister_system_combo = ttk.Combobox(sd, textvariable=self.mister_system_var, state="readonly")
        self.mister_system_combo.pack(fill="x", padx=8, pady=(0, 5))
        self.mister_system_combo.bind("<<ComboboxSelected>>", self._on_mister_system)
        scanstatus = tk.Frame(sd, bg=COLORS["panel2"]); scanstatus.pack(fill="x", padx=8, pady=(0, 7))
        self.mister_scan_progressbar = ttk.Progressbar(scanstatus, style="Accent.Horizontal.TProgressbar", maximum=100)
        self.mister_scan_progressbar.pack(side="left", fill="x", expand=True)
        tk.Label(
            scanstatus, textvariable=self.mister_scan_status_var, bg=COLORS["panel2"],
            fg=COLORS["muted"], font=("Segoe UI", 8), width=39, anchor="w",
        ).pack(side="left", padx=(8, 0))
        ttk.Label(easy, text="Or choose one ROM system folder manually", style="PanelMuted.TLabel").pack(anchor="w")
        self._path_row(easy, "ROM system folder", self.easy_rom_var, self._browse_easy_rom)
        sysrow = tk.Frame(easy, bg=COLORS["panel"]); sysrow.pack(fill="x", pady=(7, 2))
        ttk.Label(sysrow, text="System to scrape", style="Panel.TLabel").pack(side="left")
        self._button(sysrow, "Wrong guess? Choose manually", self._choose_easy_system_manually).pack(side="right")
        self._button(sysrow, "Guess from files", self._auto_match_easy).pack(side="right", padx=(0, 5))
        self.easy_system_combo = ttk.Combobox(easy, textvariable=self.easy_system_var, state="normal")
        self.easy_system_combo.pack(fill="x")
        self.easy_system_combo.bind("<<ComboboxSelected>>", self._on_easy_system)
        self.easy_system_combo.bind("<Return>", self._on_easy_system)
        ttk.Label(easy, textvariable=self.easy_hint_var, style="PanelMuted.TLabel", wraplength=790, justify="left").pack(anchor="w", pady=(5, 0))

        self.pro_card, pro = self._card(page, "Pro Mode — selected systems only")
        controls = tk.Frame(pro, bg=COLORS["panel"]); controls.pack(fill="x", pady=(0, 6))
        self.pro_sd_scan_button = self._button(controls, "Scan MiSTer SD card", self._pro_scan_mister, primary=True)
        self.pro_sd_scan_button.pack(side="left")
        self._button(controls, "Add system folder", self._pro_add_folder).pack(side="left", padx=(5, 0))
        self._button(controls, "Scan a ROM root", self._pro_add_root).pack(side="left", padx=(5, 0))
        self._button(controls, "Remove selected", self._pro_remove).pack(side="left", padx=(5, 0))
        self._button(controls, "Clear", self._pro_clear).pack(side="right")
        self.pro_tree = ttk.Treeview(pro, columns=("system", "games", "needed", "folder"), show="headings", height=7)
        self.pro_tree.heading("system", text="Detected system"); self.pro_tree.heading("games", text="Games"); self.pro_tree.heading("needed", text="To scrape"); self.pro_tree.heading("folder", text="ROM folder")
        self.pro_tree.column("system", width=165, anchor="w"); self.pro_tree.column("games", width=55, anchor="center"); self.pro_tree.column("needed", width=65, anchor="center"); self.pro_tree.column("folder", width=430, anchor="w")
        self.pro_tree.pack(fill="both", expand=True)
        override = tk.Frame(pro, bg=COLORS["panel"]); override.pack(fill="x", pady=(6, 0))
        ttk.Label(override, text="Wrong guess?", style="PanelMuted.TLabel").pack(side="left")
        self.pro_system_combo = ttk.Combobox(override, textvariable=self.pro_system_var, state="normal", width=42)
        self.pro_system_combo.pack(side="left", padx=(6, 4))
        self._button(override, "Apply to selected", self._pro_apply_system).pack(side="left")
        ttk.Label(pro, text="Private ES-DE contains only this list, so choosing all visible systems in the ES-DE scraper is safe.", style="PanelMuted.TLabel", wraplength=760, justify="left").pack(anchor="w", pady=(5, 0))

    def _build_scrape_page(self) -> None:
        page = self.pages[1]
        ttk.Label(page, text="Choose what to scrape", style="Section.TLabel").pack(anchor="w")
        ttk.Label(page, text="These choices are written into the private ES-DE profile before it opens.", style="Muted.TLabel").pack(anchor="w", pady=(1, 7))
        grid = tk.Frame(page, bg=COLORS["window"]); grid.pack(fill="both", expand=True)
        account_card, account = self._card(grid, "ScreenScraper account")
        account_card.pack(side="left", fill="both", expand=True, padx=(0, 5))
        media_card, media = self._card(grid, "Media")
        media_card.pack(side="left", fill="both", expand=True, padx=(5, 0))

        signup = tk.Frame(account, bg=COLORS["panel2"], highlightthickness=1, highlightbackground=COLORS["line"])
        signup.pack(fill="x", pady=(0, 8))
        tk.Label(signup, text="NO ACCOUNT YET?", bg=COLORS["panel2"], fg=COLORS["accent2"], font=("Segoe UI Semibold", 8)).pack(anchor="w", padx=8, pady=(6, 0))
        self._button(signup, "Create free ScreenScraper account", self._open_screenscraper_signup).pack(anchor="w", padx=8, pady=(4, 7))
        ttk.Checkbutton(account, text="Use my ScreenScraper account", variable=self.use_account_var, command=self._toggle_account).pack(anchor="w", pady=(1, 6))
        ttk.Label(account, text="Username", style="Panel.TLabel").pack(anchor="w")
        self.username_entry = ttk.Entry(account, textvariable=self.username_var); self.username_entry.pack(fill="x", pady=(2, 6))
        ttk.Label(account, text="Password", style="Panel.TLabel").pack(anchor="w")
        self.password_entry = ttk.Entry(account, textvariable=self.password_var, show="•"); self.password_entry.pack(fill="x", pady=(2, 6))
        ttk.Checkbutton(account, text="Remember on this PC", variable=self.remember_password_var).pack(anchor="w")
        ttk.Label(account, text="If Remember is off, the clear-text password ES-DE needs is scrubbed when ES-DE closes.", style="PanelMuted.TLabel", wraplength=350, justify="left").pack(anchor="w", pady=(4, 10))
        row = tk.Frame(account, bg=COLORS["panel"]); row.pack(fill="x")
        ttk.Label(row, text="Region", style="Panel.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(row, text="Language", style="Panel.TLabel").grid(row=0, column=1, sticky="w", padx=(7, 0))
        ttk.Combobox(row, textvariable=self.region_var, values=[x[0] for x in REGIONS], state="readonly").grid(row=1, column=0, sticky="ew", pady=(2, 0))
        ttk.Combobox(row, textvariable=self.language_var, values=[x[0] for x in LANGUAGES], state="readonly").grid(row=1, column=1, sticky="ew", padx=(7, 0), pady=(2, 0))
        row.columnconfigure(0, weight=1); row.columnconfigure(1, weight=1)
        ttk.Label(account, text="Region is locked into private ES-DE and checked again after startup.", style="PanelMuted.TLabel", wraplength=350, justify="left").pack(anchor="w", pady=(5, 0))
        ttk.Checkbutton(account, text="Overwrite corrected media and metadata", variable=self.overwrite_var).pack(anchor="w", pady=(10, 0))
        ttk.Checkbutton(account, text="Clean names", variable=self.game_names_var).pack(anchor="w", pady=(9, 0))
        ttk.Checkbutton(account, text="Ratings", variable=self.ratings_var).pack(anchor="w")
        ttk.Checkbutton(account, text="Descriptions, year, genre, players, developer and publisher", variable=self.metadata_var).pack(anchor="w")
        self._toggle_account()

        presets = tk.Frame(media, bg=COLORS["panel"]); presets.pack(fill="x", pady=(0, 8))
        for index, name in enumerate(MEDIA_PRESETS):
            self._button(presets, name, lambda n=name: self._set_media_preset(n)).grid(row=index // 2, column=index % 2, sticky="ew", padx=(0 if index % 2 == 0 else 3, 3 if index % 2 == 0 else 0), pady=2)
        presets.columnconfigure(0, weight=1); presets.columnconfigure(1, weight=1)
        media_grid = tk.Frame(media, bg=COLORS["panel"]); media_grid.pack(fill="both", expand=True)
        for i, key in enumerate(MEDIA_TYPES):
            ttk.Checkbutton(media_grid, text=MEDIA_LABELS[key], variable=self.media_vars[key]).grid(row=i // 2, column=i % 2, sticky="w", padx=(0, 10), pady=4)
        media_grid.columnconfigure(0, weight=1); media_grid.columnconfigure(1, weight=1)
        callout = tk.Frame(media, bg=COLORS["panel2"], highlightthickness=1, highlightbackground=COLORS["line"])
        callout.pack(fill="x", pady=(8, 0))
        tk.Label(callout, text="EVERY EXPORTED IMAGE IS COMPRESSED PNG8", bg=COLORS["panel2"], fg=COLORS["green"], font=("Segoe UI Semibold", 9)).pack(anchor="w", padx=8, pady=(7, 1))
        ttk.Label(callout, text="Artwork is capped at 340 px high and palette-compressed toward ~64 KB. Rescraped replacements overwrite only their matching bridge output.", style="PanelMuted.TLabel", wraplength=360, justify="left").pack(anchor="w", padx=8, pady=(0, 7))

    def _build_start_page(self) -> None:
        page = self.pages[2]
        ttk.Label(page, text="Start scraping", style="Section.TLabel").pack(anchor="w")
        ttk.Label(page, text="The bridge converts stable files while ES-DE runs, performs a final verified sync, then deletes ES-DE's temporary originals.", style="Muted.TLabel").pack(anchor="w", pady=(1, 7))
        formats = tk.Frame(page, bg=COLORS["window"]); formats.pack(fill="x")
        crystal_card, crystal = self._card(formats, "CRysTal Fantasy — recommended")
        crystal_card.pack(side="left", fill="both", expand=True, padx=(0, 5))
        console_card, console = self._card(formats, "Default Console Mode")
        console_card.pack(side="left", fill="both", expand=True, padx=(5, 0))
        tk.Radiobutton(crystal, text="Use CRysTal Fantasy format", variable=self.export_var, value="crystal_fantasy", command=self._refresh_smart_scan, bg=COLORS["panel"], fg=COLORS["text"], selectcolor=COLORS["panel2"], activebackground=COLORS["panel"], activeforeground=COLORS["text"], font=("Segoe UI Semibold", 9)).pack(anchor="w")
        ttk.Label(crystal, text="Creates cover PNGs and gamelist.xml directly in media, with BG, PM and other selected subfolders. Artwork is compressed PNG8.", style="PanelMuted.TLabel", wraplength=350, justify="left").pack(anchor="w", pady=(4, 5))
        ttk.Checkbutton(crystal, text="Compress artwork to PNG8 (~64 KB target)", variable=self.optimize_var).pack(anchor="w")
        ttk.Checkbutton(crystal, text="Keep selected gallery folders", variable=self.gallery_var).pack(anchor="w")
        tk.Radiobutton(console, text="Use Default Console Mode", variable=self.export_var, value="console_mode", command=self._refresh_smart_scan, bg=COLORS["panel"], fg=COLORS["text"], selectcolor=COLORS["panel2"], activebackground=COLORS["panel"], activeforeground=COLORS["text"], font=("Segoe UI Semibold", 9)).pack(anchor="w")
        ttk.Label(console, text="Creates one media folder. Box art becomes <ROM>.png and screenshots become <ROM>-BG.png. Other selected media is ignored.", style="PanelMuted.TLabel", wraplength=350, justify="left").pack(anchor="w", pady=(4, 5))

        dest_card, dest = self._card(page, "Where should finished media go?")
        dest_card.pack(fill="x", pady=(8, 0))
        ttk.Checkbutton(dest, text="Use a separate output root instead of writing beside each ROM folder", variable=self.separate_output_var, command=self._refresh_output_state).pack(anchor="w")
        self.output_row = tk.Frame(dest, bg=COLORS["panel"]); self.output_row.pack(fill="x", pady=(5, 0))
        self.output_entry = ttk.Entry(self.output_row, textvariable=self.output_root_var); self.output_entry.pack(side="left", fill="x", expand=True)
        self.output_button = self._button(self.output_row, "Browse", self._browse_output); self.output_button.pack(side="left", padx=(5, 0))
        self.output_help = ttk.Label(dest, text="Recommended: leave this off. Easy Mode writes directly into that system's ROM folder; Pro Mode writes into each selected system folder.", style="PanelMuted.TLabel", wraplength=780, justify="left")
        self.output_help.pack(anchor="w", pady=(4, 0))

        run_card, run = self._card(page, "Ready check")
        run_card.pack(fill="both", expand=True, pady=(8, 0))
        top = tk.Frame(run, bg=COLORS["panel"]); top.pack(fill="x")
        self.ready_label = tk.Label(top, textvariable=self.ready_var, bg=COLORS["panel"], fg=COLORS["yellow"], font=("Segoe UI Semibold", 9)); self.ready_label.pack(side="left")
        self.open_output_button = self._button(top, "Open destination", self._open_last_output); self.open_output_button.pack(side="right"); self.open_output_button.configure(state="disabled")
        self.progressbar = ttk.Progressbar(run, style="Accent.Horizontal.TProgressbar", maximum=100); self.progressbar.pack(fill="x", pady=(7, 6))
        buttons = tk.Frame(run, bg=COLORS["panel"]); buttons.pack(fill="x")
        self.run_button = self._button(buttons, "Open ES-DE & Start Live Sync", self._confirm_and_run, primary=True); self.run_button.pack(side="left")
        self._button(buttons, "Clear details", self._clear_log).pack(side="right")
        self.log_box = tk.Text(run, height=8, bg=COLORS["panel2"], fg=COLORS["text"], insertbackground=COLORS["text"], relief="flat", wrap="word", font=("Consolas", 8), padx=8, pady=6)
        self.log_box.pack(fill="both", expand=True, pady=(7, 0)); self.log_box.configure(state="disabled")
        self._refresh_output_state()

    def _set_mode(self, mode: str) -> None:
        if self.running:
            return
        self.mode_var.set(mode)
        self._invalidate_analysis()
        self._refresh_mode()
        self._refresh_pro_tree()
        self._refresh_all()

    def _refresh_mode(self) -> None:
        easy = self.mode_var.get() == "easy"
        self.easy_mode_button.configure(bg=COLORS["accent"] if easy else COLORS["panel2"], fg="#071827" if easy else COLORS["text"])
        self.pro_mode_button.configure(bg=COLORS["accent"] if not easy else COLORS["panel2"], fg="#071827" if not easy else COLORS["text"])
        self.easy_card.pack_forget(); self.pro_card.pack_forget()
        if easy:
            self.easy_card.pack(fill="both", expand=True, pady=(8, 0))
        else:
            self.pro_card.pack(fill="both", expand=True, pady=(8, 0))

    def _show_page(self, index: int) -> None:
        if self.running and index != 2:
            return
        for page in self.pages:
            page.pack_forget()
        self.pages[index].pack(fill="both", expand=True)
        self.current_page = index
        for i, button in enumerate(self.tab_buttons):
            active = i == index
            button.configure(bg=COLORS["accent"] if active else COLORS["panel"], fg="#071827" if active else COLORS["text"], activebackground=COLORS["accent"] if active else COLORS["panel2"])
        self._refresh_all()
        # Pro Mode intentionally avoids ROM analysis while the user is merely
        # browsing SD-card folders. Start it only once they move beyond Library.
        if index > 0 and self._smart_mode() != "all":
            self._request_library_analysis()

    def _browse_esde(self) -> None:
        value = filedialog.askopenfilename(title="Select ES-DE.exe", filetypes=[("ES-DE", "*.exe"), ("All files", "*.*")])
        if value:
            self.esde_var.set(value); self._load_systems(); self._refresh_all()

    def _browse_ffmpeg(self) -> None:
        value = filedialog.askopenfilename(title="Select ffmpeg.exe", filetypes=[("ffmpeg", "ffmpeg.exe"), ("Executables", "*.exe"), ("All files", "*.*")])
        if value:
            self.ffmpeg_var.set(value); self._refresh_all()

    def _browse_easy_rom(self) -> None:
        value = filedialog.askdirectory(title="Select one system ROM folder", mustexist=True)
        if value:
            self.mister_system_var.set("")
            self.easy_rom_var.set(value); self._invalidate_analysis(); self._auto_match_easy(); self._refresh_all()

    def _browse_mister_root(self) -> None:
        value = filedialog.askdirectory(
            title="Select the root of your MiSTer SD card", mustexist=True,
            initialdir=self.mister_root_var.get().strip() or None,
        )
        if value:
            self._start_mister_scan(Path(value), select_first=False, add_to_pro=False)

    def _start_mister_scan(self, root: Path, *, select_first: bool, add_to_pro: bool) -> None:
        if self.mister_scan_busy or self.running:
            return
        if not root.is_dir():
            messagebox.showinfo("Select MiSTer SD card", r"Choose the card/share root that contains media\fat\games, or choose the games folder itself.")
            return
        self.mister_root_var.set(str(root))
        self.mister_scan_busy = True
        self.mister_scan_token += 1
        token = self.mister_scan_token
        self.mister_scan_progressbar.stop(); self.footer_scan_progressbar.stop()
        self.mister_scan_progressbar.configure(mode="indeterminate", value=0)
        self.footer_scan_progressbar.configure(mode="indeterminate", value=0)
        self.mister_scan_progressbar.start(12); self.footer_scan_progressbar.start(12)
        self.mister_scan_status_var.set(r"Reading media\fat\games folder names…")
        self.stage_var.set("Reading SD card folders")
        self.progress_var.set("No ROM files are being scanned")
        self._refresh_all()
        systems = tuple(self.systems)

        def worker() -> None:
            try:
                # Listing media\fat\games is one shallow directory read. Do
                # not flood the Tk event queue with one event per folder.
                candidates = discover_mister_system_folders(root, systems)
                self.events.put(("mister_scan_complete", token, str(root), candidates, select_first, add_to_pro))
            except Exception as exc:
                self.events.put(("mister_scan_error", token, str(exc)))
        threading.Thread(target=worker, daemon=True, name="CRysTal-MiSTer-Scanner").start()

    def _apply_mister_scan(self, root: Path, candidates: list[MisterSystemCandidate], *, select_first: bool, add_to_pro: bool) -> None:
        self.mister_candidates = candidates
        self.mister_candidate_map = {}
        labels: list[str] = []
        for candidate in candidates:
            try:
                relative = candidate.folder.relative_to(root).as_posix()
            except ValueError:
                relative = candidate.folder.name
            if candidate.system is not None:
                source_name = candidate.known_platform or candidate.label
                guess = f"{source_name} → {candidate.system.full_name}"
            elif not candidate.scrapeable:
                guess = f"not scrapeable: {candidate.known_platform or candidate.label}"
            elif candidate.known_platform:
                guess = f"known: {candidate.known_platform}; ES-DE match unavailable"
            else:
                guess = "unknown; choose manually"
            label = f"{candidate.label}  ({guess})  [{relative}]"
            labels.append(label)
            self.mister_candidate_map[label] = candidate
        self.mister_system_combo.configure(values=labels)
        current = self.mister_system_var.get()
        if select_first and labels:
            current = labels[0]
        if current in self.mister_candidate_map:
            self.mister_system_var.set(current)
            candidate = self.mister_candidate_map[current]
            self.easy_rom_var.set(str(candidate.folder))
            self.easy_system = candidate.system
            self.easy_system_var.set(candidate.system.display_name if candidate.system else "")
        elif not add_to_pro:
            # Listing the card must be instant. Do not choose a system or inspect
            # any ROMs until the user explicitly picks from the dropdown.
            self.mister_system_var.set("")
            self.easy_rom_var.set("")
            self.easy_system = None
            self.easy_system_var.set("")
        if add_to_pro:
            added = 0
            unassigned = 0
            unsupported = 0
            for candidate in candidates:
                if any(os.path.normcase(str(job.rom_folder.resolve())) == os.path.normcase(str(candidate.folder.resolve())) for job in self.pro_jobs):
                    continue
                if not candidate.scrapeable:
                    unsupported += 1
                    continue
                if candidate.system is None:
                    unassigned += 1
                    continue
                self.pro_jobs.append(SystemJob(candidate.folder, candidate.system, None))
                added += 1
            self._append_log(
                f"Pro Mode added {added} mapped MiSTer system folder(s)."
                + (f" {unassigned} folder(s) still need a manual ES-DE system." if unassigned else "")
                + (f" {unsupported} known support/utility folder(s) were skipped." if unsupported else "")
            )
        self._invalidate_analysis()
        self._refresh_pro_tree()
        self._refresh_all()

    def _on_mister_system(self, _event=None) -> None:
        candidate = self.mister_candidate_map.get(self.mister_system_var.get())
        if not candidate:
            return
        self.easy_rom_var.set(str(candidate.folder))
        self.easy_system = candidate.system
        self.easy_system_var.set(candidate.system.display_name if candidate.system else "")
        self._invalidate_analysis()
        if candidate.system is None:
            if not candidate.scrapeable:
                self.easy_hint_var.set(
                    f"{candidate.folder.name} is recognized as {candidate.known_platform or 'support data'}, but it is not a scrapeable game library. {candidate.support_note}"
                )
            elif candidate.known_platform:
                self.easy_hint_var.set(
                    f"Recognized {candidate.folder.name} as {candidate.known_platform}, but the matching ES-DE system is unavailable. Update ES-DE or choose a system manually."
                )
            else:
                self.easy_hint_var.set(
                    f"Selected {candidate.folder.name}. This folder is not in the MiSTer registry yet; choose its ES-DE system manually below."
                )
        elif candidate.known_platform:
            self.easy_hint_var.set(
                f"MiSTer mapping: {candidate.folder.name} → {candidate.known_platform} → {candidate.system.full_name}. Use Wrong guess if needed."
            )
        self._refresh_all()

    def _choose_easy_system_manually(self) -> None:
        """Make correction of a bad folder-name guess explicit and immediate."""
        self.easy_system = None
        self.easy_system_var.set("")
        self._invalidate_analysis()
        self.easy_hint_var.set("Choose the correct ES-DE system from the list below. No ROM scan starts until you choose one.")
        self.easy_system_combo.focus_set()
        try:
            self.easy_system_combo.tk.call("ttk::combobox::Post", str(self.easy_system_combo))
        except tk.TclError:
            pass
        self._refresh_all()

    def _pro_scan_mister(self) -> None:
        value = filedialog.askdirectory(
            title="Select the root of your MiSTer SD card", mustexist=True,
            initialdir=self.mister_root_var.get().strip() or None,
        )
        if value:
            self._start_mister_scan(Path(value), select_first=False, add_to_pro=True)

    def _browse_output(self) -> None:
        value = filedialog.askdirectory(title="Select output root", mustexist=False)
        if value:
            self.output_root_var.set(value); self._refresh_all()

    def _detect_esde(self) -> None:
        preferred = Path(self.esde_var.get()) if self.esde_var.get().strip() else None
        found = detect_esde_executable(self.app_root, preferred)
        if found:
            self.esde_var.set(str(found)); self._load_systems(); self._refresh_all()
        else:
            messagebox.showinfo("ES-DE not found", "Browse to ES-DE.exe from a complete installed or portable copy.")

    def _detect_ffmpeg(self) -> None:
        preferred = Path(self.ffmpeg_var.get()) if self.ffmpeg_var.get().strip() else None
        found = resolve_ffmpeg(preferred, self.app_root)
        if found:
            self.ffmpeg_var.set(str(found)); self._refresh_all()
        else:
            messagebox.showinfo("FFmpeg not found", "Place ffmpeg.exe beside the app or browse to it. It is required to guarantee PNG output.")

    def _install_esde(self) -> None:
        if self.running or self.esde_busy:
            return
        if os.name != "nt":
            messagebox.showinfo("Windows installer", "The built-in ES-DE installer is available in the finalized Windows 10/11 app.")
            return
        managed = managed_esde_executable(self.app_root).is_file()
        verb = "Update / repair" if managed else "Install"
        if not messagebox.askokcancel(
            f"{verb} ES-DE",
            f"{verb} the latest official Windows portable ES-DE release inside CRysTal Scraper's private tools folder?\n\n"
            "The ES-DE program stays installed for future runs. Its downloaded media, gamelist cache and temporary profile are still erased after each successful conversion.",
        ):
            return
        self.esde_busy = True
        self.esde_status.configure(text="Checking official ES-DE release…", fg=COLORS["yellow"])
        self._refresh_all()

        def worker() -> None:
            try:
                progress = lambda current, total, name: self.events.put(("esde_progress", current, total, name))
                installed = install_managed_esde(
                    self.app_root,
                    log=lambda text: self.events.put(("log", text)),
                    progress=progress,
                )
                self.events.put(("esde_complete", installed))
            except Exception as exc:
                self.events.put(("esde_error", str(exc)))
        threading.Thread(target=worker, daemon=True, name="CRysTal-ESDE-Installer").start()

    def _uninstall_esde(self) -> None:
        if self.running or self.esde_busy:
            return
        managed = managed_esde_executable(self.app_root)
        if not managed.is_file():
            messagebox.showinfo("No managed ES-DE", "CRysTal Scraper has no private ES-DE program to remove. External ES-DE installations are never touched.")
            return
        if not messagebox.askyesno(
            "Uninstall managed ES-DE",
            "Remove only the portable ES-DE copy installed by CRysTal Scraper?\n\nFinished media, ROMs, FFmpeg and external ES-DE copies will not be changed.",
        ):
            return
        try:
            current = Path(self.esde_var.get().strip()) if self.esde_var.get().strip() else None
            uninstall_managed_esde(self.app_root, log=self._append_log)
            if is_managed_esde(current, self.app_root):
                self.esde_var.set("")
            fallback = detect_esde_executable(self.app_root)
            if fallback:
                self.esde_var.set(str(fallback))
            self.systems = []
            if self.esde_var.get().strip():
                self._load_systems(silent=True)
            self._save_preferences()
            self._refresh_all()
            messagebox.showinfo("ES-DE removed", "The CRysTal-managed ES-DE program was removed. No external installation was changed.")
        except Exception as exc:
            messagebox.showerror("Could not uninstall ES-DE", str(exc))

    def _open_screenscraper_signup(self) -> None:
        try:
            if not webbrowser.open(SCREENSCRAPER_SIGNUP_URL, new=2):
                raise RuntimeError("Windows could not open the default browser.")
        except Exception as exc:
            messagebox.showerror("Could not open ScreenScraper", f"Open this address in a browser:\n\n{SCREENSCRAPER_SIGNUP_URL}\n\n{exc}")

    def _install_ffmpeg(self) -> None:
        if self.running or self.ffmpeg_busy:
            return
        if os.name != "nt":
            messagebox.showinfo("Windows installer", "The built-in FFmpeg installer downloads the Windows Essentials build and is available on Windows 10 or newer.")
            return
        managed = managed_ffmpeg_executable(self.app_root).is_file()
        verb = "Update / repair" if managed else "Install"
        if not messagebox.askokcancel(
            f"{verb} FFmpeg",
            f"{verb} the FFmpeg Essentials build inside CRysTal Scraper's private data folder?\n\n"
            "The app will verify the publisher's SHA-256 checksum. Windows PATH and other FFmpeg installations will not be changed.",
        ):
            return
        self.ffmpeg_busy = True
        self.ffmpeg_status.configure(text="Connecting to FFmpeg download…", fg=COLORS["yellow"])
        self._refresh_all()

        def worker() -> None:
            try:
                progress = lambda current, total, name: self.events.put(("ffmpeg_progress", current, total, name))
                installed = install_managed_ffmpeg(
                    self.app_root,
                    log=lambda text: self.events.put(("log", text)),
                    progress=progress,
                )
                self.events.put(("ffmpeg_complete", installed))
            except Exception as exc:
                self.events.put(("ffmpeg_error", str(exc)))
        threading.Thread(target=worker, daemon=True, name="CRysTal-FFmpeg-Installer").start()

    def _uninstall_ffmpeg(self) -> None:
        if self.running or self.ffmpeg_busy:
            return
        managed = managed_ffmpeg_executable(self.app_root)
        if not managed.is_file():
            messagebox.showinfo("No managed FFmpeg", "CRysTal Scraper has no private FFmpeg copy to remove. External FFmpeg installations are never touched.")
            return
        if not messagebox.askyesno(
            "Uninstall managed FFmpeg",
            "Remove only the FFmpeg copy installed by CRysTal Scraper?\n\nExternal and system FFmpeg installations will not be changed.",
        ):
            return
        try:
            current = Path(self.ffmpeg_var.get().strip()) if self.ffmpeg_var.get().strip() else None
            uninstall_managed_ffmpeg(self.app_root, log=self._append_log)
            if is_managed_ffmpeg(current, self.app_root):
                self.ffmpeg_var.set("")
            fallback = resolve_ffmpeg(None, self.app_root)
            if fallback:
                self.ffmpeg_var.set(str(fallback))
            self._save_preferences()
            self._refresh_all()
            messagebox.showinfo("FFmpeg removed", "The CRysTal-managed FFmpeg copy was removed. No external installation was changed.")
        except Exception as exc:
            messagebox.showerror("Could not uninstall FFmpeg", str(exc))

    def _auto_detect_tools(self) -> None:
        if not self.esde_var.get().strip():
            found = detect_esde_executable(self.app_root)
            if found: self.esde_var.set(str(found))
        if not self.ffmpeg_var.get().strip():
            found = resolve_ffmpeg(None, self.app_root)
            if found: self.ffmpeg_var.set(str(found))
        if self.esde_var.get().strip():
            self._load_systems(silent=True)

    def _load_systems(self, silent=False) -> None:
        path = Path(self.esde_var.get().strip()) if self.esde_var.get().strip() else Path()
        if not path.is_file():
            return
        try:
            self.systems = load_esde_systems(path)
            labels = [system.display_name for system in self.systems]
            self.easy_system_combo.configure(values=labels)
            self.pro_system_combo.configure(values=labels)
            if self.easy_rom_var.get().strip():
                self._auto_match_easy()
            if self.mister_root_var.get().strip() and Path(self.mister_root_var.get().strip()).is_dir() and not self.mister_scan_busy:
                self._start_mister_scan(Path(self.mister_root_var.get().strip()), select_first=False, add_to_pro=False)
            if not silent:
                self._append_log(f"Loaded {len(self.systems)} ES-DE system definitions.")
        except Exception as exc:
            self.systems = []
            if not silent: messagebox.showerror("Could not load ES-DE systems", str(exc))

    def _find_system(self, value: str) -> Optional[SystemEntry]:
        value = value.strip().lower()
        return next((s for s in self.systems if s.display_name.lower() == value), None) or next((s for s in self.systems if s.name.lower() == value or s.full_name.lower() == value), None) or next((s for s in self.systems if value and (value in s.full_name.lower() or value in s.name.lower())), None)

    def _auto_match_easy(self) -> None:
        value = self.easy_rom_var.get().strip()
        if not value:
            self.easy_system = None
            self.easy_system_var.set("")
            self._refresh_easy_hint()
            return
        folder = Path(value)
        if folder.is_dir() and self.systems:
            match = suggest_system(folder, self.systems)
            if match:
                self.easy_system = match; self.easy_system_var.set(match.display_name)
        self._refresh_easy_hint()

    def _on_easy_system(self, _event=None) -> None:
        match = self._find_system(self.easy_system_var.get())
        if match:
            self.easy_system = match; self.easy_system_var.set(match.display_name)
        self._refresh_easy_hint(); self._refresh_all()

    def _refresh_easy_hint(self) -> None:
        value = self.easy_rom_var.get().strip()
        if not value:
            self.easy_hint_var.set("Choose a MiSTer SD card above or point me to one ROM system folder manually.")
            return
        folder = Path(value)
        if not folder.is_dir():
            self.easy_hint_var.set("Choose a ROM folder and I will identify the system.")
            return
        if not self.easy_system:
            self.easy_hint_var.set("Select or detect the matching system.")
            return
        destination = self._destination_for(folder, self.easy_system)
        job = SystemJob(folder, self.easy_system, destination)
        key = self._analysis_key(job, destination)
        details = self.analysis_cache.get(key)
        if details is None:
            self.easy_hint_var.set(f"{self.easy_system.full_name} • Analyzing games in the background…")
            self._request_library_analysis()
            return
        folder_count = details["folder_count"]
        folder_note = f" • {folder_count} folder game{'s' if folder_count != 1 else ''}" if folder_count else ""
        extra = details["extra"]
        report = details["report"]
        smart_text = f"Smart scan: {len(report.new)} new • {len(report.incomplete)} incomplete • {len(report.complete)} complete"
        self.easy_hint_var.set(
            f"{self.easy_system.full_name} • {details['count']} games{folder_note}{extra}\n"
            f"{smart_text} • Detected: {details['summary']}"
        )

    def _pro_add_folder(self) -> None:
        value = filedialog.askdirectory(title="Add one system ROM folder", mustexist=True)
        if value:
            self._add_pro_folder(Path(value), announce=True)

    def _pro_add_root(self) -> None:
        value = filedialog.askdirectory(title="Select a root containing system folders", mustexist=True)
        if not value: return
        root = Path(value)
        added = 0; skipped = 0
        for folder in sorted((p for p in root.iterdir() if p.is_dir()), key=lambda p: p.name.lower()):
            if self._add_pro_folder(folder, announce=False): added += 1
            else: skipped += 1
        self._append_log(f"Pro scan: added {added} system folder(s); skipped {skipped} folders without a confident game/system match.")
        self._refresh_all()

    def _add_pro_folder(self, folder: Path, announce: bool) -> bool:
        if any(os.path.normcase(str(job.rom_folder.resolve())) == os.path.normcase(str(folder.resolve())) for job in self.pro_jobs):
            return False
        match = suggest_system(folder, self.systems) if self.systems else None
        if not match:
            if announce: messagebox.showwarning("System not identified", f"I could not confidently match this folder to an ES-DE system:\n\n{folder}\n\nLoad ES-DE first or add the folder and select its system manually in Easy Mode.")
            return False
        if not has_likely_game_content(folder):
            return False
        self.pro_jobs.append(SystemJob(folder, match, None))
        self._invalidate_analysis()
        self._refresh_pro_tree()
        if announce: self._append_log(f"Added {match.full_name}: {folder}")
        self._refresh_all()
        return True

    def _refresh_pro_tree(self) -> None:
        for item in self.pro_tree.get_children():
            self.pro_tree.delete(item)
        missing = False
        for index, job in enumerate(self.pro_jobs):
            destination = self._destination_for(job.rom_folder, job.system)
            details = self.analysis_cache.get(self._analysis_key(job, destination))
            if details is None:
                games = "…"
                needed = "…"
                missing = True
            else:
                games = details["count"]
                report = details["report"]
                mode = self._smart_mode()
                needed = games if mode == "all" else (len(report.new) if mode == "new_only" else len(report.new_and_incomplete))
            self.pro_tree.insert("", "end", iid=str(index), values=(job.system.full_name, games, needed, str(job.rom_folder)))
        # Exact counts are intentionally deferred until the user explicitly
        # requests a refresh or starts a Pro scrape.

    def _pro_remove(self) -> None:
        indexes = sorted((int(item) for item in self.pro_tree.selection()), reverse=True)
        for index in indexes:
            if 0 <= index < len(self.pro_jobs): self.pro_jobs.pop(index)
        self._invalidate_analysis(); self._refresh_pro_tree(); self._refresh_all()

    def _pro_clear(self) -> None:
        self.pro_jobs.clear(); self._invalidate_analysis(); self._refresh_pro_tree(); self._refresh_all()

    def _pro_apply_system(self) -> None:
        selection = self.pro_tree.selection()
        system = self._find_system(self.pro_system_var.get())
        if not selection or not system:
            messagebox.showinfo("Select a row and system", "Select one Pro Mode row, choose the correct ES-DE system, then apply it."); return
        index = int(selection[0])
        old = self.pro_jobs[index]
        self.pro_jobs[index] = SystemJob(old.rom_folder, system, old.output_root)
        self._invalidate_analysis(); self._refresh_pro_tree(); self._refresh_all()

    def _toggle_account(self) -> None:
        state = "normal" if self.use_account_var.get() else "disabled"
        if hasattr(self, "username_entry"):
            self.username_entry.configure(state=state); self.password_entry.configure(state=state)

    def _set_media_preset(self, name: str) -> None:
        selected = set(MEDIA_PRESETS[name])
        for key, variable in self.media_vars.items(): variable.set(key in selected)
        self._invalidate_analysis(); self._refresh_all()

    def _selected_media(self) -> tuple[str, ...]:
        return tuple(key for key in MEDIA_TYPES if self.media_vars[key].get())

    def _refresh_output_state(self) -> None:
        enabled = self.separate_output_var.get()
        state = "normal" if enabled else "disabled"
        if hasattr(self, "output_entry"):
            self.output_entry.configure(state=state); self.output_button.configure(state=state)
        self._invalidate_analysis(); self._refresh_all()

    def _region_code(self) -> str:
        return next((code for label, code in REGIONS if label == self.region_var.get()), "us")

    def _language_code(self) -> str:
        return next((code for label, code in LANGUAGES if label == self.language_var.get()), "en")

    def _smart_mode(self) -> str:
        return SMART_SCAN_MODES.get(self.smart_scan_var.get(), "new_incomplete")

    def _package_options(self) -> PackageOptions:
        return PackageOptions(
            export_format=self.export_var.get(), optimize_images=self.optimize_var.get(), convert_videos=True,
            include_gallery_art=self.gallery_var.get(), selected_media=self._selected_media(),
        )

    def _destination_for(self, rom_folder: Path, system: SystemEntry) -> Path:
        if self.separate_output_var.get() and self.output_root_var.get().strip():
            return Path(self.output_root_var.get().strip()) / system.system_folder
        return rom_folder

    def _invalidate_analysis(self) -> None:
        self.analysis_generation += 1
        self.analysis_cache.clear()
        self.smart_cache.clear()
        self.analysis_pending = True

    def _analysis_key(self, job: SystemJob, destination: Path) -> tuple:
        options = self._package_options()
        try:
            rom_stamp = job.rom_folder.stat().st_mtime_ns
        except OSError:
            rom_stamp = 0
        gamelist = destination / "media" / "gamelist.xml"
        try:
            stat = gamelist.stat()
            gamelist_stamp = (stat.st_mtime_ns, stat.st_size)
        except OSError:
            gamelist_stamp = (0, 0)
        return (
            os.path.normcase(str(job.rom_folder.resolve())), job.system.name,
            os.path.normcase(str(destination.resolve())), options.export_format,
            options.selected_media, options.include_gallery_art,
            bool(self.metadata_var.get() or self.game_names_var.get() or self.ratings_var.get()),
            rom_stamp, gamelist_stamp,
        )

    def _raw_jobs(self) -> list[SystemJob]:
        if self.mode_var.get() == "easy":
            value = self.easy_rom_var.get().strip()
            folder = Path(value) if value else None
            if folder is not None and folder.is_dir() and self.easy_system:
                return [SystemJob(folder, self.easy_system, self._destination_for(folder, self.easy_system))]
            return []
        return [SystemJob(job.rom_folder, job.system, self._destination_for(job.rom_folder, job.system)) for job in self.pro_jobs]

    def _request_library_analysis(self) -> None:
        jobs = self._raw_jobs()
        missing: list[tuple[SystemJob, Path, tuple]] = []
        for job in jobs:
            destination = job.output_root or self._destination_for(job.rom_folder, job.system)
            key = self._analysis_key(job, destination)
            if key not in self.analysis_cache:
                missing.append((job, destination, key))
        if not missing:
            self.analysis_pending = False
            return
        if self.analysis_busy:
            self.analysis_pending = True
            return
        self.analysis_busy = True
        self.analysis_pending = False
        generation = self.analysis_generation
        options = self._package_options()
        require_gamelist = True  # Both CRysTal Fantasy and Default Console Mode always keep gamelist.xml
        self.stage_var.set("Analyzing library")
        self.progress_var.set(f"0 of {len(missing)} systems")
        self.mister_scan_status_var.set("Analyzing selected games in the background…")
        self.mister_scan_progressbar.configure(mode="indeterminate")
        self.footer_scan_progressbar.configure(mode="indeterminate")
        self.mister_scan_progressbar.start(12); self.footer_scan_progressbar.start(12)

        def worker() -> None:
            results: list[tuple[tuple, dict]] = []
            try:
                total = len(missing)
                for current, (job, destination, key) in enumerate(missing, start=1):
                    self.events.put(("analysis_progress", generation, current, total, job.system.full_name))
                    adapted, ext_report = extension_compatible_system(job.rom_folder, job.system)
                    report = analyze_smart_resume(
                        job.rom_folder, adapted, destination, options,
                        require_gamelist=require_gamelist, adapt_extensions=False,
                    )
                    all_records = report.complete + report.new + report.incomplete
                    summary = ", ".join(f"{ext} × {count}" for ext, count in list(ext_report.counts.items())[:6]) or "No likely game files"
                    extra = f" • Extension Masquerade adds {', '.join(ext_report.added_extensions)} privately" if ext_report.masquerade_active else ""
                    results.append((key, {
                        "report": report,
                        "count": report.total,
                        "folder_count": sum(1 for record in all_records if record.is_folder),
                        "summary": summary,
                        "extra": extra,
                    }))
                self.events.put(("analysis_complete", generation, results))
            except Exception as exc:
                self.events.put(("analysis_error", generation, str(exc)))
        threading.Thread(target=worker, daemon=True, name="CRysTal-Library-Analyzer").start()

    def _smart_report_for(self, job: SystemJob, destination: Path, *, allow_compute: bool = True):
        key = self._analysis_key(job, destination)
        details = self.analysis_cache.get(key)
        if details is not None:
            return details["report"]
        if not allow_compute:
            return None
        options = self._package_options()
        report = analyze_smart_resume(
            job.rom_folder, job.system, destination, options,
            require_gamelist=True,
        )
        self.analysis_cache[key] = {
            "report": report, "count": report.total,
            "folder_count": sum(1 for record in report.complete + report.new + report.incomplete if record.is_folder),
            "summary": "Analyzed", "extra": "",
        }
        return report

    def _refresh_smart_scan(self) -> None:
        self._invalidate_analysis()
        self._refresh_easy_hint(); self._refresh_pro_tree(); self._refresh_all()
        # This is the user's explicit request to inspect ROMs and finished media.
        self._request_library_analysis()

    def _current_jobs(self, *, allow_compute: bool = True) -> list[SystemJob]:
        raw: list[SystemJob]
        if self.mode_var.get() == "easy":
            value = self.easy_rom_var.get().strip()
            folder = Path(value) if value else None
            raw = [SystemJob(folder, self.easy_system, None)] if folder is not None and folder.is_dir() and self.easy_system else []
        else:
            raw = list(self.pro_jobs)
        jobs: list[SystemJob] = []
        mode = self._smart_mode()
        for job in raw:
            destination = self._destination_for(job.rom_folder, job.system)
            if mode == "all":
                jobs.append(SystemJob(job.rom_folder, job.system, destination))
                continue
            report = self._smart_report_for(job, destination, allow_compute=allow_compute)
            if report is None:
                continue
            records = report.new if mode == "new_only" else report.new_and_incomplete
            if not records:
                continue
            jobs.append(SystemJob(
                job.rom_folder, job.system, destination, {},
                tuple(record.relative_path for record in records), True, False,
            ))
        return jobs

    def _make_config(self) -> BatchSessionConfig:
        options = self._package_options()
        scrape = ScrapeOptions(
            use_screenscraper_account=self.use_account_var.get(), username=self.username_var.get().strip(), password=self.password_var.get(),
            remember_password=self.remember_password_var.get(), game_names=self.game_names_var.get(), ratings=self.ratings_var.get(),
            metadata=self.metadata_var.get(), media_types=self._selected_media(), region=self._region_code(), language=self._language_code(),
            overwrite=self.overwrite_var.get(), retry_count=3,
        )
        return BatchSessionConfig(
            esde_executable=Path(self.esde_var.get().strip()), jobs=self._current_jobs(),
            ffmpeg_executable=Path(self.ffmpeg_var.get().strip()) if self.ffmpeg_var.get().strip() else None,
            options=options, scrape=scrape,
        )

    def _readiness(self) -> tuple[bool, list[str]]:
        problems: list[str] = []
        esde = Path(self.esde_var.get().strip()) if self.esde_var.get().strip() else Path()
        if not esde.is_file() or find_esde_systems_xml(esde) is None: problems.append("Select a complete ES-DE installation")
        ffmpeg = resolve_ffmpeg(Path(self.ffmpeg_var.get()) if self.ffmpeg_var.get().strip() else None, self.app_root)
        if ffmpeg is None: problems.append("Select ffmpeg.exe so PNG output is guaranteed")
        jobs = self._current_jobs(allow_compute=False)
        if not jobs:
            raw_selected = bool(self.easy_rom_var.get().strip() and self.easy_system) if self.mode_var.get() == "easy" else bool(self.pro_jobs)
            if raw_selected and self._smart_mode() != "all" and any(
                self._analysis_key(job, job.output_root or self._destination_for(job.rom_folder, job.system)) not in self.analysis_cache
                for job in self._raw_jobs()
            ):
                problems.append("Analyzing selected games in the background")
            elif raw_selected and self._smart_mode() != "all":
                problems.append("Smart Resume found nothing new or incomplete")
            else:
                problems.append("Choose one system folder" if self.mode_var.get() == "easy" else "Add at least one Pro Mode system")
        if self.separate_output_var.get() and not self.output_root_var.get().strip(): problems.append("Choose the separate output root")
        if self.use_account_var.get() and (not self.username_var.get().strip() or not self.password_var.get()): problems.append("Enter both ScreenScraper username and password")
        if not self._selected_media() and not (self.game_names_var.get() or self.ratings_var.get() or self.metadata_var.get()): problems.append("Select metadata or media to scrape")
        if self.export_var.get() == "console_mode" and not ({"covers", "screenshots"} & set(self._selected_media())): problems.append("Console Mode needs covers and/or screenshots")
        return not problems, problems

    def _refresh_all(self) -> None:
        self._refresh_easy_hint()
        if hasattr(self, "easy_sd_scan_button"):
            scan_state = "disabled" if self.mister_scan_busy or self.running else "normal"
            self.easy_sd_scan_button.configure(state=scan_state)
            self.pro_sd_scan_button.configure(state=scan_state)
        esde = Path(self.esde_var.get().strip()) if self.esde_var.get().strip() else Path()
        if hasattr(self, "esde_status"):
            good = esde.is_file() and find_esde_systems_xml(esde) is not None
            if not self.esde_busy:
                managed_esde = is_managed_esde(esde if good else None, self.app_root)
                self.esde_status.configure(
                    text=("✓ Managed ES-DE ready" if managed_esde else "✓ External ES-DE ready") if good else "Required — install or select ES-DE",
                    fg=COLORS["green"] if good else COLORS["yellow"],
                )
            if hasattr(self, "esde_install_button"):
                installed_esde = managed_esde_executable(self.app_root).is_file()
                self.esde_install_button.configure(
                    text="Update / Repair" if installed_esde else "Install ES-DE",
                    state="disabled" if self.esde_busy or self.running else "normal",
                )
                self.esde_remove_button.configure(
                    state="normal" if installed_esde and not self.esde_busy and not self.running else "disabled",
                )
            ffmpeg = resolve_ffmpeg(Path(self.ffmpeg_var.get()) if self.ffmpeg_var.get().strip() else None, self.app_root)
            if not self.ffmpeg_busy:
                if ffmpeg:
                    managed = is_managed_ffmpeg(ffmpeg, self.app_root)
                    label = "✓ Managed FFmpeg ready" if managed else "✓ External FFmpeg ready"
                    self.ffmpeg_status.configure(text=label, fg=COLORS["green"])
                else:
                    self.ffmpeg_status.configure(text="Required — install or select FFmpeg", fg=COLORS["yellow"])
            if hasattr(self, "ffmpeg_install_button"):
                installed = managed_ffmpeg_executable(self.app_root).is_file()
                self.ffmpeg_install_button.configure(
                    text="Update / Repair" if installed else "Install FFmpeg",
                    state="disabled" if self.ffmpeg_busy or self.running else "normal",
                )
                self.ffmpeg_remove_button.configure(
                    state="normal" if installed and not self.ffmpeg_busy and not self.running else "disabled",
                )
        okay, problems = self._readiness()
        if hasattr(self, "ready_label"):
            count = len(self._current_jobs())
            if okay:
                self.ready_var.set(f"✓ Ready — {count} system{'s' if count != 1 else ''} will live-sync")
                self.ready_label.configure(fg=COLORS["green"])
            else:
                self.ready_var.set(" • ".join(problems[:3]))
                self.ready_label.configure(fg=COLORS["yellow"])
            self.run_button.configure(state="normal" if okay and not self.running else "disabled")

    def _confirm_and_run(self) -> None:
        okay, problems = self._readiness()
        if not okay:
            messagebox.showerror("Not ready", "\n".join("• " + problem for problem in problems)); return
        if os.name != "nt":
            messagebox.showerror("Windows required", "The safe private ES-DE bridge uses Windows directory junctions."); return
        jobs = self._current_jobs()
        format_name = "CRysTal Fantasy" if self.export_var.get() == "crystal_fantasy" else "Default Console Mode"
        action = "one selected system" if len(jobs) == 1 else f"{len(jobs)} selected systems"
        if not messagebox.askokcancel(
            "Open private ES-DE",
            f"ES-DE will open with only {action} visible.\n\n"
            f"Output: {format_name}\n"
            f"Scan: {self.smart_scan_var.get()}\n"
            "The bridge will watch ES-DE while it scrapes, wait for files to finish writing, compress every image to PNG8, and replace changed outputs when you correct or rescrape a game.\n\n"
            "In ES-DE choose Scraper → Scrape Now. In Pro Mode you can choose all visible systems. Exit ES-DE when finished.\n\n"
            "After the final verified conversion, all private ES-DE downloads and cache are deleted automatically. Your ROMs and normal ES-DE profile are not changed.",
        ):
            return
        self._start_worker()

    def _start_worker(self) -> None:
        self._save_preferences()
        self.running = True; self.last_result = None
        self.progressbar.configure(value=5); self.open_output_button.configure(state="disabled")
        self.stage_var.set("Preparing"); self.progress_var.set("Building private ES-DE profile")
        self._show_page(2); self._refresh_all()
        config = self._make_config()

        def worker() -> None:
            try:
                stage = lambda key, text: self.events.put(("stage", key, text))
                progress = lambda current, total, name: self.events.put(("progress", current, total, name))
                result = self.core.run_live_session(config, stage=stage, progress=progress)
                self.events.put(("complete", result))
            except Exception as exc:
                self.events.put(("error", str(exc)))
        threading.Thread(target=worker, daemon=True, name="CRysTal-Scraper-Worker").start()

    def _poll_events(self) -> None:
        try:
            while True:
                event = self.events.get_nowait(); kind = event[0]
                if kind == "log": self._append_log(event[1])
                elif kind == "stage":
                    self.stage_var.set(event[2]); self.progress_var.set("")
                    self.progressbar.configure(value={"prepare": 10, "esde": 30, "cleanup": 90, "complete": 100}.get(event[1], 5))
                elif kind == "progress":
                    current, total, name = event[1], max(1, event[2]), event[3]
                    self.progressbar.configure(value=min(88, 30 + int(58 * current / total)))
                    self.progress_var.set(f"Live sync: {name}")
                elif kind == "complete": self._finish_success(event[1])
                elif kind == "error": self._finish_error(event[1])
                elif kind == "mister_scan_progress":
                    token, current, total, name = event[1], event[2], max(1, event[3]), event[4]
                    if token == self.mister_scan_token:
                        percent = min(100, int(current * 100 / total))
                        self.mister_scan_progressbar.configure(value=percent)
                        self.footer_scan_progressbar.configure(value=percent)
                        self.mister_scan_status_var.set(f"Scanning {name} — {current}/{total}")
                elif kind == "mister_scan_complete":
                    token, root_text, candidates, select_first, add_to_pro = event[1:]
                    if token == self.mister_scan_token:
                        self.mister_scan_busy = False
                        self.mister_scan_progressbar.stop(); self.footer_scan_progressbar.stop()
                        self.mister_scan_progressbar.configure(mode="determinate", value=100)
                        self.footer_scan_progressbar.configure(mode="determinate", value=100)
                        if candidates:
                            games_count = sum(1 for candidate in candidates if candidate.kind == "games")
                            specials = [candidate.label for candidate in candidates if candidate.kind != "games"]
                            suffix = f" + {', '.join(specials)}" if specials else ""
                            game_candidates = [candidate for candidate in candidates if candidate.kind == "games"]
                            mapped = sum(1 for candidate in game_candidates if candidate.system is not None)
                            unsupported = sum(1 for candidate in game_candidates if not candidate.scrapeable)
                            known_missing = sum(1 for candidate in game_candidates if candidate.scrapeable and candidate.known_platform and candidate.system is None)
                            unknown = [candidate.folder.name for candidate in game_candidates if candidate.scrapeable and not candidate.known_platform]
                            self.mister_scan_status_var.set(
                                rf"Listed {games_count} folders: {mapped} mapped • {known_missing} need newer ES-DE • {unsupported} support-only • {len(unknown)} unknown{suffix}"
                            )
                            self._append_log(
                                rf"MiSTer registry checked all {games_count} immediate media\fat\games folders"
                                + (f" plus {len(specials)} special folder(s)." if specials else ".")
                                + f" Mapped: {mapped}; known but unavailable in ES-DE: {known_missing}; support-only: {unsupported}; unknown: {len(unknown)}."
                            )
                            if unknown:
                                self._append_log("Unknown MiSTer folder names: " + ", ".join(unknown))
                            self._apply_mister_scan(Path(root_text), candidates, select_first=select_first, add_to_pro=add_to_pro)
                        else:
                            self.mister_scan_status_var.set(r"No folders found at media\fat\games")
                            messagebox.showwarning("No MiSTer folders found", r"No immediate folders were found under media\fat\games. You can still choose a ROM folder manually.")
                        self._refresh_all()
                elif kind == "mister_scan_error":
                    token, message = event[1], event[2]
                    if token == self.mister_scan_token:
                        self.mister_scan_busy = False
                        self.mister_scan_progressbar.stop(); self.footer_scan_progressbar.stop()
                        self.mister_scan_progressbar.configure(mode="determinate", value=0)
                        self.footer_scan_progressbar.configure(mode="determinate", value=0)
                        self.mister_scan_status_var.set("SD-card scan stopped safely")
                        self._refresh_all()
                        messagebox.showerror("Could not scan MiSTer SD card", message)
                elif kind == "analysis_progress":
                    generation, current, total, name = event[1], event[2], max(1, event[3]), event[4]
                    if generation == self.analysis_generation:
                        self.progress_var.set(f"Analyzing {current}/{total}: {name}")
                        self.mister_scan_status_var.set(f"Analyzing {name} — {current}/{total}")
                elif kind == "analysis_complete":
                    generation, results = event[1], event[2]
                    self.analysis_busy = False
                    if generation == self.analysis_generation:
                        self.mister_scan_progressbar.stop(); self.footer_scan_progressbar.stop()
                        self.mister_scan_progressbar.configure(mode="determinate", value=100)
                        self.footer_scan_progressbar.configure(mode="determinate", value=100)
                        for key, details in results:
                            self.analysis_cache[key] = details
                        self.analysis_pending = False
                        self.mister_scan_status_var.set("Scan complete — choose a system from the list")
                        if not self.running:
                            self.stage_var.set("Ready")
                            self.progress_var.set("")
                        self._refresh_easy_hint()
                        self._refresh_pro_tree()
                        self._refresh_all()
                    else:
                        self.analysis_pending = True
                    if self.analysis_pending:
                        self.root.after_idle(self._request_library_analysis)
                elif kind == "analysis_error":
                    generation, message = event[1], event[2]
                    self.analysis_busy = False
                    if generation == self.analysis_generation:
                        self.mister_scan_progressbar.stop(); self.footer_scan_progressbar.stop()
                        self.mister_scan_progressbar.configure(mode="determinate", value=0)
                        self.footer_scan_progressbar.configure(mode="determinate", value=0)
                        self.mister_scan_status_var.set("Game analysis stopped safely")
                        self._append_log("Analysis error: " + message)
                    if self.analysis_pending:
                        self.root.after_idle(self._request_library_analysis)
                elif kind == "esde_progress":
                    current, total, name = event[1], max(1, event[2]), event[3]
                    percent = min(100, int(current * 100 / total))
                    self.esde_status.configure(text=f"{name} — {percent}%", fg=COLORS["yellow"])
                elif kind == "esde_complete":
                    self.esde_busy = False
                    installed = Path(event[1])
                    self.esde_var.set(str(installed))
                    self._load_systems(silent=True)
                    self._save_preferences(); self._refresh_all()
                    messagebox.showinfo("ES-DE ready", "The latest official portable ES-DE release was installed privately for CRysTal Scraper.")
                elif kind == "esde_error":
                    self.esde_busy = False
                    self._refresh_all()
                    messagebox.showerror("ES-DE installation failed", event[1])
                elif kind == "ffmpeg_progress":
                    current, total, name = event[1], max(1, event[2]), event[3]
                    percent = min(100, int(current * 100 / total))
                    self.ffmpeg_status.configure(text=f"{name} — {percent}%", fg=COLORS["yellow"])
                elif kind == "ffmpeg_complete":
                    self.ffmpeg_busy = False
                    installed = Path(event[1])
                    self.ffmpeg_var.set(str(installed))
                    self._save_preferences(); self._refresh_all()
                    version = ffmpeg_version_text(installed)
                    messagebox.showinfo("FFmpeg ready", "FFmpeg was installed privately for CRysTal Scraper." + (f"\n\n{version}" if version else ""))
                elif kind == "ffmpeg_error":
                    self.ffmpeg_busy = False
                    self._refresh_all()
                    messagebox.showerror("FFmpeg installation failed", event[1])
        except queue.Empty:
            pass
        self.root.after(80, self._poll_events)

    def _finish_success(self, result: BatchResult) -> None:
        self.running = False; self.last_result = result
        self._invalidate_analysis()
        self.progressbar.configure(value=100); self.stage_var.set("Complete")
        self.progress_var.set(f"{result.systems} systems • {result.games} games • {result.media_files} media files")
        self.open_output_button.configure(state="normal")
        self._append_log("Live sync complete. Temporary ES-DE originals were deleted.")
        for root in result.output_roots: self._append_log(f"Output: {root}")
        self._refresh_all()
        messagebox.showinfo("Scrape sync complete", f"CRysTal Scraper finished syncing {result.systems} system(s).\n\nChanged media was converted and verified, then all temporary ES-DE downloads were deleted.")

    def _finish_error(self, message: str) -> None:
        self.running = False; self.stage_var.set("Stopped safely"); self.progress_var.set(message)
        self._append_log("ERROR: " + message); self._refresh_all()
        messagebox.showerror("CRysTal Scraper stopped safely", message)

    def _append_log(self, text: str) -> None:
        if not hasattr(self, "log_box"): return
        self.log_box.configure(state="normal"); self.log_box.insert("end", text.rstrip() + "\n"); self.log_box.see("end"); self.log_box.configure(state="disabled")

    def _clear_log(self) -> None:
        self.log_box.configure(state="normal"); self.log_box.delete("1.0", "end"); self.log_box.configure(state="disabled")

    def _save_preferences(self) -> None:
        values = {
            "mode": self.mode_var.get(), "esde": self.esde_var.get().strip(), "ffmpeg": self.ffmpeg_var.get().strip(),
            "rom": self.easy_rom_var.get().strip(), "mister_root": self.mister_root_var.get().strip(),
            "smart_scan_mode": self._smart_mode(), "use_account": self.use_account_var.get(), "username": self.username_var.get().strip(),
            "remember_password": self.remember_password_var.get(), "region_label": self.region_var.get(), "language_label": self.language_var.get(),
            "overwrite": self.overwrite_var.get(), "game_names": self.game_names_var.get(), "ratings": self.ratings_var.get(),
            "metadata": self.metadata_var.get(), "media_types": list(self._selected_media()), "export_format": self.export_var.get(),
            "separate_output": self.separate_output_var.get(), "output_root": self.output_root_var.get().strip(),
            "optimize_images": self.optimize_var.get(), "gallery": self.gallery_var.get(),
        }
        if self.remember_password_var.get(): values["password"] = self.password_var.get()
        self.core.save_preferences(values)

    def _open_last_output(self) -> None:
        if not self.last_result or not self.last_result.output_roots: return
        self._open_path(self.last_result.output_roots[0])

    def _open_path(self, path: Path) -> None:
        try:
            path.mkdir(parents=True, exist_ok=True)
            if os.name == "nt": os.startfile(str(path))  # type: ignore[attr-defined]
            elif sys.platform == "darwin": subprocess.Popen(["open", str(path)])
            else: subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc: messagebox.showerror("Could not open folder", str(exc))

    def _reset_profile(self) -> None:
        if self.running: return
        if messagebox.askyesno(
            "Clear leftover cache",
            "Successful sessions already delete all temporary ES-DE downloads automatically.\n\n"
            "Clear leftovers from a cancelled, crashed or failed session? ROMs, finished media, preferences, managed FFmpeg and safety backups are untouched.",
        ):
            try:
                self.core.reset_isolated_profile()
                self._append_log("Leftover private ES-DE cache cleared. Finished media and safety backups were preserved.")
            except Exception as exc: messagebox.showerror("Cleanup failed", str(exc))

    def _on_close(self) -> None:
        if self.running:
            messagebox.showinfo("Scrape in progress", "Close ES-DE first and let the final sync finish."); return
        if self.esde_busy:
            messagebox.showinfo("ES-DE installation in progress", "Let the ES-DE installation finish before closing the app."); return
        if self.ffmpeg_busy:
            messagebox.showinfo("FFmpeg installation in progress", "Let the FFmpeg installation finish before closing the app."); return
        self._save_preferences(); self.root.destroy()


def main() -> None:
    root = tk.Tk()
    CrystalScraperApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
