from __future__ import annotations

import csv
import hashlib
import itertools
import json
import os
import re
import shutil
import stat
import struct
import subprocess
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
import xml.etree.ElementTree as ET
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterable, Optional, Sequence

APP_NAME = "CRysTal Fantasy Scraper"
APP_VERSION = "0.5.8 Build-Ready Windows EXE"
SCHEMA_VERSION = "internal-gamelist-v2"

LogFn = Callable[[str], None]
StageFn = Callable[[str, str], None]
ProgressFn = Callable[[int, int, str], None]


def _noop_log(_: str) -> None:
    pass


def _noop_stage(_: str, __: str) -> None:
    pass


def _noop_progress(_: int, __: int, ___: str) -> None:
    pass


@dataclass(frozen=True)
class SystemEntry:
    name: str
    full_name: str
    rom_path: str
    extensions: tuple[str, ...]
    outer_xml: str
    source_xml: str

    @property
    def display_name(self) -> str:
        return f"{self.full_name}  [{self.name}]"

    @property
    def system_folder(self) -> str:
        path = self.rom_path.replace("\\", "/").replace("%ROMPATH%", "").strip("/")
        if not path or "%" in path:
            return self.name
        return path.split("/")[0] or self.name

    @property
    def canonical_id(self) -> str:
        return canonical_system_id(self.name, self.full_name, self.system_folder)


@dataclass(frozen=True)
class ExtensionCompatibility:
    original_extensions: tuple[str, ...]
    accepted_extensions: tuple[str, ...]
    added_extensions: tuple[str, ...]
    counts: dict[str, int]
    game_file_count: int

    @property
    def masquerade_active(self) -> bool:
        return bool(self.added_extensions)


MEDIA_TYPES = (
    "screenshots", "titlescreens", "covers", "backcovers", "marquees",
    "3dboxes", "physicalmedia", "fanart", "videos", "manuals", "miximages",
)

CRYSTAL_RECOMMENDED_MEDIA = (
    "screenshots", "covers", "backcovers", "physicalmedia", "videos", "manuals",
)

MEDIA_SETTING_KEYS = {
    "screenshots": "ScrapeScreenshots",
    "titlescreens": "ScrapeTitleScreens",
    "covers": "ScrapeCovers",
    "backcovers": "ScrapeBackCovers",
    "marquees": "ScrapeMarquees",
    "3dboxes": "Scrape3DBoxes",
    "physicalmedia": "ScrapePhysicalMedia",
    "fanart": "ScrapeFanArt",
    "videos": "ScrapeVideos",
    "manuals": "ScrapeManuals",
}

EXPORT_PRESETS = {
    "crystal_fantasy": {
        "title": "CRysTal Fantasy",
        "description": "Compressed PNG8 media and gamelist.xml written together in the main media folder, plus compact CRysTal video previews.",
    },
    "console_mode": {
        "title": "Default Console Mode",
        "description": "A simple media folder with gamelist.xml, <ROM>.png box art and <ROM>-BG.png screenshots.",
    },
}



@dataclass
class ScrapeOptions:
    use_screenscraper_account: bool = False
    username: str = ""
    password: str = ""
    remember_password: bool = False
    game_names: bool = True
    ratings: bool = True
    metadata: bool = True
    media_types: tuple[str, ...] = (
        "screenshots", "covers", "backcovers", "physicalmedia", "videos",
    )
    region: str = "us"
    language: str = "en"
    overwrite: bool = True
    retry_count: int = 3


@dataclass
class PackageOptions:
    export_format: str = "crystal_fantasy"
    optimize_images: bool = True
    convert_videos: bool = True
    include_gallery_art: bool = True
    keep_staging: bool = False
    target_system_folder: str = ""
    selected_media: tuple[str, ...] = MEDIA_TYPES


@dataclass
class SessionConfig:
    esde_executable: Path
    rom_folder: Path
    system: SystemEntry
    output_parent: Path
    ffmpeg_executable: Optional[Path]
    options: PackageOptions = field(default_factory=PackageOptions)
    scrape: ScrapeOptions = field(default_factory=ScrapeOptions)


@dataclass
class SystemJob:
    rom_folder: Path
    system: SystemEntry
    output_root: Optional[Path] = None
    scrape_path_map: dict[str, str] = field(default_factory=dict)
    selected_game_paths: tuple[str, ...] = ()
    merge_existing_gamelist: bool = False
    prune_outputs: bool = True


@dataclass(frozen=True)
class GameRecord:
    relative_path: str
    display_stem: str
    is_folder: bool = False


@dataclass(frozen=True)
class SmartResumeReport:
    total: int
    complete: tuple[GameRecord, ...]
    new: tuple[GameRecord, ...]
    incomplete: tuple[GameRecord, ...]
    orphaned_paths: tuple[str, ...]

    @property
    def new_and_incomplete(self) -> tuple[GameRecord, ...]:
        return self.new + self.incomplete


@dataclass(frozen=True)
class MisterFolderRule:
    display_name: str
    esde_names: tuple[str, ...] = ()
    scrapeable: bool = True
    note: str = ""


@dataclass(frozen=True)
class MisterSystemCandidate:
    label: str
    folder: Path
    system: Optional[SystemEntry]
    kind: str = "games"
    known_platform: str = ""
    support_note: str = ""
    scrapeable: bool = True


@dataclass
class BatchSessionConfig:
    esde_executable: Path
    jobs: list[SystemJob]
    ffmpeg_executable: Optional[Path]
    options: PackageOptions = field(default_factory=PackageOptions)
    scrape: ScrapeOptions = field(default_factory=ScrapeOptions)


@dataclass
class BatchResult:
    systems: int
    games: int
    media_files: int
    video_count: int
    output_roots: list[Path]


@dataclass
class PackageResult:
    package_root: Path
    media_file_count: int
    game_count: int
    video_count: int
    collision_count: int
    metadata_path: Optional[Path]
    copied_gamelist: Optional[Path]


@dataclass
class BridgeLocations:
    app_root: Path
    data_root: Path
    isolated_home: Path
    sessions_root: Path
    preferences_path: Path

    @classmethod
    def default(cls, app_root: Path) -> "BridgeLocations":
        if os.name == "nt":
            local = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))
        else:
            local = Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local" / "share")))
        data_root = local / "CRysTal Fantasy Scraper"
        return cls(
            app_root=app_root,
            data_root=data_root,
            isolated_home=data_root / "IsolatedHome",
            sessions_root=data_root / "Sessions",
            preferences_path=data_root / "preferences.json",
        )


SYSTEM_ALIASES: dict[str, str] = {
    "genesis": "genesis",
    "megadrive": "genesis",
    "megadrivejp": "genesis",
    "md": "genesis",
    "segagenesis": "genesis",
    "snes": "snes",
    "snesna": "snes",
    "supernintendo": "snes",
    "superfamicom": "snes",
    "nes": "nes",
    "famicom": "nes",
    "mastersystem": "mastersystem",
    "sms": "mastersystem",
    "pcengine": "pcengine",
    "pcenginecd": "pcenginecd",
    "tg16": "pcengine",
    "turbografx16": "pcengine",
    "turbografxcd": "pcenginecd",
    "pce": "pcengine",
    "neogeo": "neogeo",
    "neogeocd": "neogeocd",
    "psx": "playstation",
    "ps1": "playstation",
    "playstation": "playstation",
    "saturn": "saturn",
    "segasaturn": "saturn",
    "n64": "n64",
    "nintendo64": "n64",
    "gb": "gameboy",
    "gameboy": "gameboy",
    "gbc": "gameboycolor",
    "gameboycolor": "gameboycolor",
    "gba": "gameboyadvance",
    "gameboyadvance": "gameboyadvance",
    "gamegear": "gamegear",
    "gg": "gamegear",
    "segacd": "segacd",
    "megacd": "segacd",
    "sega32x": "sega32x",
    "32x": "sega32x",
    "3do": "3do",
    "panasonic3do": "3do",
    "jaguar": "jaguar",
    "atarijaguar": "jaguar",
    "arcade": "arcade",
    "mame": "arcade",
    "mamearcade": "arcade",
    "fbneo": "arcade",
    "finalburnneo": "arcade",
    "dos": "dos",
    "dosgames": "dos",
    "0mhz": "dos",
    "ao486": "dos",
    "pcdos": "dos",
    "amiga": "amiga",
    "amigacd32": "amigacd32",
    "cd32": "amigacd32",
    "amstradcpc": "amstradcpc",
    "cpc": "amstradcpc",
    "applei": "apple1",
    "appleii": "apple2",
    "apple2": "apple2",
    "atari2600": "atari2600",
    "atari5200": "atari5200",
    "atari7800": "atari7800",
    "atari800": "atari800",
    "atarilynx": "atarilynx",
    "lynx": "atarilynx",
    "atarist": "atarist",
    "c64": "c64",
    "commodore64": "c64",
    "colecovision": "colecovision",
    "coleco": "colecovision",
    "intellivision": "intellivision",
    "msx": "msx",
    "msx2": "msx2",
    "odyssey2": "odyssey2",
    "videopac": "odyssey2",
    "vectrex": "vectrex",
    "wonderswan": "wonderswan",
    "wonderswancolor": "wonderswancolor",
    "wswan": "wonderswan",
    "wswanc": "wonderswancolor",
    "zx81": "zx81",
    "zxspectrum": "zxspectrum",
    "spectrum": "zxspectrum",
}


# Deterministic MiSTer /media/fat/games folder registry.
# Folder names are stable conventions used by MiSTer cores and update packages.
# The first matching ES-DE name wins; this never scans ROMs or guesses by extension.
def _build_mister_folder_registry() -> dict[str, MisterFolderRule]:
    groups: tuple[tuple[tuple[str, ...], str, tuple[str, ...], bool, str], ...] = (
        # Consoles and handhelds
        (("3DO", "Panasonic3DO"), "3DO Interactive Multiplayer", ("3do",), True, ""),
        (("AdventureVision", "Avision"), "Entex Adventure Vision", ("adventurevision",), True, ""),
        (("Arcadia",), "Emerson Arcadia 2001", ("arcadia",), True, ""),
        (("Astrocade",), "Bally Astrocade", ("astrocde", "astrocade"), True, ""),
        (("Atari2600",), "Atari 2600", ("atari2600",), True, ""),
        (("Atari5200",), "Atari 5200", ("atari5200",), True, ""),
        (("Atari7800",), "Atari 7800", ("atari7800",), True, ""),
        (("Jaguar", "AtariJaguar"), "Atari Jaguar", ("atarijaguar", "jaguar"), True, ""),
        (("AtariLynx", "Lynx"), "Atari Lynx", ("atarilynx",), True, ""),
        (("ChannelF",), "Fairchild Channel F", ("channelf",), True, ""),
        (("Coleco", "ColecoVision"), "ColecoVision", ("colecovision",), True, ""),
        (("CreatiVision",), "VTech CreatiVision", ("creativision",), True, ""),
        (("FDS", "FamicomDiskSystem"), "Famicom Disk System", ("fds", "nes"), True, ""),
        (("Gamate",), "Bit Corporation Gamate", ("gamate",), True, ""),
        (("Gameboy", "GB", "Gameboy2P"), "Nintendo Game Boy", ("gameboy",), True, ""),
        (("GameboyColor", "GBC"), "Nintendo Game Boy Color", ("gameboycolor",), True, ""),
        (("GameboyAdvance", "GBA", "GBA2P"), "Nintendo Game Boy Advance", ("gameboyadvance",), True, ""),
        (("GameGear", "GG"), "Sega Game Gear", ("gamegear",), True, ""),
        (("GameNWatch", "GameAndWatch", "GNW"), "Nintendo Game & Watch", ("gameandwatch", "gameandwatchlcd"), True, ""),
        (("Genesis",), "Sega Genesis", ("genesis", "megadrive"), True, ""),
        (("Intellivision",), "Mattel Intellivision", ("intellivision",), True, ""),
        (("MasterSystem", "SMS", "SegaMark3"), "Sega Master System", ("mastersystem",), True, ""),
        (("MegaCD", "SegaCD"), "Sega CD / Mega-CD", ("segacd", "megacd"), True, ""),
        (("MegaDrive",), "Sega Mega Drive", ("megadrive", "genesis"), True, ""),
        (("MegaDuck",), "Mega Duck / Cougar Boy", ("megaduck",), True, ""),
        (("MyVision",), "Nichibutsu My Vision", ("myvision",), True, ""),
        (("N64", "Nintendo64"), "Nintendo 64", ("n64",), True, ""),
        (("NeoGeo",), "SNK Neo Geo", ("neogeo",), True, ""),
        (("NeoGeo-CD", "NeoGeoCD"), "SNK Neo Geo CD", ("neogeocd",), True, ""),
        (("NES", "Famicom", "Nintendo"), "Nintendo Entertainment System", ("nes",), True, ""),
        (("Odyssey2", "Videopac"), "Magnavox Odyssey² / Philips Videopac", ("odyssey2",), True, ""),
        (("PCEngine", "TGFX16", "TurboGrafx", "TurboGrafx16"), "PC Engine / TurboGrafx-16", ("pcengine",), True, ""),
        (("PCEngineCD", "TGFX16-CD", "TGFX16CD", "TurboGrafxCD", "TurboGrafx16CD"), "PC Engine CD / TurboGrafx-CD", ("pcenginecd",), True, ""),
        (("PokemonMini", "PokeMini"), "Pokémon Mini", ("pokemini",), True, ""),
        (("PSX", "PS1", "PlayStation"), "Sony PlayStation", ("psx", "playstation"), True, ""),
        (("RX78",), "Bandai RX-78", ("rx78",), True, ""),
        (("S32X", "32X", "Sega32X"), "Sega 32X", ("sega32x",), True, ""),
        (("Saturn", "SegaSaturn"), "Sega Saturn", ("saturn",), True, ""),
        (("SG1000",), "Sega SG-1000", ("sg1000",), True, ""),
        (("SC3000",), "Sega SC-3000", ("sc3000", "sg1000"), True, ""),
        (("SNES", "SuperNES", "SuperNintendo", "SuperFamicom", "Sufami"), "Super Nintendo Entertainment System", ("snes",), True, ""),
        (("SGB", "SuperGameboy"), "Super Game Boy", ("gameboy", "snes"), True, ""),
        (("SuperVision", "PocketChallengeV2"), "Watara Supervision", ("supervision",), True, ""),
        (("SuperVision8000",), "Bandai Super Vision 8000", ("supervision8000",), True, ""),
        (("TomyTutor",), "Tomy Tutor", ("tomytutor",), True, ""),
        (("VC4000",), "Interton VC 4000", ("vc4000",), True, ""),
        (("Vectrex",), "GCE Vectrex", ("vectrex",), True, ""),
        (("WonderSwan", "WSwan"), "Bandai WonderSwan", ("wonderswan",), True, ""),
        (("WonderSwanColor", "WSwanC"), "Bandai WonderSwan Color", ("wonderswancolor",), True, ""),

        # Computers
        (("AcornAtom",), "Acorn Atom", ("atom", "acornatom"), True, ""),
        (("AcornElectron",), "Acorn Electron", ("electron", "acornelectron"), True, ""),
        (("Adam", "ColecoAdam"), "Coleco Adam", ("adam",), True, ""),
        (("AliceMC10",), "Matra & Hachette Alice MC-10", ("alice", "mc10"), True, ""),
        (("Altair8800",), "MITS Altair 8800", ("altair", "altair8800"), True, ""),
        (("Amiga", "Minimig"), "Commodore Amiga", ("amiga",), True, ""),
        (("AmigaCD32", "CD32"), "Commodore Amiga CD32", ("amigacd32",), True, ""),
        (("Amstrad", "AmstradCPC", "CPC"), "Amstrad CPC", ("amstradcpc",), True, ""),
        (("AmstradPCW",), "Amstrad PCW", ("amstradpcw",), True, ""),
        (("AO486", "PCXT", "Z386"), "DOS / IBM PC", ("dos", "pc"), True, "Computer disk images are scraped as DOS/PC titles."),
        (("Apogee",), "Apogee BK-01", (), False, "No matching ES-DE scraper platform is currently available."),
        (("Apple-I", "AppleI"), "Apple I", ("apple1",), True, ""),
        (("Apple-II", "AppleII"), "Apple II", ("apple2",), True, ""),
        (("Aquarius",), "Mattel Aquarius", ("aquarius",), True, ""),
        (("Archie", "Archimedes"), "Acorn Archimedes", ("archimedes",), True, ""),
        (("Arduboy",), "Arduboy", ("arduboy",), True, ""),
        (("Atari800",), "Atari 8-bit computers", ("atari800",), True, ""),
        (("AtariST",), "Atari ST", ("atarist",), True, ""),
        (("BBCMicro",), "BBC Micro", ("bbcmicro",), True, ""),
        (("BK0011M", "BK"), "Elektronika BK", ("bk", "bk0011m"), True, ""),
        (("C128",), "Commodore 128", ("c128",), True, ""),
        (("C16", "Plus4"), "Commodore 16 / Plus/4", ("plus4", "c16"), True, ""),
        (("C64", "Commodore64"), "Commodore 64", ("c64",), True, ""),
        (("CasioPV1000", "PV1000"), "Casio PV-1000", ("pv1000",), True, ""),
        (("CasioPV2000", "PV2000"), "Casio PV-2000", ("pv2000",), True, ""),
        (("CHIP8",), "CHIP-8", ("chip8",), True, ""),
        (("CoCo2",), "Tandy Color Computer 2", ("coco2", "coco"), True, ""),
        (("CoCo3",), "Tandy Color Computer 3", ("coco3", "coco"), True, ""),
        (("EDSAC",), "EDSAC", ("edsac",), True, ""),
        (("EG2000",), "Colour Genie EG2000", ("eg2000", "colorcomputer"), True, ""),
        (("Galaksija",), "Galaksija", ("galaksija",), True, ""),
        (("Homelab",), "HomeLab", ("homelab",), True, ""),
        (("Interact",), "Interact Home Computer", ("interact",), True, ""),
        (("Jupiter", "JupiterAce"), "Jupiter Ace", ("jupiterace",), True, ""),
        (("Laser", "Laser310"), "VTech Laser 310", ("laser310",), True, ""),
        (("Lynx48",), "Camputers Lynx", ("camputerslynx", "lynx48"), True, ""),
        (("MacPlus",), "Apple Macintosh Plus", ("macintosh", "macplus"), True, ""),
        (("MSX", "MSX1"), "MSX", ("msx",), True, ""),
        (("MSX2",), "MSX2", ("msx2",), True, ""),
        (("MultiComp",), "MultiComp", ("multicomp",), True, ""),
        (("OndraSPO186", "Ondra"), "Ondra SPO-186", ("ondra",), True, ""),
        (("Orao",), "Orao", ("orao",), True, ""),
        (("Oric",), "Oric", ("oric",), True, ""),
        (("PC88", "PC8801"), "NEC PC-8801", ("pc88",), True, ""),
        (("PDP1",), "PDP-1", ("pdp1",), True, ""),
        (("PET2001", "PET"), "Commodore PET", ("pet",), True, ""),
        (("PMD85",), "Tesla PMD 85", ("pmd85",), True, ""),
        (("QL", "SinclairQL"), "Sinclair QL", ("sinclairql", "ql"), True, ""),
        (("SAMCoupe",), "SAM Coupé", ("samcoupe",), True, ""),
        (("SharpMZ",), "Sharp MZ", ("sharpmz",), True, ""),
        (("SordM5",), "Sord M5", ("sordm5",), True, ""),
        (("Specialist",), "Specialist", ("specialist",), True, ""),
        (("SPMX",), "Specialist MX", ("specialist", "spmx"), True, ""),
        (("Spectrum", "ZXSpectrum"), "ZX Spectrum", ("zxspectrum",), True, ""),
        (("SVI328",), "Spectravideo SVI-328", ("spectravideo", "svi328"), True, ""),
        (("TatungEinstein",), "Tatung Einstein", ("einst", "tatungeinstein"), True, ""),
        (("TI994A", "TI99"), "Texas Instruments TI-99/4A", ("ti99",), True, ""),
        (("TRS80",), "Tandy TRS-80", ("trs80",), True, ""),
        (("TSConf",), "TS-Conf", ("zxspectrum", "tsconf"), True, "Scrapes against the closest ZX Spectrum platform."),
        (("UK101",), "Compukit UK101", ("uk101",), True, ""),
        (("Vector06", "Vector06C"), "Vector-06C", ("vector06c",), True, ""),
        (("VIC20",), "Commodore VIC-20", ("vic20",), True, ""),
        (("X68000",), "Sharp X68000", ("x68000",), True, ""),
        (("ZX81",), "Sinclair ZX81", ("zx81",), True, ""),
        (("ZXNext",), "ZX Spectrum Next", ("zxnext", "zxspectrum"), True, ""),

        # Known data/utility folders that are not game libraries.
        (("BIOS", "BootROM", "BootROMs"), "BIOS / boot ROM files", (), False, "System support files, not a game library."),
        (("Cheats",), "Cheat files", (), False, "Support files, not a game library."),
        (("Docs", "Documentation", "Manuals"), "Documentation", (), False, "Documentation folder, not a game library."),
        (("Media", "Images", "Screenshots", "Covers", "Videos"), "Existing media", (), False, "Media folder, not a game library."),
        (("Saves", "Save", "States"), "Save data", (), False, "Save data, not a game library."),
        (("MemTest", "InputTest", "MiSTerLaggy", "GameOfLife"), "Utility / test core", (), False, "Utility or test data, not a scrapeable game system."),
    )
    registry: dict[str, MisterFolderRule] = {}
    for aliases, display_name, esde_names, scrapeable, note in groups:
        rule = MisterFolderRule(display_name, esde_names, scrapeable, note)
        for alias in aliases:
            token = re.sub(r"[^a-z0-9]+", "", alias.lower())
            if token:
                registry[token] = rule
    return registry


MISTER_FOLDER_REGISTRY = _build_mister_folder_registry()

GENRE_RULES: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("fighting", ("fighting", "fighter", "versus")),
    ("racing", ("racing", "driving", "vehicle simulation", "kart")),
    ("rpg", ("role-playing", "role playing", "rpg", "jrpg", "action rpg", "tactical rpg")),
    ("puzzle", ("puzzle", "logic")),
    ("shooter", ("shooter", "shoot 'em up", "shoot-em-up", "shmup", "light gun", "run and gun")),
    ("platform", ("platform", "platformer")),
    ("sports", ("sports", "football", "baseball", "basketball", "soccer", "hockey", "golf", "tennis")),
    ("strategy", ("strategy", "real-time strategy", "turn-based strategy", "tower defense")),
    ("adventure", ("adventure", "visual novel", "point and click")),
    ("action", ("action", "hack and slash", "stealth", "beat 'em up", "beat-em-up", "brawler")),
)

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}
VIDEO_EXTENSIONS = {".mp4", ".mkv", ".avi", ".wmv", ".mov", ".webm", ".m4v"}

# Files that commonly live beside ROMs but should never be presented to ES-DE as games.
NON_GAME_SIDECAR_EXTENSIONS = {
    ".txt", ".nfo", ".md", ".pdf", ".doc", ".docx", ".rtf",
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".svg",
    ".mp4", ".mkv", ".avi", ".wmv", ".mov", ".webm", ".m4v",
    ".xml", ".json", ".csv", ".db", ".sqlite", ".ini", ".cfg",
    ".sav", ".srm", ".state", ".bak", ".log", ".url", ".lnk",
}


# Private placeholder used only inside the bridge-owned ES-DE scrape view.
# It lets a top-level disc-game folder behave like one ROM without exposing
# the folder's internal .cue/.bin/.chd/multi-disc files as separate games.
FOLDER_GAME_EXTENSION = ".crystalfolder"
IGNORED_GAME_FOLDER_NAMES = {
    "media", "images", "screenshots", "covers", "videos", "manuals",
    "saves", "save", "states", "bios", "docs", "documentation",
}

# Strong platform hints for formats ES-DE may not list natively.
EXTENSION_SYSTEM_HINTS: dict[str, set[str]] = {
    ".mra": {"arcade"},
}


def normalize_token(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", value.lower())


def canonical_system_id(*values: str) -> str:
    tokens = [normalize_token(v) for v in values if v]
    for token in tokens:
        if token in SYSTEM_ALIASES:
            return SYSTEM_ALIASES[token]
    for token in tokens:
        for alias, canonical in SYSTEM_ALIASES.items():
            if alias and (token.startswith(alias) or alias in token):
                return canonical
    return tokens[0] if tokens else "unknown"


def normalized_genre_tags(genre: str) -> list[str]:
    lower = " ".join(genre.lower().replace("/", " ").replace("_", " ").split())
    tags: list[str] = []
    for tag, needles in GENRE_RULES:
        if any(needle in lower for needle in needles):
            tags.append(tag)
    return tags


def safe_filename(value: str) -> str:
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value).strip().rstrip(".")
    return value or "Unknown System"


def parse_release_year(value: str) -> Optional[int]:
    if not value:
        return None
    match = re.match(r"\s*((?:19|20)\d{2})", value)
    if not match:
        return None
    year = int(match.group(1))
    return year if 1970 <= year <= 2099 else None


def parse_bool(value: str) -> bool:
    return value.strip().lower() in {"true", "1", "yes"}


def read_text(node: ET.Element, name: str) -> str:
    child = node.find(name)
    return (child.text or "").strip() if child is not None else ""


def _rom_name_from_path(value: str) -> tuple[str, str]:
    normalized = value.replace("\\", "/")
    while normalized.startswith("./"):
        normalized = normalized[2:]
    name = normalized.rsplit("/", 1)[-1]
    return normalized, name


def parse_player_range(value: str) -> tuple[Optional[int], Optional[int]]:
    numbers = [int(item) for item in re.findall(r"\d+", value)]
    if not numbers:
        return None, None
    return min(numbers), max(numbers)


def quest_system_groups(canonical_id: str) -> list[str]:
    groups: list[str] = []
    if canonical_id in {"snes", "genesis", "pcengine", "neogeo"}:
        groups.append("sixteen_bit_pilgrimage")
    if canonical_id in {"playstation", "saturn", "n64"}:
        groups.append("fifth_generation")
    if canonical_id in {"gameboy", "gameboycolor", "gameboyadvance", "gamegear"}:
        groups.append("handheld")
    if canonical_id in {"mastersystem", "genesis", "segacd", "sega32x", "saturn"}:
        groups.append("sega")
    if canonical_id == "arcade":
        groups.append("arcade")
    if canonical_id in {"3do", "jaguar"}:
        groups.append("fallen_titans")
    return groups


def parse_gamelist(gamelist_path: Path, system: SystemEntry) -> dict:
    result = {
        "schema": SCHEMA_VERSION,
        "created_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "generator": {"name": APP_NAME, "version": APP_VERSION},
        "system": {
            "esde_name": system.name,
            "full_name": system.full_name,
            "canonical_id": system.canonical_id,
            "quest_groups": quest_system_groups(system.canonical_id),
            "rom_path_template": system.rom_path,
        },
        "games": [],
    }
    if not gamelist_path.is_file():
        return result
    tree = ET.parse(gamelist_path)
    root = tree.getroot()
    for node in root.findall("game"):
        raw_path = read_text(node, "path")
        relative_path, rom_name = _rom_name_from_path(raw_path)
        stem = Path(rom_name).stem
        genre = read_text(node, "genre")
        rating_text = read_text(node, "rating")
        try:
            rating_01 = float(rating_text) if rating_text else None
        except ValueError:
            rating_01 = None
        if rating_01 is not None:
            rating_01 = min(1.0, max(0.0, rating_01))
        player_min, player_max = parse_player_range(read_text(node, "players"))
        release_year = parse_release_year(read_text(node, "releasedate"))
        game = {
            "rom_relative_path": relative_path,
            "rom_filename": rom_name,
            "rom_stem": stem,
            "title": read_text(node, "name") or stem,
            "description": read_text(node, "desc"),
            "release_date": read_text(node, "releasedate"),
            "release_year": release_year,
            "release_decade": (release_year // 10) * 10 if release_year else None,
            "developer": read_text(node, "developer"),
            "publisher": read_text(node, "publisher"),
            "genre": genre,
            "genre_tags": normalized_genre_tags(genre),
            "players": read_text(node, "players"),
            "player_min": player_min,
            "player_max": player_max,
            "rating_0_to_1": rating_01,
            "rating_0_to_5": round(rating_01 * 5, 2) if rating_01 is not None else None,
            "favorite": parse_bool(read_text(node, "favorite")),
            "kidgame": parse_bool(read_text(node, "kidgame")),
        }
        result["games"].append(game)
    result["games"].sort(key=lambda g: (g["rom_relative_path"].lower(), g["title"].lower()))
    return result



def find_esde_systems_xml(executable: Path) -> Optional[Path]:
    if not executable.is_file():
        return None
    exe_dir = executable.parent
    candidates = [
        exe_dir / "resources" / "systems" / "windows" / "es_systems.xml",
        exe_dir.parent / "resources" / "systems" / "windows" / "es_systems.xml",
        exe_dir / "resources" / "systems" / "es_systems.xml",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


def load_esde_systems(executable: Path) -> list[SystemEntry]:
    xml_path = find_esde_systems_xml(executable)
    if xml_path is None:
        raise FileNotFoundError("Could not locate ES-DE resources/systems/windows/es_systems.xml beside that executable.")
    root = ET.parse(xml_path).getroot()
    systems: list[SystemEntry] = []
    for node in root.findall("system"):
        name = read_text(node, "name")
        full_name = read_text(node, "fullname") or name
        rom_path = read_text(node, "path")
        ext_text = read_text(node, "extension")
        extensions = tuple(sorted({item.lower() for item in ext_text.split() if item.startswith(".")}))
        if not name or not rom_path:
            continue
        systems.append(
            SystemEntry(
                name=name,
                full_name=full_name,
                rom_path=rom_path,
                extensions=extensions,
                outer_xml=ET.tostring(node, encoding="unicode"),
                source_xml=str(xml_path),
            )
        )
    systems.sort(key=lambda item: (item.full_name.lower(), item.name.lower()))
    return systems


def count_matching_roms(folder: Path, system: SystemEntry, recursive: bool = True) -> int:
    if not folder.is_dir() or not system.extensions:
        return 0
    iterator = folder.rglob("*") if recursive else folder.glob("*")
    return sum(1 for item in iterator if item.is_file() and item.suffix.lower() in system.extensions)


def _folder_has_game_content(folder: Path, system: SystemEntry) -> bool:
    """Return True when a top-level folder contains at least one likely game file."""
    try:
        for item in folder.rglob("*"):
            if not item.is_file():
                continue
            suffix = item.suffix.lower()
            if suffix and suffix not in NON_GAME_SIDECAR_EXTENSIONS and suffix in system.extensions:
                return True
    except OSError:
        return False
    return False


def discover_folder_games(folder: Path, system: SystemEntry) -> list[Path]:
    """Discover top-level directories that should be represented as one game each."""
    if not folder.is_dir():
        return []
    games: list[Path] = []
    try:
        children = sorted(folder.iterdir(), key=lambda item: item.name.lower())
    except OSError:
        return []
    for child in children:
        if not child.is_dir() or is_reparse_point(child):
            continue
        token = child.name.strip().lower()
        if not token or token.startswith('.') or token in IGNORED_GAME_FOLDER_NAMES:
            continue
        if _folder_has_game_content(child, system):
            games.append(child)
    return games


def discover_direct_game_files(folder: Path, system: SystemEntry) -> list[Path]:
    if not folder.is_dir():
        return []
    try:
        return [
            item for item in sorted(folder.iterdir(), key=lambda item: item.name.lower())
            if item.is_file() and item.suffix.lower() in system.extensions
        ]
    except OSError:
        return []


def count_game_entries(folder: Path, system: SystemEntry) -> int:
    """Count user-visible games, collapsing each qualifying top-level folder to one entry."""
    return len(discover_game_records(folder, system))


def discover_game_records(folder: Path, system: SystemEntry) -> list[GameRecord]:
    """Return the real user-visible games in a MiSTer system folder.

    Top-level disc folders become one game. Ordinary systems retain relative paths so
    Smart Resume can match the finished gamelist.xml without relying on scraped names.
    """
    if not folder.is_dir():
        return []
    folder_games = discover_folder_games(folder, system)
    records: list[GameRecord] = []
    if folder_games:
        for item in discover_direct_game_files(folder, system):
            records.append(GameRecord(item.name.replace('\\', '/'), item.stem, False))
        for game_folder in folder_games:
            records.append(GameRecord(game_folder.name.replace('\\', '/'), game_folder.name, True))
    else:
        try:
            for item in sorted(folder.rglob('*'), key=lambda path: str(path).lower()):
                if not item.is_file() or is_reparse_point(item):
                    continue
                if item.suffix.lower() not in system.extensions:
                    continue
                relative = item.relative_to(folder).as_posix()
                records.append(GameRecord(relative, item.stem, False))
        except OSError:
            return []
    unique: dict[str, GameRecord] = {}
    for record in records:
        unique.setdefault(_normalized_gamelist_key(record.relative_path), record)
    return sorted(unique.values(), key=lambda record: record.relative_path.casefold())


def _gamelist_path_set(path: Path) -> set[str]:
    if not path.is_file():
        return set()
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError):
        return set()
    result: set[str] = set()
    for game in root.findall('game'):
        node = game.find('path')
        if node is not None and node.text:
            result.add(_normalized_gamelist_key(node.text))
    return result


def _expected_finished_media(
    output_root: Path,
    record: GameRecord,
    options: PackageOptions,
) -> list[Path]:
    media = output_root / 'media'
    stem = record.display_stem
    selected = set(options.selected_media)
    expected: list[Path] = []
    if options.export_format == 'console_mode':
        if 'covers' in selected:
            expected.append(media / f'{stem}.png')
        if 'screenshots' in selected:
            expected.append(media / f'{stem}-BG.png')
        return expected
    if 'covers' in selected:
        expected.append(media / f'{stem}.png')
    if 'screenshots' in selected:
        expected.append(media / 'BG' / f'{stem}.png')
    if 'backcovers' in selected:
        expected.append(media / 'BC' / f'{stem}.png')
    if 'physicalmedia' in selected:
        expected.append(media / 'PM' / f'{stem}.png')
    if 'videos' in selected:
        expected.append(media / 'videos' / f'{stem}.cfv')
    if 'manuals' in selected:
        expected.append(media / 'manuals' / f'{stem}.pdf')
    if options.include_gallery_art:
        for media_type in ('marquees', 'titlescreens', 'fanart', 'miximages', '3dboxes'):
            if media_type in selected:
                expected.append(media / media_type / f'{stem}.png')
    return expected


def analyze_smart_resume(
    rom_folder: Path,
    system: SystemEntry,
    output_root: Path,
    options: PackageOptions,
    *,
    require_gamelist: bool = True,
    adapt_extensions: bool = True,
) -> SmartResumeReport:
    """Compare the live MiSTer library against finished CRysTal/Console output.

    No private ES-DE cache is needed. The real ROM paths, finished gamelist.xml and
    selected media files are the complete source of truth.
    """
    adapted = extension_compatible_system(rom_folder, system)[0] if adapt_extensions else system
    records = discover_game_records(rom_folder, adapted)
    gamelist = output_root / 'media' / 'gamelist.xml'
    listed = _gamelist_path_set(gamelist)
    complete: list[GameRecord] = []
    new: list[GameRecord] = []
    incomplete: list[GameRecord] = []
    current_keys = {_normalized_gamelist_key(record.relative_path) for record in records}
    for record in records:
        key = _normalized_gamelist_key(record.relative_path)
        if require_gamelist and key not in listed:
            new.append(record)
            continue
        expected = _expected_finished_media(output_root, record, options)
        if any(not path.is_file() for path in expected):
            incomplete.append(record)
        else:
            complete.append(record)
    orphaned = tuple(sorted(listed - current_keys))
    return SmartResumeReport(
        total=len(records),
        complete=tuple(complete),
        new=tuple(new),
        incomplete=tuple(incomplete),
        orphaned_paths=orphaned,
    )


def build_selective_game_catalog(
    source_folder: Path,
    catalog_folder: Path,
    system: SystemEntry,
    selected_relative_paths: Sequence[str],
) -> tuple[SystemEntry, dict[str, str], int]:
    """Create a zero-byte ES-DE view containing only selected real games."""
    selected = {_normalized_gamelist_key(value) for value in selected_relative_paths}
    records = [record for record in discover_game_records(source_folder, system)
               if _normalized_gamelist_key(record.relative_path) in selected]
    if catalog_folder.exists():
        shutil.rmtree(catalog_folder)
    catalog_folder.mkdir(parents=True, exist_ok=True)
    path_map: dict[str, str] = {}
    used: set[str] = set()
    for record in records:
        if record.is_folder:
            relative = Path(record.display_stem + FOLDER_GAME_EXTENSION)
        else:
            relative = Path(record.relative_path)
        candidate = relative
        serial = 2
        while candidate.as_posix().casefold() in used:
            candidate = relative.with_name(f'{relative.stem}__bridge{serial}{relative.suffix}')
            serial += 1
        used.add(candidate.as_posix().casefold())
        destination = catalog_folder / candidate
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(b'')
        private_key = candidate.as_posix().casefold()
        real_path = record.relative_path.replace('\\', '/')
        if private_key != _normalized_gamelist_key(real_path):
            path_map[private_key] = real_path
            path_map[candidate.name.casefold()] = real_path
    accepted = tuple(sorted(set(system.extensions).union({FOLDER_GAME_EXTENSION})))
    return replace(system, extensions=accepted), path_map, len(records)


def build_folder_game_catalog(
    source_folder: Path,
    catalog_folder: Path,
    system: SystemEntry,
) -> tuple[SystemEntry, dict[str, str], int]:
    """Create a bridge-owned filename-only view for disc-folder libraries.

    Zero-byte placeholders are sufficient because private ES-DE only needs filenames
    for scraping. Source ROMs are never copied, opened, renamed, or modified.
    """
    folder_games = discover_folder_games(source_folder, system)
    if not folder_games:
        return system, {}, 0
    if catalog_folder.exists():
        shutil.rmtree(catalog_folder)
    catalog_folder.mkdir(parents=True, exist_ok=True)
    path_map: dict[str, str] = {}
    used: set[str] = set()

    for source in discover_direct_game_files(source_folder, system):
        name = source.name
        key = name.casefold()
        if key in used:
            continue
        used.add(key)
        (catalog_folder / name).write_bytes(b"")

    for game_folder in folder_games:
        placeholder_name = game_folder.name + FOLDER_GAME_EXTENSION
        candidate = placeholder_name
        serial = 2
        while candidate.casefold() in used:
            candidate = f"{game_folder.name}__folder{serial}{FOLDER_GAME_EXTENSION}"
            serial += 1
        used.add(candidate.casefold())
        (catalog_folder / candidate).write_bytes(b"")
        path_map[candidate.replace('\\', '/').casefold()] = game_folder.name.replace('\\', '/')

    accepted = tuple(sorted(set(system.extensions).union({FOLDER_GAME_EXTENSION})))
    return replace(system, extensions=accepted), path_map, len(used)


def _normalized_gamelist_key(value: str) -> str:
    normalized = value.replace('\\', '/')
    while normalized.startswith('./'):
        normalized = normalized[2:]
    return normalized.casefold()


def rewrite_gamelist_paths(source: Path, destination: Path, path_map: dict[str, str]) -> None:
    """Atomically copy a gamelist while mapping private placeholders to real folders."""
    if not path_map:
        _atomic_copy(source, destination)
        return
    tree = ET.parse(source)
    root = tree.getroot()
    for node in root.findall('game'):
        path_node = node.find('path')
        if path_node is None or not path_node.text:
            continue
        normalized_key = _normalized_gamelist_key(path_node.text)
        mapped = path_map.get(normalized_key)
        if mapped is None:
            mapped = path_map.get(Path(normalized_key).name.casefold())
        if mapped is not None:
            path_node.text = './' + mapped.replace('\\', '/')
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.name}.{uuid.uuid4().hex}.tmp")
    try:
        tree.write(temporary, encoding='utf-8', xml_declaration=True)
        temporary.replace(destination)
    finally:
        temporary.unlink(missing_ok=True)




def merge_gamelist_paths(source: Path, destination: Path, path_map: dict[str, str]) -> None:
    """Merge a selective scrape into an existing gamelist without losing old games."""
    source_tree = ET.parse(source)
    source_root = source_tree.getroot()
    for node in source_root.findall('game'):
        path_node = node.find('path')
        if path_node is None or not path_node.text:
            continue
        key = _normalized_gamelist_key(path_node.text)
        mapped = path_map.get(key) or path_map.get(Path(key).name.casefold())
        if mapped is not None:
            path_node.text = './' + mapped.replace('\\', '/')
    if destination.is_file():
        try:
            destination_tree = ET.parse(destination)
            destination_root = destination_tree.getroot()
        except (ET.ParseError, OSError):
            destination_tree = ET.ElementTree(ET.Element('gameList'))
            destination_root = destination_tree.getroot()
    else:
        destination_tree = ET.ElementTree(ET.Element('gameList'))
        destination_root = destination_tree.getroot()
    existing: dict[str, ET.Element] = {}
    for game in list(destination_root.findall('game')):
        path_node = game.find('path')
        if path_node is not None and path_node.text:
            existing[_normalized_gamelist_key(path_node.text)] = game
    for game in source_root.findall('game'):
        path_node = game.find('path')
        if path_node is None or not path_node.text:
            continue
        key = _normalized_gamelist_key(path_node.text)
        old = existing.get(key)
        if old is not None:
            index = list(destination_root).index(old)
            destination_root.remove(old)
            destination_root.insert(index, game)
        else:
            destination_root.append(game)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f'.{destination.name}.{uuid.uuid4().hex}.tmp')
    try:
        destination_tree.write(temporary, encoding='utf-8', xml_declaration=True)
        temporary.replace(destination)
    finally:
        temporary.unlink(missing_ok=True)


def scan_source_extensions(folder: Path, recursive: bool = True) -> dict[str, int]:
    counts: dict[str, int] = {}
    if not folder.is_dir():
        return counts
    iterator = folder.rglob("*") if recursive else folder.glob("*")
    try:
        for item in iterator:
            if not item.is_file():
                continue
            suffix = item.suffix.lower()
            if not suffix or suffix in NON_GAME_SIDECAR_EXTENSIONS:
                continue
            counts[suffix] = counts.get(suffix, 0) + 1
    except OSError:
        return counts
    return dict(sorted(counts.items(), key=lambda pair: (-pair[1], pair[0])))


def extension_compatible_system(folder: Path, system: SystemEntry) -> tuple[SystemEntry, ExtensionCompatibility]:
    """Privately teach ES-DE to accept the source folder's real game extensions.

    This is an isolated-config masquerade only: source files are not renamed, copied,
    converted, or modified. It is especially useful for MiSTer Arcade .mra files.
    """
    counts = scan_source_extensions(folder)
    original = tuple(sorted({ext.lower() for ext in system.extensions}))
    actual = tuple(sorted(counts))
    accepted = tuple(sorted(set(original).union(actual)))
    added = tuple(ext for ext in accepted if ext not in original)
    adapted = replace(system, extensions=accepted)
    report = ExtensionCompatibility(
        original_extensions=original,
        accepted_extensions=accepted,
        added_extensions=added,
        counts=counts,
        game_file_count=sum(counts.values()),
    )
    return adapted, report


def _extension_xml_tokens(extensions: Sequence[str]) -> str:
    tokens: list[str] = []
    seen: set[str] = set()
    for extension in extensions:
        normalized = extension if extension.startswith(".") else f".{extension}"
        for token in (normalized.lower(), normalized.upper()):
            if token not in seen:
                seen.add(token)
                tokens.append(token)
    return " ".join(tokens)


def _system_name_score(folder_token: str, system: SystemEntry) -> int:
    tokens = {
        normalize_token(system.name),
        normalize_token(system.full_name),
        normalize_token(system.system_folder),
        normalize_token(system.canonical_id),
    }
    if folder_token in tokens:
        return 100
    if any(folder_token and (folder_token in token or token in folder_token) for token in tokens):
        return 55
    return 0


def suggest_system_from_name(folder: Path, systems: Sequence[SystemEntry]) -> Optional[SystemEntry]:
    """Fast MiSTer-oriented match that never walks the ROM tree."""
    if not systems:
        return None
    folder_token = normalize_token(folder.name)
    scored = [(_system_name_score(folder_token, system), system) for system in systems]
    scored.sort(key=lambda item: (item[0], item[1].full_name.lower()), reverse=True)
    return scored[0][1] if scored and scored[0][0] > 0 else None


def suggest_system(folder: Path, systems: Sequence[SystemEntry]) -> Optional[SystemEntry]:
    if not systems:
        return None
    folder_token = normalize_token(folder.name)

    # Normal MiSTer folders are already named after their platform. Avoid touching
    # thousands of ROM files when the directory name gives us a confident answer.
    name_match = suggest_system_from_name(folder, systems)
    if name_match is not None:
        return name_match

    suffixes: dict[str, int] = {}
    if folder.is_dir():
        try:
            files = itertools.islice((item for item in folder.rglob("*") if item.is_file()), 3000)
            for item in files:
                suffix = item.suffix.lower()
                suffixes[suffix] = suffixes.get(suffix, 0) + 1
        except OSError:
            suffixes = {}

    scored: list[tuple[int, int, SystemEntry]] = []
    for system in systems:
        name_score = _system_name_score(folder_token, system)
        extension_score = sum(suffixes.get(ext, 0) for ext in system.extensions)
        for extension, hinted_systems in EXTENSION_SYSTEM_HINTS.items():
            if system.canonical_id in hinted_systems:
                extension_score += suffixes.get(extension, 0) * 4
        scored.append((name_score, extension_score, system))
    scored.sort(key=lambda item: (item[0], item[1], item[2].full_name.lower()), reverse=True)
    best = scored[0]
    return best[2] if best[0] > 0 or best[1] > 0 else None


def has_likely_game_content(folder: Path, *, max_files: int = 512) -> bool:
    """Bounded presence check used by UI discovery.

    This deliberately avoids a full recursive count. Exact counting and Smart Resume
    run later on a worker thread after the user selects a system.
    """
    if not folder.is_dir():
        return False
    seen_files = 0
    try:
        for current, directories, files in os.walk(folder):
            directories[:] = [
                name for name in directories
                if name.strip().lower() not in IGNORED_GAME_FOLDER_NAMES and not name.startswith('.')
            ]
            for name in files:
                seen_files += 1
                suffix = Path(name).suffix.lower()
                if suffix and suffix not in NON_GAME_SIDECAR_EXTENSIONS:
                    return True
                if seen_files >= max_files:
                    return False
    except OSError:
        return False
    return False


MISTER_IGNORED_GAMES_FOLDERS = {
    'mame', 'hbmame', 'media', 'saves', 'save', 'states', 'bios', 'cheats',
    'docs', 'documentation', 'games', 'cores', 'bootrom', 'bootroms',
}


def resolve_mister_fat_root(root: Path) -> Optional[Path]:
    """Return the MiSTer FAT data root without walking any game directory.

    A selection may point at the card/share root, ``media``, ``fat``, ``games``
    itself, or a legacy direct card root. CRysTal prefers the real MiSTer layout
    ``media\\fat\\games`` and falls back only for older/direct mounts.
    """
    if not root.is_dir():
        return None
    candidates: list[Path] = []
    name = root.name.strip().lower()
    if name == 'games':
        candidates.append(root.parent)
    if name == 'fat':
        candidates.append(root)
    if name == 'media':
        candidates.append(root / 'fat')
    candidates.extend((
        root / 'media' / 'fat',
        root / 'fat',
        root,
    ))
    seen: set[str] = set()
    for candidate in candidates:
        key = os.path.normcase(str(candidate))
        if key in seen:
            continue
        seen.add(key)
        if (candidate / 'games').is_dir():
            return candidate
    return None


def looks_like_mister_root(root: Path) -> bool:
    fat_root = resolve_mister_fat_root(root)
    if fat_root is not None:
        return True
    return root.is_dir() and (
        (root / '_Arcade').is_dir()
        or (root / '_DOS Games').is_dir()
        or (root / 'MiSTer').is_file()
        or (root / 'menu.rbf').is_file()
    )

def _system_by_canonical(systems: Sequence[SystemEntry], canonical: str) -> Optional[SystemEntry]:
    matches = [system for system in systems if system.canonical_id == canonical]
    if not matches:
        return None
    matches.sort(key=lambda system: (0 if normalize_token(system.name) == canonical else 1, system.full_name.lower()))
    return matches[0]



def _mister_system_indexes(systems: Sequence[SystemEntry]) -> dict[str, dict[str, SystemEntry]]:
    indexes: dict[str, dict[str, SystemEntry]] = {
        "name": {}, "folder": {}, "platform": {}, "canonical": {}, "full": {},
    }
    for system in systems:
        values = {
            "name": (system.name,),
            "folder": (system.system_folder,),
            "canonical": (system.canonical_id,),
            "full": (system.full_name,),
        }
        for category, items in values.items():
            for value in items:
                token = normalize_token(value)
                if token:
                    indexes[category].setdefault(token, system)
        try:
            node = ET.fromstring(system.outer_xml)
            platform_text = (node.findtext("platform") or "").strip()
        except (ET.ParseError, ValueError):
            platform_text = ""
        for value in re.split(r"[,;]", platform_text):
            token = normalize_token(value)
            if token:
                indexes["platform"].setdefault(token, system)
    return indexes


def resolve_mister_folder_system(
    folder_name: str,
    systems: Sequence[SystemEntry],
    indexes: Optional[dict[str, dict[str, SystemEntry]]] = None,
) -> tuple[Optional[MisterFolderRule], Optional[SystemEntry], str]:
    """Resolve a stable MiSTer folder name without reading a single ROM.

    Known MiSTer names use the explicit registry first. Unknown names receive only
    exact ES-DE name/folder/canonical matching; fuzzy substring matching is never
    used during SD-card discovery.
    """
    token = normalize_token(folder_name)
    rule = MISTER_FOLDER_REGISTRY.get(token)
    indexes = indexes or _mister_system_indexes(systems)
    if rule is not None:
        if not rule.scrapeable:
            return rule, None, rule.note or "This is not a scrapeable game library."
        for target in rule.esde_names:
            target_token = normalize_token(target)
            for category in ("name", "folder", "platform", "canonical", "full"):
                match = indexes[category].get(target_token)
                if match is not None:
                    return rule, match, rule.note
        note = rule.note
        missing = "Known MiSTer platform, but this ES-DE build has no matching system definition loaded."
        return rule, None, f"{note} {missing}".strip()

    for category in ("name", "folder", "canonical", "platform", "full"):
        match = indexes[category].get(token)
        if match is not None:
            generated = MisterFolderRule(match.full_name, (match.name,), True, "Exact ES-DE folder-name match.")
            return generated, match, generated.note
    return None, None, "Unknown MiSTer folder. Choose the ES-DE system manually."


def discover_mister_system_folders(
    root: Path,
    systems: Sequence[SystemEntry],
    progress: Optional[ProgressFn] = None,
) -> list[MisterSystemCandidate]:
    """List MiSTer system folders instantly, without opening any of them.

    Discovery reads only the immediate children of ``media/fat/games`` and checks
    the two known special roots beside it. ROM detection, extension probing, exact
    counts and Smart Resume are deliberately deferred until the user chooses a
    system (or starts a Pro job).
    """
    fat_root = resolve_mister_fat_root(root)
    if fat_root is None:
        return []

    games_root = fat_root / 'games'
    try:
        children = sorted(
            (path for path in games_root.iterdir() if path.is_dir()),
            key=lambda path: path.name.lower(),
        )
    except OSError:
        children = []

    work: list[tuple[str, Path]] = [('games', folder) for folder in children]
    work.extend([('arcade', fat_root / '_Arcade'), ('0mhz', fat_root / '_DOS Games')])
    total = max(1, len(work))
    found: list[MisterSystemCandidate] = []

    # Build exact indexes once. The explicit MiSTer registry handles abbreviations
    # such as PSX, TGFX16-CD and MegaCD without extension probing or fuzzy guesses.
    system_indexes = _mister_system_indexes(systems)

    for index, (kind, folder) in enumerate(work, start=1):
        if progress:
            progress(index, total, folder.name)
        if not folder.is_dir():
            continue
        if kind == 'games':
            # Folder discovery must be literal and lossless. Every immediate
            # directory under media/fat/games is shown to the user, even when its
            # name is unfamiliar to our alias table. System recognition is only a
            # suggestion attached afterward; it never decides folder visibility.
            rule, match, note = resolve_mister_folder_system(folder.name, systems, system_indexes)
            known_name = rule.display_name if rule is not None else ""
            scrapeable = rule.scrapeable if rule is not None else True
            found.append(MisterSystemCandidate(
                folder.name, folder, match, 'games', known_name, note, scrapeable
            ))
            continue
        if kind == 'arcade':
            rule, match, note = resolve_mister_folder_system('Arcade', systems, system_indexes)
            found.append(MisterSystemCandidate(
                'Arcade', folder, match, 'arcade', 'Arcade', note, True
            ))
            continue
        rule, match, note = resolve_mister_folder_system('AO486', systems, system_indexes)
        found.append(MisterSystemCandidate(
            '0MHz DOS Games', folder, match, '0mhz', 'DOS / IBM PC', note, True
        ))

    unique: dict[str, MisterSystemCandidate] = {}
    for candidate in found:
        unique[os.path.normcase(os.path.abspath(str(candidate.folder)))] = candidate
    return sorted(unique.values(), key=lambda item: (item.kind != 'arcade', item.kind != '0mhz', item.label.lower()))


FFMPEG_RELEASE_URL = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
FFMPEG_RELEASE_SHA256_URL = FFMPEG_RELEASE_URL + ".sha256"
FFMPEG_DOWNLOAD_USER_AGENT = f"{APP_NAME}/{APP_VERSION}"

ESDE_RELEASES_API_URL = "https://gitlab.com/api/v4/projects/es-de%2Femulationstation-de/releases?per_page=20"
ESDE_PROJECT_RELEASES_URL = "https://gitlab.com/es-de/emulationstation-de/-/releases"
SCREENSCRAPER_SIGNUP_URL = "https://www.screenscraper.fr/membreinscription.php"
DOWNLOAD_USER_AGENT = f"{APP_NAME}/{APP_VERSION} (Windows; managed tools installer)"


def managed_ffmpeg_root(app_root: Path) -> Path:
    return BridgeLocations.default(app_root).data_root / "Tools" / "FFmpeg"


def managed_ffmpeg_executable(app_root: Path) -> Path:
    return managed_ffmpeg_root(app_root) / "bin" / "ffmpeg.exe"


def is_managed_ffmpeg(path: Optional[Path], app_root: Path) -> bool:
    if path is None:
        return False
    try:
        path.resolve().relative_to(managed_ffmpeg_root(app_root).resolve())
        return True
    except (OSError, ValueError):
        return False


def ffmpeg_version_text(executable: Path) -> str:
    try:
        result = subprocess.run(
            [str(executable), "-version"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            timeout=15, check=False, creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    first = (result.stdout or "").splitlines()
    return first[0].strip() if result.returncode == 0 and first else ""


def _download_to_file(
    url: str,
    destination: Path,
    *,
    progress: ProgressFn = _noop_progress,
    opener=urllib.request.urlopen,
) -> None:
    request = urllib.request.Request(url, headers={"User-Agent": FFMPEG_DOWNLOAD_USER_AGENT})
    try:
        response = opener(request, timeout=45)
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Could not download FFmpeg: {exc.reason}") from exc
    with response:
        total = int(response.headers.get("Content-Length") or 0)
        current = 0
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("wb") as handle:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                handle.write(chunk)
                current += len(chunk)
                progress(current, total or max(current, 1), "Downloading FFmpeg")
    if not destination.is_file() or destination.stat().st_size < 1024:
        raise RuntimeError("The FFmpeg download was empty or incomplete.")


def _download_text(url: str, *, opener=urllib.request.urlopen) -> str:
    request = urllib.request.Request(url, headers={"User-Agent": FFMPEG_DOWNLOAD_USER_AGENT})
    try:
        response = opener(request, timeout=30)
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Could not download the FFmpeg checksum: {exc.reason}") from exc
    with response:
        return response.read(8192).decode("utf-8", errors="replace")


def _published_sha256(text: str) -> str:
    match = re.search(r"(?i)\b([0-9a-f]{64})\b", text)
    if not match:
        raise RuntimeError("The FFmpeg publisher checksum could not be read.")
    return match.group(1).lower()


def _safe_zip_member(member: str) -> bool:
    normalized = member.replace("\\", "/")
    path = Path(normalized)
    return not path.is_absolute() and ".." not in path.parts


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().lower()


def install_managed_ffmpeg_from_archive(
    *,
    app_root: Path,
    archive: Path,
    expected_sha256: str,
    source_url: str = FFMPEG_RELEASE_URL,
    verify_executable: bool = True,
    log: LogFn = _noop_log,
) -> Path:
    actual = _sha256_file(archive)
    if actual != expected_sha256.lower():
        raise RuntimeError("FFmpeg checksum verification failed. Nothing was installed.")

    target_root = managed_ffmpeg_root(app_root)
    target_root.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix="FFmpeg.install.", dir=str(target_root.parent)))
    backup = target_root.with_name(target_root.name + ".previous")
    try:
        with zipfile.ZipFile(archive, "r") as bundle:
            members = [info for info in bundle.infolist() if _safe_zip_member(info.filename)]
            ffmpeg_info = next((info for info in members if info.filename.replace("\\", "/").lower().endswith("/bin/ffmpeg.exe")), None)
            ffprobe_info = next((info for info in members if info.filename.replace("\\", "/").lower().endswith("/bin/ffprobe.exe")), None)
            if ffmpeg_info is None:
                raise RuntimeError("The downloaded FFmpeg package did not contain ffmpeg.exe.")
            bin_dir = staging / "bin"
            bin_dir.mkdir(parents=True, exist_ok=True)
            for info, name in ((ffmpeg_info, "ffmpeg.exe"), (ffprobe_info, "ffprobe.exe")):
                if info is None:
                    continue
                with bundle.open(info, "r") as source, (bin_dir / name).open("wb") as destination:
                    shutil.copyfileobj(source, destination)

        executable = staging / "bin" / "ffmpeg.exe"
        if verify_executable and not ffmpeg_version_text(executable):
            raise RuntimeError("The downloaded ffmpeg.exe could not be started. Nothing was installed.")

        info = {
            "source": source_url,
            "sha256": actual,
            "installed_at_utc": datetime.now(timezone.utc).isoformat(),
            "version": ffmpeg_version_text(executable) if verify_executable else "test-package",
        }
        (staging / "INSTALL_INFO.json").write_text(json.dumps(info, indent=2), encoding="utf-8")

        if backup.exists():
            shutil.rmtree(backup, ignore_errors=True)
        if target_root.exists():
            target_root.replace(backup)
        try:
            staging.replace(target_root)
        except Exception:
            if backup.exists() and not target_root.exists():
                backup.replace(target_root)
            raise
        shutil.rmtree(backup, ignore_errors=True)
        installed = managed_ffmpeg_executable(app_root)
        log(f"Managed FFmpeg installed: {installed}")
        return installed
    finally:
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)


def install_managed_ffmpeg(
    app_root: Path,
    *,
    log: LogFn = _noop_log,
    progress: ProgressFn = _noop_progress,
    opener=urllib.request.urlopen,
) -> Path:
    tools_root = BridgeLocations.default(app_root).data_root / "Downloads"
    tools_root.mkdir(parents=True, exist_ok=True)
    archive = tools_root / "ffmpeg-release-essentials.zip.download"
    try:
        progress(0, 1, "Reading publisher checksum")
        expected = _published_sha256(_download_text(FFMPEG_RELEASE_SHA256_URL, opener=opener))
        _download_to_file(FFMPEG_RELEASE_URL, archive, progress=progress, opener=opener)
        progress(1, 1, "Verifying and installing FFmpeg")
        return install_managed_ffmpeg_from_archive(
            app_root=app_root, archive=archive, expected_sha256=expected,
            verify_executable=True, log=log,
        )
    finally:
        archive.unlink(missing_ok=True)


def uninstall_managed_ffmpeg(app_root: Path, *, log: LogFn = _noop_log) -> bool:
    root = managed_ffmpeg_root(app_root)
    if not root.exists():
        return False
    shutil.rmtree(root)
    log("Managed FFmpeg removed. External or system FFmpeg installations were not changed.")
    return True


def resolve_ffmpeg(preferred: Optional[Path], app_root: Path) -> Optional[Path]:
    if preferred and preferred.is_file():
        return preferred
    managed = managed_ffmpeg_executable(app_root)
    if managed.is_file():
        return managed
    local = app_root / "ffmpeg.exe"
    if local.is_file():
        return local
    found = shutil.which("ffmpeg.exe") or shutil.which("ffmpeg")
    return Path(found) if found else None



def managed_esde_root(app_root: Path) -> Path:
    return BridgeLocations.default(app_root).data_root / "Tools" / "ES-DE"


def _find_esde_executable_under(root: Path) -> Optional[Path]:
    if not root.is_dir():
        return None
    preferred_names = ("ES-DE.exe", "es-de.exe", "ES-DE_x64.exe")
    direct = [root / name for name in preferred_names]
    recursive: list[Path] = []
    for name in preferred_names:
        recursive.extend(root.rglob(name))
    seen: set[str] = set()
    for candidate in direct + recursive:
        key = os.path.normcase(str(candidate.resolve(strict=False)))
        if key in seen:
            continue
        seen.add(key)
        if candidate.is_file() and find_esde_systems_xml(candidate) is not None:
            return candidate
    return None


def managed_esde_executable(app_root: Path) -> Path:
    found = _find_esde_executable_under(managed_esde_root(app_root))
    return found if found is not None else managed_esde_root(app_root) / "ES-DE.exe"


def is_managed_esde(path: Optional[Path], app_root: Path) -> bool:
    if path is None:
        return False
    try:
        path.resolve(strict=False).relative_to(managed_esde_root(app_root).resolve(strict=False))
        return True
    except (OSError, ValueError):
        return False


def _http_text(url: str, *, label: str, opener=urllib.request.urlopen, limit: int = 4 * 1024 * 1024) -> str:
    request = urllib.request.Request(url, headers={"User-Agent": DOWNLOAD_USER_AGENT, "Accept": "application/json,text/plain,*/*"})
    try:
        response = opener(request, timeout=45)
    except urllib.error.URLError as exc:
        reason = getattr(exc, "reason", exc)
        raise RuntimeError(f"Could not contact {label}: {reason}") from exc
    with response:
        data = response.read(limit + 1)
    if len(data) > limit:
        raise RuntimeError(f"The response from {label} was unexpectedly large.")
    return data.decode("utf-8", errors="replace")


def _download_named_file(
    url: str,
    destination: Path,
    *,
    label: str,
    progress: ProgressFn = _noop_progress,
    opener=urllib.request.urlopen,
) -> None:
    request = urllib.request.Request(url, headers={"User-Agent": DOWNLOAD_USER_AGENT, "Accept": "application/zip,application/octet-stream,*/*"})
    try:
        response = opener(request, timeout=60)
    except urllib.error.URLError as exc:
        reason = getattr(exc, "reason", exc)
        raise RuntimeError(f"Could not download {label}: {reason}") from exc
    with response:
        total = int(response.headers.get("Content-Length") or 0)
        current = 0
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("wb") as handle:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                handle.write(chunk)
                current += len(chunk)
                progress(current, total or max(current, 1), f"Downloading {label}")
    if not destination.is_file() or destination.stat().st_size < 1024:
        raise RuntimeError(f"The {label} download was empty or incomplete.")


def _esde_asset_score(name: str, url: str) -> int:
    text = f"{name} {url}".lower()
    score = 0
    if text.endswith(".zip") or ".zip?" in text:
        score += 100
    if any(token in text for token in ("windows", "win64", "win-x64", "x64")):
        score += 55
    if "portable" in text:
        score += 45
    if "es-de" in text or "es_de" in text:
        score += 15
    if any(token in text for token in ("installer", "setup", ".msi", "arm64", "aarch64", "source", "checksum", "sha256")):
        score -= 180
    return score


def select_esde_windows_portable_asset(releases_payload: object) -> dict[str, str]:
    if not isinstance(releases_payload, list):
        raise RuntimeError("The official ES-DE releases response was not understood.")
    candidates: list[tuple[int, dict[str, str]]] = []
    for release in releases_payload:
        if not isinstance(release, dict) or release.get("upcoming_release"):
            continue
        version = str(release.get("tag_name") or release.get("name") or "latest")
        links = ((release.get("assets") or {}).get("links") or []) if isinstance(release.get("assets"), dict) else []
        for link in links:
            if not isinstance(link, dict):
                continue
            url = str(link.get("direct_asset_url") or link.get("url") or "").strip()
            name = str(link.get("name") or Path(urllib.parse.urlparse(url).path).name or "ES-DE Windows portable.zip")
            if not url:
                continue
            score = _esde_asset_score(name, url)
            if score > 0:
                candidates.append((score, {"name": name, "url": url, "version": version}))
    if not candidates:
        raise RuntimeError(
            "The latest official ES-DE release did not expose a recognizable Windows portable ZIP. "
            "Use Browse to select an existing ES-DE copy, or try Update / Repair later."
        )
    candidates.sort(key=lambda item: (item[0], item[1]["version"]), reverse=True)
    return candidates[0][1]


def install_managed_esde_from_archive(
    *,
    app_root: Path,
    archive: Path,
    source_url: str,
    version: str = "unknown",
    log: LogFn = _noop_log,
) -> Path:
    target_root = managed_esde_root(app_root)
    target_root.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix="ES-DE.install.", dir=str(target_root.parent)))
    unpack = staging / "unpack"
    final_tree = staging / "final"
    backup = target_root.with_name(target_root.name + ".previous")
    try:
        unpack.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(archive, "r") as bundle:
            unsafe = [info.filename for info in bundle.infolist() if not _safe_zip_member(info.filename)]
            if unsafe:
                raise RuntimeError("The downloaded ES-DE archive contained unsafe paths. Nothing was installed.")
            bundle.extractall(unpack)
        executable = _find_esde_executable_under(unpack)
        if executable is None:
            raise RuntimeError("The downloaded ES-DE package did not contain a complete Windows portable installation.")
        package_root = executable.parent
        final_tree.mkdir(parents=True, exist_ok=True)
        for child in package_root.iterdir():
            destination = final_tree / child.name
            if child.is_dir():
                shutil.copytree(child, destination, dirs_exist_ok=True)
            else:
                shutil.copy2(child, destination)
        installed_candidate = _find_esde_executable_under(final_tree)
        if installed_candidate is None:
            raise RuntimeError("The staged ES-DE installation failed validation. Nothing was installed.")
        info = {
            "source": source_url,
            "version": version,
            "archive_sha256": _sha256_file(archive),
            "installed_at_utc": datetime.now(timezone.utc).isoformat(),
        }
        (final_tree / "INSTALL_INFO.json").write_text(json.dumps(info, indent=2), encoding="utf-8")
        if backup.exists():
            shutil.rmtree(backup, ignore_errors=True)
        if target_root.exists():
            target_root.replace(backup)
        try:
            final_tree.replace(target_root)
        except Exception:
            if backup.exists() and not target_root.exists():
                backup.replace(target_root)
            raise
        shutil.rmtree(backup, ignore_errors=True)
        installed = _find_esde_executable_under(target_root)
        if installed is None:
            raise RuntimeError("ES-DE was installed but could not be located afterward.")
        log(f"Managed ES-DE {version} installed: {installed}")
        return installed
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def install_managed_esde(
    app_root: Path,
    *,
    log: LogFn = _noop_log,
    progress: ProgressFn = _noop_progress,
    opener=urllib.request.urlopen,
) -> Path:
    progress(0, 1, "Checking official ES-DE releases")
    try:
        payload = json.loads(_http_text(ESDE_RELEASES_API_URL, label="the official ES-DE GitLab project", opener=opener))
    except json.JSONDecodeError as exc:
        raise RuntimeError("The official ES-DE release list could not be read.") from exc
    asset = select_esde_windows_portable_asset(payload)
    downloads = BridgeLocations.default(app_root).data_root / "Downloads"
    downloads.mkdir(parents=True, exist_ok=True)
    archive = downloads / "ES-DE-Windows-portable.zip.download"
    try:
        _download_named_file(asset["url"], archive, label=f"ES-DE {asset['version']}", progress=progress, opener=opener)
        progress(1, 1, "Validating and installing ES-DE")
        return install_managed_esde_from_archive(
            app_root=app_root,
            archive=archive,
            source_url=asset["url"],
            version=asset["version"],
            log=log,
        )
    finally:
        archive.unlink(missing_ok=True)


def uninstall_managed_esde(app_root: Path, *, log: LogFn = _noop_log) -> bool:
    root = managed_esde_root(app_root)
    if not root.exists():
        return False
    shutil.rmtree(root)
    log("Managed ES-DE removed. External ES-DE installations and finished media were not changed.")
    return True


def detect_esde_executable(app_root: Path, preferred: Optional[Path] = None) -> Optional[Path]:
    candidates: list[Path] = []
    if preferred:
        candidates.append(preferred)
    managed = _find_esde_executable_under(managed_esde_root(app_root))
    if managed is not None:
        candidates.append(managed)
    for name in ("ES-DE.exe", "es-de.exe", "ES-DE_x64.exe"):
        candidates.append(app_root / name)
    if os.name == "nt":
        roots = [
            Path(os.environ.get("ProgramFiles", r"C:\Program Files")),
            Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")),
            Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local"))) / "Programs",
            Path.home() / "Desktop",
        ]
        relative_candidates = [
            Path("ES-DE") / "ES-DE.exe",
            Path("ES-DE") / "es-de.exe",
            Path("EmulationStation-DE") / "ES-DE.exe",
        ]
        for root in roots:
            for relative in relative_candidates:
                candidates.append(root / relative)
    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate).lower()
        if key in seen:
            continue
        seen.add(key)
        if candidate.is_file() and find_esde_systems_xml(candidate):
            return candidate
    return None


def _run_command(args: Sequence[str], *, cwd: Optional[Path] = None, capture: bool = True) -> subprocess.CompletedProcess[str]:
    flags = 0
    if os.name == "nt":
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return subprocess.run(
        list(map(str, args)),
        cwd=str(cwd) if cwd else None,
        check=False,
        text=True,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.STDOUT if capture else None,
        creationflags=flags,
    )


def create_windows_junction(link_path: Path, target_path: Path) -> None:
    if os.name != "nt":
        raise RuntimeError("The isolated ES-DE session currently requires Windows directory junctions.")
    link_path.parent.mkdir(parents=True, exist_ok=True)
    if link_path.exists():
        raise FileExistsError(f"Junction path already exists: {link_path}")
    result = _run_command([os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", "mklink", "/J", str(link_path), str(target_path)])
    if result.returncode != 0 or not link_path.exists():
        raise RuntimeError("Could not create the temporary ROM junction. " + (result.stdout or "").strip())


def is_reparse_point(path: Path) -> bool:
    try:
        attrs = path.lstat().st_file_attributes  # type: ignore[attr-defined]
        return bool(attrs & stat.FILE_ATTRIBUTE_REPARSE_POINT)
    except (AttributeError, OSError):
        if os.name == "nt":
            result = _run_command(["fsutil", "reparsepoint", "query", str(path)])
            return result.returncode == 0
        return path.is_symlink()


def remove_windows_junction_safely(link_path: Path) -> None:
    if not link_path.exists():
        return
    if not is_reparse_point(link_path):
        raise RuntimeError(f"Safety stop: expected a junction but found a normal directory at {link_path}")
    if os.name == "nt":
        result = _run_command([os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", "rmdir", str(link_path)])
        if result.returncode != 0 or link_path.exists():
            raise RuntimeError(f"Could not remove temporary junction: {link_path}")
    else:
        link_path.unlink()


def path_is_within(child: Path, parent: Path) -> bool:
    try:
        child.resolve(strict=False).relative_to(parent.resolve(strict=False))
        return True
    except ValueError:
        return False


def safe_remove_tree(path: Path, owned_root: Path) -> None:
    if not path.exists():
        return
    if not path_is_within(path, owned_root) or path.resolve(strict=False) == owned_root.resolve(strict=False):
        raise RuntimeError(f"Safety stop: refused to delete non-owned path: {path}")
    if is_reparse_point(path):
        remove_windows_junction_safely(path)
    else:
        shutil.rmtree(path)


def _owned_tree_size(path: Path) -> int:
    """Measure ordinary files without following any junctions or symlinks."""
    if not path.exists():
        return 0
    total = 0
    for root, directories, files in os.walk(path, topdown=True, followlinks=False):
        root_path = Path(root)
        kept: list[str] = []
        for name in directories:
            candidate = root_path / name
            if is_reparse_point(candidate):
                continue
            kept.append(name)
        directories[:] = kept
        for name in files:
            candidate = root_path / name
            try:
                if not is_reparse_point(candidate):
                    total += candidate.stat().st_size
            except OSError:
                continue
    return total


def _format_bytes(value: int) -> str:
    amount = float(max(0, value))
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if amount < 1024.0 or unit == "TB":
            return f"{amount:.0f} {unit}" if unit == "B" else f"{amount:.1f} {unit}"
        amount /= 1024.0
    return f"{amount:.1f} TB"


def purge_private_esde_home(
    isolated_home: Path,
    data_root: Path,
    log: LogFn = _noop_log,
) -> int:
    """Delete all bridge-owned ES-DE downloads/cache after verified conversion.

    The whole --home directory is disposable: settings and custom system files are
    regenerated on every launch.  ROM junctions must normally be disconnected by
    the session cleanup first, but this function defensively removes any remaining
    bridge-owned junctions beneath IsolatedHome/ROMs before deleting the tree.
    """
    if not isolated_home.exists():
        isolated_home.mkdir(parents=True, exist_ok=True)
        return 0
    if not path_is_within(isolated_home, data_root):
        raise RuntimeError(f"Safety stop: private ES-DE home is outside app data: {isolated_home}")

    rom_root = isolated_home / "ROMs"
    if rom_root.is_dir():
        for child in tuple(rom_root.iterdir()):
            if child.exists() and is_reparse_point(child):
                remove_windows_junction_safely(child)

    released = _owned_tree_size(isolated_home)
    safe_remove_tree(isolated_home, data_root)
    isolated_home.mkdir(parents=True, exist_ok=True)
    log(f"Deleted temporary ES-DE downloads and private scrape data ({_format_bytes(released)} released).")
    return released


def esde_profile_roots(isolated_home: Path) -> tuple[Path, Path]:
    """Return the current and legacy ES-DE app-data roots beneath --home."""
    return (isolated_home / "ES-DE", isolated_home / ".emulationstation")


def _system_xml_with_absolute_path(system: SystemEntry, rom_path: Path) -> str:
    node = ET.fromstring(system.outer_xml)
    path_node = node.find("path")
    if path_node is None:
        path_node = ET.SubElement(node, "path")
    path_node.text = rom_path.absolute().as_posix()
    extension_node = node.find("extension")
    if extension_node is None:
        extension_node = ET.SubElement(node, "extension")
    extension_node.text = _extension_xml_tokens(system.extensions)
    return ET.tostring(node, encoding="unicode")


def write_compatibility_system_configs(
    system: SystemEntry,
    isolated_home: Path,
    rom_path: Path,
) -> tuple[Path, Path]:
    """Write a direct-path one-system config for both ES-DE profile generations."""
    system_xml = _system_xml_with_absolute_path(system, rom_path)
    written: list[Path] = []
    for profile_root in esde_profile_roots(isolated_home):
        target = profile_root / "custom_systems" / "es_systems.xml"
        target.parent.mkdir(parents=True, exist_ok=True)
        content = (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<!-- Generated by CRysTal Fantasy Scraper. Private profile only. -->\n'
            "<systemList>\n"
            "  <loadExclusive/>\n"
            f"  {system_xml}\n"
            "</systemList>\n"
        )
        target.write_text(content, encoding="utf-8")
        written.append(target)
    return (written[0], written[1])



def write_multi_compatibility_system_configs(
    systems_and_paths: Sequence[tuple[SystemEntry, Path]],
    isolated_home: Path,
) -> tuple[Path, Path]:
    """Write a private multi-system ES-DE configuration for Easy or Pro mode."""
    if not systems_and_paths:
        raise ValueError("At least one system is required.")
    system_xml = [_system_xml_with_absolute_path(system, path) for system, path in systems_and_paths]
    written: list[Path] = []
    for profile_root in esde_profile_roots(isolated_home):
        target = profile_root / "custom_systems" / "es_systems.xml"
        target.parent.mkdir(parents=True, exist_ok=True)
        content = (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<!-- Generated by CRysTal Fantasy Scraper. Private profile only. -->\n'
            '<systemList>\n  <loadExclusive/>\n  '
            + '\n  '.join(system_xml)
            + '\n</systemList>\n'
        )
        target.write_text(content, encoding="utf-8")
        written.append(target)
    return written[0], written[1]


def validate_multi_bridge_rom_visibility(
    config_paths: Sequence[Path],
    systems_and_paths: Sequence[tuple[SystemEntry, Path]],
) -> dict[str, int]:
    expected = {system.name: path.absolute().as_posix() for system, path in systems_and_paths}
    for config_path in config_paths:
        try:
            root = ET.parse(config_path).getroot()
        except (ET.ParseError, OSError) as exc:
            raise RuntimeError(f"Generated ES-DE system config is unreadable: {config_path}: {exc}") from exc
        if root.find("loadExclusive") is None:
            raise RuntimeError(f"Generated ES-DE system config is missing loadExclusive: {config_path}")
        actual = {node.findtext("name", default=""): node.findtext("path", default="") for node in root.findall("system")}
        if actual != expected:
            raise RuntimeError(f"Generated ES-DE multi-system configuration does not match the selected folders: {config_path}")
    counts: dict[str, int] = {}
    for system, path in systems_and_paths:
        visible = count_matching_roms(path, system)
        if visible <= 0:
            raise RuntimeError(f"No ES-DE-visible game files were found for {system.full_name} through {path}.")
        counts[system.name] = visible
    return counts


def validate_bridge_rom_visibility(
    config_paths: Sequence[Path],
    system: SystemEntry,
    expected_path: Path,
) -> int:
    """Verify the exact configuration ES-DE will read before it is launched."""
    expected = expected_path.absolute().as_posix()
    for config_path in config_paths:
        try:
            root = ET.parse(config_path).getroot()
        except (ET.ParseError, OSError) as exc:
            raise RuntimeError(f"Generated ES-DE system config is unreadable: {config_path}: {exc}") from exc
        if root.find("loadExclusive") is None:
            raise RuntimeError(f"Generated ES-DE system config is missing loadExclusive: {config_path}")
        system_node = root.find("system")
        actual = system_node.findtext("path", default="") if system_node is not None else ""
        if actual != expected:
            raise RuntimeError(
                f"Generated ES-DE ROM path mismatch. Expected {expected}, found {actual or '<empty>'}."
            )
    visible = count_matching_roms(expected_path, system)
    if visible <= 0:
        raise RuntimeError(
            "The temporary ROM link was created, but ES-DE-compatible game files are not visible through it. "
            "The bridge stopped before opening ES-DE."
        )
    return visible


def write_exclusive_system_config(system: SystemEntry, isolated_home: Path) -> Path:
    """Legacy helper retained for compatibility with older callers."""
    target = isolated_home / "ES-DE" / "custom_systems" / "es_systems.xml"
    target.parent.mkdir(parents=True, exist_ok=True)
    content = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!-- Generated by CRysTal Fantasy Scraper. Private profile only. -->\n'
        "<systemList>\n"
        "  <loadExclusive/>\n"
        f"  {system.outer_xml}\n"
        "</systemList>\n"
    )
    target.write_text(content, encoding="utf-8")
    return target


def set_existing_esde_setting(profile_root: Path, name: str, value: str) -> bool:
    """Update an ES-DE-created setting without synthesizing a partial config."""
    settings_path = profile_root / "es_settings.xml"
    if not settings_path.is_file():
        return False
    try:
        tree = ET.parse(settings_path)
        root = tree.getroot()
        found = None
        for node in root.findall("string"):
            if node.get("name") == name:
                found = node
                break
        if found is None:
            found = ET.SubElement(root, "string")
            found.set("name", name)
        found.set("value", value)
        ET.indent(tree, space="  ")
        tree.write(settings_path, encoding="utf-8", xml_declaration=True)
        return True
    except (ET.ParseError, OSError):
        return False


def locate_scrape_outputs(isolated_home: Path, system_name: str) -> tuple[Path, Path, Path]:
    """Locate results under whichever ES-DE profile generation actually ran."""
    candidates: list[tuple[float, Path, Path, Path]] = []
    for profile_root in esde_profile_roots(isolated_home):
        media = profile_root / "downloaded_media" / system_name
        gamelist = profile_root / "gamelists" / system_name / "gamelist.xml"
        newest = 0.0
        for probe in (media, gamelist, profile_root / "es_log.txt"):
            try:
                if probe.exists():
                    newest = max(newest, probe.stat().st_mtime)
            except OSError:
                pass
        if media.is_dir() or gamelist.is_file():
            candidates.append((newest, profile_root, media, gamelist))
    if candidates:
        _, root, media, gamelist = max(candidates, key=lambda item: item[0])
        return root, media, gamelist
    root = esde_profile_roots(isolated_home)[0]
    return root, root / "downloaded_media" / system_name, root / "gamelists" / system_name / "gamelist.xml"


def collect_esde_diagnostic(isolated_home: Path, limit: int = 12) -> str:
    interesting: list[str] = []
    needles = ("error", "warning", "rom", "system", "game")
    for profile_root in esde_profile_roots(isolated_home):
        log_path = profile_root / "es_log.txt"
        if not log_path.is_file():
            continue
        try:
            lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        for line in lines:
            if any(token in line.lower() for token in needles):
                interesting.append(f"[{profile_root.name}] {line.strip()}")
    return "\n".join(interesting[-limit:])


def _unique_package_root(output_parent: Path, system: SystemEntry) -> Path:
    stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    base = f"{safe_filename(system.full_name)} - CRysTal Fantasy Ready - {stamp}"
    candidate = output_parent / base
    number = 2
    while candidate.exists():
        candidate = output_parent / f"{base}_{number}"
        number += 1
    return candidate


def _claim_key(destination_folder: Path, stem: str) -> str:
    return f"{destination_folder.as_posix().lower()}|{stem.lower()}"


def _ffmpeg_scale_filter(max_width: int, max_height: int) -> str:
    return f"scale={max_width}:{max_height}:force_original_aspect_ratio=decrease:flags=lanczos"


PNG_TARGET_BYTES = 64 * 1024
PNG_MAX_HEIGHT = 340


def _png8_filter(max_height: int, colors: int, preserve_alpha: bool) -> str:
    # Mirrors the user's proven ImageMagick workflow: never upscale, cap height,
    # then quantize to an indexed PNG palette.  The extra attempts below only
    # reduce palette/height when the first PNG8 pass remains larger than ~64 KB.
    alpha_options = "reserve_transparent=1:transparency_color=ffffff" if preserve_alpha else "reserve_transparent=0"
    return (
        f"[0:v]scale='min(iw,720)':'min(ih,{max_height})':"
        "force_original_aspect_ratio=decrease:flags=lanczos,split[img][palin];"
        f"[palin]palettegen=max_colors={colors}:{alpha_options}:stats_mode=full[pal];"
        f"[img][pal]paletteuse=dither=sierra2_4a:alpha_threshold={'128' if preserve_alpha else '255'}"
    )


def _render_png8_attempt(
    ffmpeg: Path,
    source: Path,
    destination: Path,
    *,
    max_height: int,
    colors: int,
    preserve_alpha: bool,
) -> None:
    args = [
        str(ffmpeg), "-hide_banner", "-loglevel", "error", "-y", "-i", str(source),
        "-filter_complex", _png8_filter(max_height, colors, preserve_alpha),
        "-frames:v", "1", "-update", "1", str(destination),
    ]
    result = _run_command(args)
    if result.returncode != 0 or not destination.is_file() or destination.stat().st_size == 0:
        destination.unlink(missing_ok=True)
        raise RuntimeError((result.stdout or "FFmpeg PNG8 conversion failed").strip())


def convert_image_with_ffmpeg(
    ffmpeg: Path,
    source: Path,
    destination: Path,
    preserve_alpha: bool,
    *,
    optimize: bool = True,
) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not optimize:
        args = [
            str(ffmpeg), "-hide_banner", "-loglevel", "error", "-y", "-i", str(source),
            "-frames:v", "1", "-update", "1", str(destination),
        ]
        result = _run_command(args)
        if result.returncode != 0 or not destination.is_file() or destination.stat().st_size == 0:
            destination.unlink(missing_ok=True)
            raise RuntimeError((result.stdout or "FFmpeg image conversion failed").strip())
        return

    attempts = (
        (340, 256),
        (340, 192),
        (340, 128),
        (320, 128),
        (300, 96),
        (280, 64),
    )
    best_path: Optional[Path] = None
    best_size: Optional[int] = None
    attempt_paths: list[Path] = []
    try:
        for index, (height, colors) in enumerate(attempts):
            attempt = destination.with_name(f".{destination.stem}.png8-{index}-{uuid.uuid4().hex}.png")
            attempt_paths.append(attempt)
            _render_png8_attempt(
                ffmpeg, source, attempt, max_height=height, colors=colors, preserve_alpha=preserve_alpha
            )
            size = attempt.stat().st_size
            if best_size is None or size < best_size:
                best_path, best_size = attempt, size
            if size <= PNG_TARGET_BYTES:
                break
        if best_path is None:
            raise RuntimeError("No valid PNG8 output was produced.")
        shutil.copy2(best_path, destination)
    finally:
        for attempt in attempt_paths:
            attempt.unlink(missing_ok=True)


def import_image_folders(
    source_root: Path,
    source_folders: Sequence[str],
    destination_folder: Path,
    *,
    preserve_alpha: bool,
    optimize: bool,
    ffmpeg: Optional[Path],
    collisions: list[str],
    source_map: list[tuple[str, str]],
    claimed: set[str],
    fallback_only: bool,
    progress: ProgressFn,
    progress_state: list[int],
    progress_total: int,
) -> int:
    count = 0
    destination_folder.mkdir(parents=True, exist_ok=True)
    for folder_name in source_folders:
        source_folder = source_root / folder_name
        if not source_folder.is_dir():
            continue
        for file in sorted((p for p in source_folder.rglob("*") if p.is_file()), key=lambda p: str(p).lower()):
            if file.suffix.lower() not in IMAGE_EXTENSIONS:
                continue
            stem = file.stem
            key = _claim_key(destination_folder, stem)
            if fallback_only and key in claimed:
                progress_state[0] += 1
                progress(progress_state[0], progress_total, file.name)
                continue
            if key in claimed:
                collisions.append(f"Skipped name collision: {file} -> {destination_folder}")
                progress_state[0] += 1
                progress(progress_state[0], progress_total, file.name)
                continue
            try:
                destination = destination_folder / (stem + ".png")
                if destination.exists():
                    collisions.append(f"Skipped name collision: {file} -> {destination}")
                    continue
                if file.suffix.lower() == ".png" and not optimize:
                    shutil.copy2(file, destination)
                elif ffmpeg is not None:
                    convert_image_with_ffmpeg(ffmpeg, file, destination, preserve_alpha, optimize=optimize)
                elif file.suffix.lower() == ".png":
                    shutil.copy2(file, destination)
                else:
                    raise RuntimeError("FFmpeg is required to guarantee PNG artwork output.")
                claimed.add(key)
                source_map.append((str(file), str(destination)))
                count += 1
            finally:
                progress_state[0] += 1
                progress(progress_state[0], progress_total, file.name)
    return count


def pack_cfv_jpeg_frames(frames: Sequence[Path], destination: Path, width: int = 160, height: int = 120, fps: int = 15) -> None:
    if not frames:
        raise ValueError("No JPEG frames were created.")
    sizes: list[int] = []
    total = 0
    for frame in frames:
        size = frame.stat().st_size
        if size < 32 or size > 524288:
            raise ValueError(f"Invalid JPEG frame size: {frame.name}")
        sizes.append(size)
        total += size
    if total > 0xFFFFFFFF:
        raise ValueError("Video is too large.")
    frame_count = len(frames)
    video_offset = 48 + 4 * frame_count
    header = struct.pack(
        "<12I",
        0x31564643,  # CFV1
        2,
        48,
        width,
        height,
        fps,
        1,
        frame_count,
        48,
        video_offset,
        total,
        0,
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("wb") as output:
        output.write(header)
        output.write(struct.pack(f"<{frame_count}I", *sizes))
        for frame in frames:
            with frame.open("rb") as source:
                shutil.copyfileobj(source, output, length=1024 * 1024)


def write_cfa(pcm_path: Path, destination: Path, sample_rate: int = 14000) -> None:
    length = pcm_path.stat().st_size
    if length < 2 or length % 2:
        raise ValueError("FFmpeg created invalid PCM audio.")
    samples = length // 2
    if samples > 0xFFFFFFFF:
        raise ValueError("Audio is too long.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("wb") as output:
        output.write(struct.pack("<5I", 0x31414643, 1, sample_rate, 1, samples))
        with pcm_path.open("rb") as source:
            shutil.copyfileobj(source, output, length=1024 * 1024)


def convert_video_golden(ffmpeg: Path, source: Path, cfv_path: Path, cfa_path: Path) -> None:
    with tempfile.TemporaryDirectory(prefix="crt_fantasy_bridge_video_") as temp_dir_text:
        temp_dir = Path(temp_dir_text)
        frame_pattern = temp_dir / "frame-%06d.jpg"
        video_args = [
            str(ffmpeg), "-hide_banner", "-loglevel", "error", "-y", "-i", str(source),
            "-map", "0:v:0", "-t", "15",
            "-vf", "fps=15,scale=160:120:force_original_aspect_ratio=decrease:flags=lanczos,pad=160:120:(ow-iw)/2:(oh-ih)/2:color=black,format=yuvj420p,setsar=1",
            "-an", "-q:v", "8", str(frame_pattern),
        ]
        result = _run_command(video_args)
        if result.returncode != 0:
            raise RuntimeError((result.stdout or "FFmpeg video conversion failed").strip())
        frames = sorted(temp_dir.glob("frame-*.jpg"))
        pack_cfv_jpeg_frames(frames, cfv_path)
        duration = len(frames) / 15.0
        pcm = temp_dir / "audio.pcm"
        audio_args = [
            str(ffmpeg), "-hide_banner", "-loglevel", "error", "-y", "-i", str(source),
            "-map", "0:a:0?", "-vn", "-af", "apad,alimiter=limit=0.85", "-t", f"{duration:.8f}",
            "-ac", "1", "-ar", "14000", "-c:a", "pcm_s16le", "-f", "s16le", str(pcm),
        ]
        audio_result = _run_command(audio_args)
        if audio_result.returncode == 0 and pcm.is_file() and pcm.stat().st_size >= 2:
            write_cfa(pcm, cfa_path, 14000)
        else:
            cfa_path.unlink(missing_ok=True)


def import_videos(
    source_root: Path,
    destination_folder: Path,
    ffmpeg: Optional[Path],
    convert_videos: bool,
    collisions: list[str],
    source_map: list[tuple[str, str]],
    progress: ProgressFn,
    progress_state: list[int],
    progress_total: int,
    log: LogFn,
) -> int:
    source_folder = source_root / "videos"
    if not source_folder.is_dir():
        return 0
    destination_folder.mkdir(parents=True, exist_ok=True)
    count = 0
    for file in sorted((p for p in source_folder.rglob("*") if p.is_file()), key=lambda p: str(p).lower()):
        if file.suffix.lower() not in VIDEO_EXTENSIONS:
            continue
        stem = file.stem
        try:
            if convert_videos:
                if not ffmpeg:
                    raise RuntimeError("ffmpeg is required to create CRysTal Fantasy video files.")
                cfv = destination_folder / f"{stem}.cfv"
                cfa = destination_folder / f"{stem}.cfa"
                if cfv.exists() or cfa.exists():
                    collisions.append(f"Skipped name collision: {file} -> {cfv}")
                    continue
                log(f"Converting video: {file.name}")
                convert_video_golden(ffmpeg, file, cfv, cfa)
                source_map.append((str(file), str(cfv)))
                if cfa.exists():
                    source_map.append((str(file), str(cfa)))
            else:
                destination = destination_folder / file.name
                if destination.exists():
                    collisions.append(f"Skipped name collision: {file} -> {destination}")
                    continue
                shutil.copy2(file, destination)
                source_map.append((str(file), str(destination)))
            count += 1
        except Exception as exc:
            (destination_folder / f"{stem}.cfv").unlink(missing_ok=True)
            (destination_folder / f"{stem}.cfa").unlink(missing_ok=True)
            log(f"Video failed: {file.name} — {exc}")
        finally:
            progress_state[0] += 1
            progress(progress_state[0], progress_total, file.name)
    return count


def _count_convertible_files(scraped_root: Path, include_gallery_art: bool) -> int:
    folders = {
        "covers", "miximages", "marquees", "backcovers", "screenshots", "fanart", "titlescreens", "physicalmedia", "videos"
    }
    if not include_gallery_art:
        folders -= {"marquees", "titlescreens", "fanart", "miximages"}
    count = 0
    for folder in folders:
        root = scraped_root / folder
        if not root.is_dir():
            continue
        for file in root.rglob("*"):
            if file.is_file() and (file.suffix.lower() in IMAGE_EXTENSIONS or file.suffix.lower() in VIDEO_EXTENSIONS):
                count += 1
    return max(1, count)




def esde_settings_paths(isolated_home: Path) -> tuple[Path, ...]:
    """Settings locations used by current and legacy ES-DE releases under --home."""
    modern, legacy = esde_profile_roots(isolated_home)
    return (
        modern / "settings" / "es_settings.xml",
        modern / "es_settings.xml",
        legacy / "es_settings.xml",
    )


def _setting_nodes(scrape: ScrapeOptions, rom_root: Path, profile_root: Path) -> tuple[dict[str, str], dict[str, bool], dict[str, int]]:
    strings = {
        "Scraper": "screenscraper",
        "ScraperUsernameScreenScraper": scrape.username if scrape.use_screenscraper_account else "",
        "ScraperPasswordScreenScraper": scrape.password if scrape.use_screenscraper_account else "",
        "ScraperRegion": scrape.region,
        "ScraperLanguage": scrape.language,
        "ROMDirectory": str(rom_root),
        "MediaDirectory": str(profile_root / "downloaded_media"),
        "SaveGamelistsMode": "always",
    }
    bools = {
        "ScraperUseAccountScreenScraper": bool(scrape.use_screenscraper_account),
        "ScrapeGameNames": bool(scrape.game_names),
        "ScrapeRatings": bool(scrape.ratings),
        "ScrapeMetadata": bool(scrape.metadata),
        "ScraperOverwriteData": bool(scrape.overwrite),
        "ScraperInteractive": False,
        "ScraperSemiautomatic": True,
        "ScraperSearchFileHash": True,
        # Always search from the physical ROM/folder name in this disposable profile.
        # This prevents an earlier regional title from influencing a corrected scrape.
        "ScraperSearchMetadataName": False,
        "ScraperIgnoreHTTP404Errors": True,
        "ScraperIncludeFolders": True,
        # ES-DE defaults to Europe and also enables an extra country-specific fallback.
        # The bridge explicitly locks the selected region and disables that additional fallback.
        "ScraperRegionFallback": False,
        "MiximageGenerate": "miximages" in scrape.media_types,
    }
    selected = set(scrape.media_types)
    for media, key in MEDIA_SETTING_KEYS.items():
        bools[key] = media in selected
    ints = {"ScraperRetryOnErrorCount": max(0, min(10, int(scrape.retry_count)))}
    return strings, bools, ints


def _write_settings_document(path: Path, strings: dict[str, str], bools: dict[str, bool], ints: dict[str, int], *, wrapped: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    nodes: list[str] = []
    from xml.sax.saxutils import quoteattr
    for name, value in sorted(bools.items()):
        nodes.append(f'  <bool name={quoteattr(name)} value={quoteattr("true" if value else "false")} />')
    for name, value in sorted(ints.items()):
        nodes.append(f'  <int name={quoteattr(name)} value={quoteattr(str(value))} />')
    for name, value in sorted(strings.items()):
        nodes.append(f'  <string name={quoteattr(name)} value={quoteattr(value)} />')
    if wrapped:
        text = '<?xml version="1.0" encoding="UTF-8"?>\n<settings>\n' + '\n'.join(nodes) + '\n</settings>\n'
    else:
        text = '<?xml version="1.0" encoding="UTF-8"?>\n' + '\n'.join(node.strip() for node in nodes) + '\n'
    path.write_text(text, encoding='utf-8')


def configure_esde_scraper_profiles(isolated_home: Path, scrape: ScrapeOptions, rom_root: Path) -> tuple[Path, ...]:
    modern, legacy = esde_profile_roots(isolated_home)
    paths = esde_settings_paths(isolated_home)
    for path in paths:
        profile_root = modern if path.is_relative_to(modern) else legacy
        strings, bools, ints = _setting_nodes(scrape, rom_root, profile_root)
        # Current ES-DE writes a flat sequence of setting nodes. It can read a wrapped
        # document too, but matching its native format removes migration ambiguity.
        _write_settings_document(path, strings, bools, ints, wrapped=False)
    return paths


def scrub_screenscraper_password(isolated_home: Path) -> None:
    """Remove the clear-text password from every private settings layout."""
    for path in esde_settings_paths(isolated_home):
        if not path.is_file():
            continue
        text = path.read_text(encoding='utf-8', errors='replace')
        text = re.sub(
            r'(<string\s+name=["\']ScraperPasswordScreenScraper["\']\s+value=)["\'][^"\']*["\']',
            r'\1""', text,
        )
        path.write_text(text, encoding='utf-8')


def read_private_esde_settings(path: Path) -> dict[str, object]:
    """Read either modern wrapped or legacy flat private ES-DE settings."""
    if not path.is_file():
        return {}
    text = path.read_text(encoding="utf-8", errors="replace")
    try:
        root = ET.fromstring(text)
        nodes = list(root) if root.tag == "settings" else [root]
    except ET.ParseError:
        # Legacy ES-DE accepted a flat sequence of setting elements. Wrap only
        # for parsing; the bridge never exposes this file outside its profile.
        cleaned = re.sub(r"<\?xml[^>]*\?>", "", text).strip()
        try:
            root = ET.fromstring(f"<settings>{cleaned}</settings>")
            nodes = list(root)
        except ET.ParseError:
            return {}
    result: dict[str, object] = {}
    for node in nodes:
        name = node.get("name")
        if not name:
            continue
        value = node.get("value", "")
        if node.tag == "bool":
            result[name] = value.lower() == "true"
        elif node.tag == "int":
            try: result[name] = int(value)
            except ValueError: result[name] = 0
        else:
            result[name] = value
    return result


def validate_private_scraper_region(path: Path, expected_region: str) -> None:
    """Fail closed if the canonical ES-DE settings file does not contain the chosen region."""
    settings = read_private_esde_settings(path)
    actual = str(settings.get("ScraperRegion", "")).lower()
    if actual != expected_region.lower():
        raise RuntimeError(
            f"Region lock failed before launch: expected {expected_region!r}, found {actual or 'missing'!r} in {path}."
        )
    if settings.get("ScraperRegionFallback") is not False:
        raise RuntimeError(f"Region lock failed: additional-region fallback was not disabled in {path}.")


def wait_for_esde_region_handshake(
    process: subprocess.Popen,
    settings_path: Path,
    expected_region: str,
    initial_mtime_ns: int,
    *,
    timeout: float = 30.0,
) -> None:
    """Wait until ES-DE rewrites its first-run settings, then verify the region survived loading."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(
                "ES-DE exited before the scraper-region handshake completed. The scrape was not started."
            )
        try:
            current_mtime = settings_path.stat().st_mtime_ns
        except FileNotFoundError:
            current_mtime = 0
        if current_mtime > initial_mtime_ns:
            settings = read_private_esde_settings(settings_path)
            actual = str(settings.get("ScraperRegion", "")).lower()
            if actual != expected_region.lower():
                process.terminate()
                try:
                    process.wait(timeout=5)
                except Exception:
                    process.kill()
                raise RuntimeError(
                    "ES-DE did not retain the selected scraper region. "
                    f"Expected {expected_region!r}, but ES-DE initialized as {actual or 'missing'!r}. "
                    "The run was stopped before scraping to prevent wrong-region titles and artwork."
                )
            if settings.get("ScraperRegionFallback") is not False:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except Exception:
                    process.kill()
                raise RuntimeError(
                    "ES-DE re-enabled additional-region fallback during startup. "
                    "The run was stopped before scraping to prevent mixed-region artwork."
                )
            return
        time.sleep(0.15)
    # Older releases may not rewrite the file during startup. Revalidate the exact file
    # we supplied rather than silently accepting ES-DE's European default.
    validate_private_scraper_region(settings_path, expected_region)


def _unique_export_root(output_parent: Path, system: SystemEntry, export_format: str) -> Path:
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    label = EXPORT_PRESETS.get(export_format, {}).get("title", export_format)
    base = f"{safe_filename(label)}_{safe_filename(system.name)}_{stamp}"
    target = output_parent / base
    index = 2
    while target.exists():
        target = output_parent / f"{base}_{index}"
        index += 1
    return target


def _media_index(scraped_root: Path) -> dict[str, dict[str, list[Path]]]:
    index: dict[str, dict[str, list[Path]]] = {}
    if not scraped_root.is_dir():
        return index
    for media_type in MEDIA_TYPES:
        folder = scraped_root / media_type
        if not folder.is_dir():
            continue
        by_stem: dict[str, list[Path]] = {}
        for file in sorted(folder.rglob('*')):
            if not file.is_file():
                continue
            relative = file.relative_to(folder)
            key_full = (relative.parent / file.stem).as_posix().lower().lstrip('./')
            key_stem = file.stem.lower()
            by_stem.setdefault(key_full, []).append(file)
            by_stem.setdefault(key_stem, []).append(file)
        index[media_type] = by_stem
    return index


def _find_media(index: dict[str, dict[str, list[Path]]], media_type: str, game: dict) -> Optional[Path]:
    table = index.get(media_type, {})
    relative = Path(game.get('rom_relative_path') or game.get('rom_filename') or '')
    full_key = (relative.parent / relative.stem).as_posix().lower().lstrip('./')
    stem_key = relative.stem.lower()
    choices = table.get(full_key) or table.get(stem_key) or []
    return choices[0] if choices else None


def _copy_media_file(source: Path, destination: Path, ffmpeg: Optional[Path], *, force_png: bool = False, preserve_alpha: bool = False) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if force_png:
        destination = destination.with_suffix('.png')
        if ffmpeg is not None:
            convert_image_with_ffmpeg(ffmpeg, source, destination, preserve_alpha, optimize=True)
        elif source.suffix.lower() == '.png':
            shutil.copy2(source, destination)
        else:
            raise RuntimeError('FFmpeg is required to convert non-PNG artwork for this export preset.')
    else:
        if not destination.suffix:
            destination = destination.with_suffix(source.suffix.lower())
        shutil.copy2(source, destination)
    return destination


def _xml_text(parent: ET.Element, name: str, value: object) -> None:
    if value is None or value == '':
        return
    ET.SubElement(parent, name).text = str(value)


def _build_portable_gamelist(metadata: dict, media_paths: dict[str, dict[str, str]], destination: Path, *, batocera_tags: bool = False) -> None:
    root = ET.Element('gameList')
    for game in metadata.get('games', []):
        node = ET.SubElement(root, 'game')
        _xml_text(node, 'path', './' + str(game.get('rom_relative_path') or game.get('rom_filename')).replace('\\','/').lstrip('./'))
        for tag, key in (
            ('name','title'), ('desc','description'), ('releasedate','release_date'),
            ('developer','developer'), ('publisher','publisher'), ('genre','genre'),
            ('players','players'),
        ):
            _xml_text(node, tag, game.get(key))
        rating = game.get('rating_0_to_1')
        if rating is not None:
            _xml_text(node, 'rating', f'{float(rating):.6f}')
        paths = media_paths.get(str(game.get('rom_relative_path')), {})
        primary = paths.get('miximages') or paths.get('screenshots') or paths.get('covers') or paths.get('titlescreens') or paths.get('3dboxes')
        thumb = paths.get('covers') or paths.get('3dboxes')
        _xml_text(node, 'image', primary)
        _xml_text(node, 'thumbnail', thumb)
        _xml_text(node, 'video', paths.get('videos'))
        _xml_text(node, 'marquee', paths.get('marquees'))
        _xml_text(node, 'manual', paths.get('manuals'))
        if batocera_tags:
            _xml_text(node, 'fanart', paths.get('fanart'))
            _xml_text(node, 'titleshot', paths.get('titlescreens'))
            _xml_text(node, 'boxback', paths.get('backcovers'))
            _xml_text(node, 'cartridge', paths.get('physicalmedia'))
            _xml_text(node, 'boxart', paths.get('covers'))
            _xml_text(node, 'wheel', paths.get('marquees'))
            _xml_text(node, 'mix', paths.get('miximages'))
    tree = ET.ElementTree(root)
    ET.indent(tree, space='  ')
    destination.parent.mkdir(parents=True, exist_ok=True)
    tree.write(destination, encoding='utf-8', xml_declaration=True)


def _portable_media_folder(export_format: str, media_type: str) -> str:
    """Return conservative, portable folder names used beside each system gamelist."""
    # Relative paths in gamelist.xml are authoritative. These conventional names
    # also make the package understandable when browsed without the frontend.
    if export_format == "recalbox":
        mapping = {
            "screenshots": "media/images", "miximages": "media/images",
            "titlescreens": "media/titlescreens", "covers": "media/box2dfront",
            "backcovers": "media/box2dback", "marquees": "media/wheels",
            "3dboxes": "media/box3d", "physicalmedia": "media/cartridges",
            "fanart": "media/fanart", "videos": "media/videos",
            "manuals": "media/manuals",
        }
        return mapping.get(media_type, f"media/{media_type}")
    if export_format == "batocera":
        mapping = {
            "screenshots": "images", "miximages": "images",
            "titlescreens": "images", "covers": "images",
            "backcovers": "images", "marquees": "images",
            "3dboxes": "images", "physicalmedia": "images",
            "fanart": "images", "videos": "videos", "manuals": "manuals",
        }
        return mapping.get(media_type, media_type)
    # Classic/RetroPie EmulationStation packages commonly use images beside a
    # system gamelist. Separate videos/manuals avoid ambiguous image tags.
    if media_type == "videos":
        return "videos"
    if media_type == "manuals":
        return "manuals"
    return "images"


def build_standard_esde_package(*, system: SystemEntry, output_parent: Path, scraped_root: Path, gamelist_source: Path, selected_media: Sequence[str], log: LogFn, stage: StageFn, progress: ProgressFn) -> PackageResult:
    package_root = _unique_export_root(output_parent, system, 'esde')
    target_root = package_root / 'ES-DE'
    media_target = target_root / 'downloaded_media' / system.name
    selected = set(selected_media)
    count = 0
    if scraped_root.is_dir():
        for child in scraped_root.iterdir():
            if not child.is_dir() or child.name not in selected:
                continue
            shutil.copytree(child, media_target / child.name, dirs_exist_ok=True)
            count += sum(1 for p in (media_target / child.name).rglob('*') if p.is_file())
    copied = None
    if gamelist_source.is_file():
        copied = target_root / 'gamelists' / system.name / 'gamelist.xml'
        copied.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(gamelist_source, copied)
    metadata = parse_gamelist(gamelist_source, system)
    (package_root/'README_FIRST.txt').write_text(
        f'Standard ES-DE export for {system.full_name}.\n\nCopy the enclosed ES-DE folder into your ES-DE application-data folder.\n'
        'The package preserves ES-DE native gamelists/<system> and downloaded_media/<system> structure.\n'
        'No proprietary metadata files are added.\n', encoding='utf-8')
    stage('complete','Standard ES-DE package complete')
    return PackageResult(package_root,count,len(metadata.get('games',[])),sum(1 for p in media_target.rglob('*') if p.is_file() and p.suffix.lower() in VIDEO_EXTENSIONS),0,None,copied)


def build_console_mode_package(*, system: SystemEntry, output_parent: Path, scraped_root: Path, gamelist_source: Path, ffmpeg: Optional[Path], selected_media: Sequence[str], log: LogFn, stage: StageFn, progress: ProgressFn) -> PackageResult:
    package_root = _unique_export_root(output_parent, system, 'console_mode')
    media_root = package_root/'media'
    media_root.mkdir(parents=True)
    metadata = parse_gamelist(gamelist_source, system)
    index = _media_index(scraped_root)
    count = 0
    source_map = []
    for game in metadata.get('games',[]):
        stem = game.get('rom_stem') or Path(game.get('rom_filename','game')).stem
        if 'covers' in selected_media:
            src = _find_media(index,'covers',game) or _find_media(index,'miximages',game)
            if src:
                dest = _copy_media_file(src, media_root/f'{stem}.png', ffmpeg, force_png=True)
                source_map.append((str(src),str(dest))); count += 1
        if 'screenshots' in selected_media:
            src = _find_media(index,'screenshots',game) or _find_media(index,'fanart',game) or _find_media(index,'titlescreens',game)
            if src:
                dest = _copy_media_file(src, media_root/f'{stem}-BG.png', ffmpeg, force_png=True)
                source_map.append((str(src),str(dest))); count += 1
    copied_gamelist: Optional[Path] = None
    if gamelist_source.is_file():
        copied_gamelist = media_root / 'gamelist.xml'
        shutil.copy2(gamelist_source, copied_gamelist)
    with (package_root/'SOURCE_MAP.csv').open('w',encoding='utf-8-sig',newline='') as fh:
        w=csv.writer(fh); w.writerow(['Source','Console Mode Output']); w.writerows(source_map)
    (package_root/'README_FIRST.txt').write_text(
        f'Default Console Mode media for {system.full_name}.\n\nCopy the media folder to the location used by Console Mode.\n'
        'Box art is named <ROM stem>.png and screenshots/backgrounds are named <ROM stem>-BG.png.\n'
        'A standard gamelist.xml is included beside the images for current or future metadata support.\n',encoding='utf-8')
    stage('complete','Console Mode package complete')
    return PackageResult(package_root,count,len(metadata.get('games',[])),0,0,None,copied_gamelist)


def build_portable_es_package(*, export_format: str, system: SystemEntry, output_parent: Path, scraped_root: Path, gamelist_source: Path, selected_media: Sequence[str], log: LogFn, stage: StageFn, progress: ProgressFn, target_system_folder: str='') -> PackageResult:
    package_root = _unique_export_root(output_parent, system, export_format)
    folder_name = safe_filename(target_system_folder or system.system_folder or system.name)
    if export_format in {'batocera','recalbox'}:
        system_root = package_root/'share'/'roms'/folder_name
    else:
        system_root = package_root/folder_name
    system_root.mkdir(parents=True)
    metadata = parse_gamelist(gamelist_source, system)
    index = _media_index(scraped_root)
    media_paths: dict[str,dict[str,str]] = {}
    count = videos = 0
    selected = [m for m in MEDIA_TYPES if m in set(selected_media)]
    for game in metadata.get('games',[]):
        key = str(game.get('rom_relative_path'))
        paths: dict[str,str] = {}
        stem = game.get('rom_stem') or Path(game.get('rom_filename','game')).stem
        parent = Path(game.get('rom_relative_path') or '').parent
        for media_type in selected:
            src = _find_media(index, media_type, game)
            if not src:
                continue
            folder = _portable_media_folder(export_format, media_type)
            filename_stem = stem
            # Several image roles intentionally share one conventional folder.
            # Give secondary roles a stable suffix so every selected asset survives.
            shared_primary = {"miximages", "screenshots", "covers", "titlescreens"}
            if folder.endswith("images") or folder == "images":
                if media_type not in shared_primary:
                    filename_stem = f"{stem}-{media_type}"
                elif media_type != "miximages" and "miximages" in selected:
                    filename_stem = f"{stem}-{media_type}"
                elif media_type not in {"miximages", "screenshots"}:
                    filename_stem = f"{stem}-{media_type}"
            dest = system_root/folder/parent/(filename_stem + src.suffix.lower())
            dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,dest)
            paths[media_type] = './' + dest.relative_to(system_root).as_posix()
            count += 1
            if media_type == 'videos': videos += 1
        media_paths[key] = paths
    gamelist = system_root/'gamelist.xml'
    _build_portable_gamelist(metadata,media_paths,gamelist,batocera_tags=(export_format in {'batocera','recalbox'}))
    title = EXPORT_PRESETS[export_format]['title']
    destination = f'/userdata/roms/{folder_name}' if export_format == 'batocera' else (f'/recalbox/share/roms/{folder_name}' if export_format == 'recalbox' else f'your ROM folder for {folder_name}')
    (package_root/'README_FIRST.txt').write_text(
        f'{title} export for {system.full_name}.\n\nMerge the contents of the enclosed system folder into {destination}.\n'
        'ROMs are intentionally not copied. gamelist.xml uses portable paths relative to the ROM system folder.\n',encoding='utf-8')
    stage('complete',f'{title} package complete')
    return PackageResult(package_root,count,len(metadata.get('games',[])),videos,0,None,gamelist)


def build_export_package(*, system: SystemEntry, rom_folder: Path, output_parent: Path, scraped_root: Path, gamelist_source: Path, ffmpeg: Optional[Path], options: PackageOptions, log: LogFn=_noop_log, stage: StageFn=_noop_stage, progress: ProgressFn=_noop_progress) -> PackageResult:
    export_format = options.export_format
    if export_format in {'crystal_fantasy', 'crt_fantasy'}:
        return build_crt_fantasy_package(system=system, rom_folder=rom_folder, output_parent=output_parent, scraped_root=scraped_root, gamelist_source=gamelist_source, ffmpeg=ffmpeg, options=options, log=log, stage=stage, progress=progress)
    if export_format == 'console_mode':
        return build_console_mode_package(system=system, output_parent=output_parent, scraped_root=scraped_root, gamelist_source=gamelist_source, ffmpeg=ffmpeg, selected_media=options.selected_media, log=log, stage=stage, progress=progress)
    raise ValueError(f'Unsupported output format: {export_format}. This release supports CRysTal Fantasy and Default Console Mode only.')

def build_crt_fantasy_package(
    *,
    system: SystemEntry,
    rom_folder: Path,
    output_parent: Path,
    scraped_root: Path,
    gamelist_source: Path,
    ffmpeg: Optional[Path],
    options: PackageOptions,
    log: LogFn = _noop_log,
    stage: StageFn = _noop_stage,
    progress: ProgressFn = _noop_progress,
) -> PackageResult:
    output_parent.mkdir(parents=True, exist_ok=True)
    package_root = _unique_package_root(output_parent, system)
    media_root = package_root / "media"
    media_root.mkdir(parents=True, exist_ok=False)
    collisions: list[str] = []
    source_map: list[tuple[str, str]] = []
    claimed: set[str] = set()
    progress_total = _count_convertible_files(scraped_root, options.include_gallery_art)
    progress_state = [0]
    stage("packaging", "Building a fresh CRysTal Fantasy package")
    log(f"Creating new CRysTal Fantasy package: {package_root}")
    if options.optimize_images and ffmpeg is None:
        log("FFmpeg was not available, so original image files will be copied without optimization.")

    if scraped_root.is_dir():
        selected = set(options.selected_media)
        image_jobs = []
        if "covers" in selected:
            image_jobs.extend([(("covers",), media_root, False, False), (("miximages", "marquees"), media_root, False, True)])
        if "backcovers" in selected:
            image_jobs.append((("backcovers",), media_root / "BC", False, False))
        if "screenshots" in selected:
            image_jobs.extend([(("screenshots",), media_root / "BG", False, False), (("fanart", "titlescreens", "miximages"), media_root / "BG", False, True)])
        if "physicalmedia" in selected:
            image_jobs.append((("physicalmedia",), media_root / "PM", True, False))
        if options.include_gallery_art:
            if "marquees" in selected: image_jobs.append((("marquees",), media_root / "marquees", True, False))
            if "titlescreens" in selected: image_jobs.append((("titlescreens",), media_root / "titlescreens", False, False))
            if "fanart" in selected: image_jobs.append((("fanart",), media_root / "fanart", False, False))
            if "miximages" in selected: image_jobs.append((("miximages",), media_root / "miximages", False, False))
        for folders, destination, preserve_alpha, fallback in image_jobs:
            import_image_folders(
                scraped_root,
                folders,
                destination,
                preserve_alpha=preserve_alpha,
                optimize=options.optimize_images,
                ffmpeg=ffmpeg,
                collisions=collisions,
                source_map=source_map,
                claimed=claimed,
                fallback_only=fallback,
                progress=progress,
                progress_state=progress_state,
                progress_total=progress_total,
            )
        video_count = 0
        if "videos" in selected:
            video_count = import_videos(
                scraped_root,
                media_root / "videos",
                ffmpeg,
                options.convert_videos,
                collisions,
                source_map,
                progress,
                progress_state,
                progress_total,
                log,
            )
    else:
        video_count = 0

    copied_gamelist: Optional[Path] = None
    if gamelist_source.is_file():
        copied_gamelist = media_root / "gamelist.xml"
        shutil.copy2(gamelist_source, copied_gamelist)
    metadata = parse_gamelist(gamelist_source, system)

    with (package_root / "SOURCE_MAP.csv").open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["Source", "CRysTal Fantasy Output"])
        writer.writerows(source_map)
    if collisions:
        (package_root / "COLLISIONS.txt").write_text("\n".join(collisions) + "\n", encoding="utf-8")

    media_files = sum(1 for item in media_root.rglob("*") if item.is_file())
    readme = f"""CRysTal Fantasy Ready Media Package
================================

System: {system.full_name} [{system.name}]
Canonical system ID: {system.canonical_id}
Created: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
ROM source used by ES-DE: {rom_folder}
Games listed in gamelist.xml: {len(metadata.get('games', []))}
Media files created: {media_files}
Converted video previews: {video_count}

INSTALL
-------
Copy the enclosed media folder into the root of the matching MiSTer system ROM folder.
Example:
    /media/fat/games/N64/media/

The main media folder includes the standard ES-DE gamelist.xml beside the cover PNGs. CRysTal Fantasy reads its game,
system, genre, year, player, publisher, developer and rating data directly from that
file. No CRysTal Fantasy-specific metadata database is created.

SAFETY
------
- The original ROM folder was exposed to ES-DE through a temporary directory junction.
- No ROM was moved, renamed, edited, or deleted.
- Unsupported source extensions were accepted only through the bridge-owned private ES-DE config.
- The user's normal ES-DE profile was not opened or modified.
- Existing CRysTal Fantasy media was not overwritten; this package was created in a new timestamped folder.
- ES-DE and ScreenScraper remain responsible for scraping. The bridge contains no ScreenScraper API client, and no credentials are included in this package.

Nested ES-DE media is flattened to ROM filename stems because CRysTal Fantasy looks up
media by the selected ROM filename. Duplicate stems are skipped and recorded in
COLLISIONS.txt.
"""
    (package_root / "README_FIRST.txt").write_text(readme, encoding="utf-8")
    progress(progress_total, progress_total, "Complete")
    stage("complete", "CRysTal Fantasy package complete")
    return PackageResult(
        package_root=package_root,
        media_file_count=media_files,
        game_count=len(metadata.get("games", [])),
        video_count=video_count,
        collision_count=len(collisions),
        metadata_path=None,
        copied_gamelist=copied_gamelist,
    )




def _file_signature(path: Path) -> str:
    stat_result = path.stat()
    return f"{stat_result.st_mtime_ns}:{stat_result.st_size}"


def _atomic_copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.name}.{uuid.uuid4().hex}.tmp")
    try:
        shutil.copy2(source, temporary)
        temporary.replace(destination)
    finally:
        temporary.unlink(missing_ok=True)


def _atomic_png(ffmpeg: Path, source: Path, destination: Path, preserve_alpha: bool, optimize: bool = True) -> None:
    destination = destination.with_suffix('.png')
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.stem}.{uuid.uuid4().hex}.tmp.png")
    try:
        if source.suffix.lower() == '.png' and not optimize:
            shutil.copy2(source, temporary)
        else:
            convert_image_with_ffmpeg(ffmpeg, source, temporary, preserve_alpha, optimize=optimize)
        temporary.replace(destination)
    finally:
        temporary.unlink(missing_ok=True)


def _atomic_crystal_video(ffmpeg: Path, source: Path, cfv_destination: Path, cfa_destination: Path) -> None:
    cfv_destination.parent.mkdir(parents=True, exist_ok=True)
    temp_cfv = cfv_destination.with_name(f".{cfv_destination.stem}.{uuid.uuid4().hex}.tmp.cfv")
    temp_cfa = cfa_destination.with_name(f".{cfa_destination.stem}.{uuid.uuid4().hex}.tmp.cfa")
    try:
        convert_video_golden(ffmpeg, source, temp_cfv, temp_cfa)
        temp_cfv.replace(cfv_destination)
        if temp_cfa.is_file():
            temp_cfa.replace(cfa_destination)
        else:
            cfa_destination.unlink(missing_ok=True)
    finally:
        temp_cfv.unlink(missing_ok=True)
        temp_cfa.unlink(missing_ok=True)


def _output_root_for_job(job: SystemJob) -> Path:
    return job.output_root if job.output_root is not None else job.rom_folder


def _iter_media_files(root: Path, media_type: str, extensions: set[str]) -> Iterable[Path]:
    folder = root / media_type
    if not folder.is_dir():
        return ()
    return tuple(
        sorted(
            (item for item in folder.rglob('*') if item.is_file() and item.suffix.lower() in extensions),
            key=lambda item: str(item).lower(),
        )
    )


class LiveSystemMirror:
    """Mirror ES-DE's private scrape into a CRysTal or Console Mode destination while ES-DE runs."""

    def __init__(
        self,
        *,
        job: SystemJob,
        isolated_home: Path,
        state_root: Path,
        ffmpeg: Path,
        options: PackageOptions,
        log: LogFn = _noop_log,
        progress: ProgressFn = _noop_progress,
    ) -> None:
        self.job = job
        self.isolated_home = isolated_home
        self.ffmpeg = ffmpeg
        self.options = options
        self.log = log
        self.progress = progress
        self.output_root = _output_root_for_job(job)
        identity = hashlib.sha1((str(job.rom_folder.resolve()) + '|' + job.system.name + '|' + options.export_format).encode('utf-8')).hexdigest()[:16]
        self.state_path = state_root / f"{identity}.json"
        self.backup_root = state_root.parent / "SafetyBackups" / identity
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self.state: dict[str, dict[str, str]] = self._load_state()
        self.pending: dict[str, str] = {}
        self.failures: dict[str, str] = {}
        self.converted = 0
        self.video_count = 0
        self.game_count = 0
        self.gamelist_synced = False

    def _load_state(self) -> dict[str, dict[str, str]]:
        if not self.state_path.is_file():
            return {}
        try:
            data = json.loads(self.state_path.read_text(encoding='utf-8'))
            return data if isinstance(data, dict) else {}
        except (OSError, json.JSONDecodeError):
            return {}

    def _save_state(self) -> None:
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.state_path.with_suffix('.tmp')
        temporary.write_text(json.dumps(self.state, indent=2, sort_keys=True), encoding='utf-8')
        temporary.replace(self.state_path)

    def _backup_if_unowned(self, destination: Path) -> None:
        key = str(destination.resolve())
        if not destination.is_file() or key in self.state:
            return
        try:
            relative = destination.resolve().relative_to(self.output_root.resolve())
        except ValueError:
            return
        backup = self.backup_root / relative
        if not backup.exists():
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(destination, backup)
            self.log(f"Safety backup created before first overwrite: {relative.as_posix()}")


    def _source_locations(self) -> tuple[Path, Path]:
        _, media_root, gamelist = locate_scrape_outputs(self.isolated_home, self.job.system.name)
        return media_root, gamelist

    def _add_image_candidates(
        self,
        desired: dict[Path, tuple[int, Path, bool]],
        source_root: Path,
        source_type: str,
        destination_folder: Path,
        priority: int,
        preserve_alpha: bool,
        suffix: str = '',
    ) -> None:
        for source in _iter_media_files(source_root, source_type, set(IMAGE_EXTENSIONS)):
            destination = destination_folder / f"{source.stem}{suffix}.png"
            previous = desired.get(destination)
            if previous is None or priority > previous[0]:
                desired[destination] = (priority, source, preserve_alpha)

    def _desired_images(self, media_root: Path) -> dict[Path, tuple[int, Path, bool]]:
        desired: dict[Path, tuple[int, Path, bool]] = {}
        selected = set(self.options.selected_media)
        output_media = self.output_root / 'media'
        if self.options.export_format == 'console_mode':
            if 'covers' in selected:
                self._add_image_candidates(desired, media_root, 'miximages', output_media, 40, False)
                self._add_image_candidates(desired, media_root, 'covers', output_media, 100, False)
            if 'screenshots' in selected:
                self._add_image_candidates(desired, media_root, 'titlescreens', output_media, 30, False, '-BG')
                self._add_image_candidates(desired, media_root, 'fanart', output_media, 40, False, '-BG')
                self._add_image_candidates(desired, media_root, 'screenshots', output_media, 100, False, '-BG')
            return desired

        if 'covers' in selected:
            self._add_image_candidates(desired, media_root, 'marquees', output_media, 20, True)
            self._add_image_candidates(desired, media_root, 'miximages', output_media, 40, False)
            self._add_image_candidates(desired, media_root, 'covers', output_media, 100, False)
        if 'screenshots' in selected:
            self._add_image_candidates(desired, media_root, 'miximages', output_media / 'BG', 20, False)
            self._add_image_candidates(desired, media_root, 'titlescreens', output_media / 'BG', 30, False)
            self._add_image_candidates(desired, media_root, 'fanart', output_media / 'BG', 40, False)
            self._add_image_candidates(desired, media_root, 'screenshots', output_media / 'BG', 100, False)
        if 'backcovers' in selected:
            self._add_image_candidates(desired, media_root, 'backcovers', output_media / 'BC', 100, False)
        if 'physicalmedia' in selected:
            self._add_image_candidates(desired, media_root, 'physicalmedia', output_media / 'PM', 100, True)
        if self.options.include_gallery_art:
            for media_type, preserve_alpha in (
                ('marquees', True), ('titlescreens', False), ('fanart', False),
                ('miximages', False), ('3dboxes', True),
            ):
                if media_type in selected:
                    self._add_image_candidates(desired, media_root, media_type, output_media / media_type, 100, preserve_alpha)
        return desired

    def _desired_videos(self, media_root: Path) -> dict[Path, Path]:
        if self.options.export_format != 'crystal_fantasy' or 'videos' not in set(self.options.selected_media):
            return {}
        destination_folder = self.output_root / 'media' / 'videos'
        return {
            destination_folder / f"{source.stem}.cfv": source
            for source in _iter_media_files(media_root, 'videos', set(VIDEO_EXTENSIONS))
        }

    def _desired_manuals(self, media_root: Path) -> dict[Path, Path]:
        if self.options.export_format != 'crystal_fantasy' or 'manuals' not in set(self.options.selected_media):
            return {}
        destination_folder = self.output_root / 'media' / 'manuals'
        return {
            destination_folder / source.name: source
            for source in _iter_media_files(media_root, 'manuals', {'.pdf'})
        }


    def _failed(self, key: str, source: Path, exc: Exception | str) -> None:
        self.failures[key] = f"{source.name}: {exc}"

    def _succeeded(self, key: str) -> None:
        self.failures.pop(key, None)

    def raise_for_unresolved_failures(self) -> None:
        if not self.failures:
            return
        examples = list(self.failures.values())[:5]
        extra = len(self.failures) - len(examples)
        detail = "\n".join(f"• {item}" for item in examples)
        if extra > 0:
            detail += f"\n• ...and {extra} more"
        raise RuntimeError(
            "Final conversion did not finish for every downloaded item. "
            "The temporary ES-DE originals were preserved so nothing is lost.\n\n" + detail
        )

    def _stable(self, key: str, signature: str, force: bool) -> bool:
        if force:
            return True
        if self.pending.get(key) == signature:
            return True
        self.pending[key] = signature
        return False

    def sync_once(self, *, force: bool = False, prune: bool = False) -> tuple[int, int]:
        media_root, gamelist = self._source_locations()
        desired_images = self._desired_images(media_root) if media_root.is_dir() else {}
        desired_videos = self._desired_videos(media_root) if media_root.is_dir() else {}
        desired_manuals = self._desired_manuals(media_root) if media_root.is_dir() else {}
        desired_keys: set[str] = set()
        changed = 0
        total = len(desired_images) + len(desired_videos) + len(desired_manuals) + (1 if gamelist.is_file() else 0)
        current = 0

        for destination, (_, source, preserve_alpha) in desired_images.items():
            current += 1
            key = str(destination.resolve())
            desired_keys.add(key)
            try:
                signature = _file_signature(source)
            except OSError as exc:
                self._failed(key, source, exc)
                continue
            existing = self.state.get(key)
            if existing and existing.get('source') == str(source) and existing.get('signature') == signature and destination.is_file():
                continue
            if not self._stable(key, signature, force):
                continue
            try:
                self._backup_if_unowned(destination)
                _atomic_png(self.ffmpeg, source, destination, preserve_alpha, self.options.optimize_images)
                self.state[key] = {'source': str(source), 'signature': signature, 'kind': 'image'}
                self.pending.pop(key, None)
                self._succeeded(key)
                self.converted += 1
                changed += 1
                self.log(f"PNG8 synced: {self.job.system.name} / {destination.name}")
                self.progress(current, max(1, total), destination.name)
            except Exception as exc:
                self._failed(key, source, exc)
                self.log(f"Image sync retry queued: {source.name} — {exc}")

        for cfv_destination, source in desired_videos.items():
            current += 1
            key = str(cfv_destination.resolve())
            desired_keys.add(key)
            cfa_destination = cfv_destination.with_suffix('.cfa')
            desired_keys.add(str(cfa_destination.resolve()))
            try:
                signature = _file_signature(source)
            except OSError as exc:
                self._failed(key, source, exc)
                continue
            existing = self.state.get(key)
            if existing and existing.get('source') == str(source) and existing.get('signature') == signature and cfv_destination.is_file():
                continue
            if not self._stable(key, signature, force):
                continue
            try:
                self._backup_if_unowned(cfv_destination)
                self._backup_if_unowned(cfa_destination)
                _atomic_crystal_video(self.ffmpeg, source, cfv_destination, cfa_destination)
                record = {'source': str(source), 'signature': signature, 'kind': 'video'}
                self.state[key] = record
                if cfa_destination.is_file():
                    self.state[str(cfa_destination.resolve())] = record
                self.pending.pop(key, None)
                self._succeeded(key)
                self.converted += 1
                self.video_count += 1
                changed += 1
                self.log(f"Video synced: {self.job.system.name} / {source.name}")
                self.progress(current, max(1, total), source.name)
            except Exception as exc:
                self._failed(key, source, exc)
                self.log(f"Video sync retry queued: {source.name} — {exc}")

        for destination, source in desired_manuals.items():
            current += 1
            key = str(destination.resolve())
            desired_keys.add(key)
            try:
                signature = _file_signature(source)
            except OSError as exc:
                self._failed(key, source, exc)
                continue
            existing = self.state.get(key)
            if existing and existing.get('source') == str(source) and existing.get('signature') == signature and destination.is_file():
                continue
            if not self._stable(key, signature, force):
                continue
            try:
                self._backup_if_unowned(destination)
                _atomic_copy(source, destination)
                self.state[key] = {'source': str(source), 'signature': signature, 'kind': 'manual'}
                self.pending.pop(key, None)
                self._succeeded(key)
                self.converted += 1
                changed += 1
                self.log(f"Manual synced: {self.job.system.name} / {destination.name}")
                self.progress(current, max(1, total), destination.name)
            except Exception as exc:
                self._failed(key, source, exc)
                self.log(f"Manual sync retry queued: {source.name} — {exc}")

        if self.options.export_format in {'crystal_fantasy', 'console_mode'} and gamelist.is_file():
            current += 1
            destination = self.output_root / 'media' / 'gamelist.xml'
            key = str(destination.resolve())
            desired_keys.add(key)
            try:
                map_signature = hashlib.sha1(json.dumps(self.job.scrape_path_map, sort_keys=True).encode('utf-8')).hexdigest()
                signature = _file_signature(gamelist) + '|' + map_signature
                existing = self.state.get(key)
                if not (existing and existing.get('signature') == signature and destination.is_file()):
                    if self._stable(key, signature, force):
                        self._backup_if_unowned(destination)
                        if self.job.merge_existing_gamelist:
                            merge_gamelist_paths(gamelist, destination, self.job.scrape_path_map)
                        else:
                            rewrite_gamelist_paths(gamelist, destination, self.job.scrape_path_map)
                        self.state[key] = {'source': str(gamelist), 'signature': signature, 'kind': 'gamelist'}
                        self.pending.pop(key, None)
                        self._succeeded(key)
                        changed += 1
                        self.gamelist_synced = True
                        self.log(f"gamelist.xml synced: {self.job.system.name}")
                try:
                    count_source = destination if destination.is_file() else gamelist
                    self.game_count = len(parse_gamelist(count_source, self.job.system).get('games', []))
                except Exception:
                    pass
            except Exception as exc:
                self._failed(key, gamelist, exc)
                self.log(f"gamelist.xml sync retry queued: {self.job.system.name} — {exc}")

        # Failures for media that ES-DE later removed are no longer unresolved.
        for failed_key in tuple(self.failures):
            if failed_key not in desired_keys:
                self.failures.pop(failed_key, None)

        if prune and (media_root.is_dir() or gamelist.is_file()):
            for key in list(self.state):
                if key in desired_keys:
                    continue
                path = Path(key)
                try:
                    if path_is_within(path, self.output_root):
                        path.unlink(missing_ok=True)
                        self.state.pop(key, None)
                        changed += 1
                        self.log(f"Removed stale bridge output: {path.name}")
                except OSError:
                    pass

        if changed or force:
            self._save_state()
        media_files = sum(1 for item in (self.output_root / 'media').rglob('*') if item.is_file()) if (self.output_root / 'media').is_dir() else 0
        return changed, media_files


class BridgeCore:
    def __init__(self, app_root: Path, log: LogFn = _noop_log):
        self.locations = BridgeLocations.default(app_root)
        self.log = log
        for path in (self.locations.data_root, self.locations.isolated_home, self.locations.sessions_root):
            path.mkdir(parents=True, exist_ok=True)

    def load_preferences(self) -> dict:
        try:
            return json.loads(self.locations.preferences_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}

    def save_preferences(self, values: dict) -> None:
        self.locations.data_root.mkdir(parents=True, exist_ok=True)
        temporary = self.locations.preferences_path.with_suffix(".tmp")
        temporary.write_text(json.dumps(values, indent=2), encoding="utf-8")
        temporary.replace(self.locations.preferences_path)

    def clean_stale_junctions(self) -> int:
        removed = 0
        for manifest_path in self.locations.sessions_root.rglob("session.json"):
            try:
                data = json.loads(manifest_path.read_text(encoding="utf-8"))
                link = Path(data.get("junction_path", ""))
                owned_link = path_is_within(link, self.locations.sessions_root) or path_is_within(
                    link, self.locations.isolated_home / "ROMs"
                )
                if link and owned_link and link.exists() and is_reparse_point(link):
                    remove_windows_junction_safely(link)
                    removed += 1
            except Exception:
                continue
        return removed

    def reset_isolated_profile(self) -> None:
        self.clean_stale_junctions()
        rom_root = self.locations.isolated_home / "ROMs"
        if rom_root.is_dir():
            for child in rom_root.iterdir():
                if child.exists() and is_reparse_point(child):
                    remove_windows_junction_safely(child)
        path = self.locations.isolated_home
        if path.exists():
            safe_remove_tree(path, self.locations.data_root)
        path.mkdir(parents=True, exist_ok=True)

    def _write_manifest(self, path: Path, data: dict) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".tmp")
        temporary.write_text(json.dumps(data, indent=2), encoding="utf-8")
        temporary.replace(path)

    def run_live_session(
        self,
        config: BatchSessionConfig,
        *,
        stage: StageFn = _noop_stage,
        progress: ProgressFn = _noop_progress,
    ) -> BatchResult:
        """Run one private ES-DE session while live-converting selected systems in the background."""
        if os.name != 'nt':
            raise RuntimeError('The private ES-DE bridge session currently runs on Windows only.')
        if not config.esde_executable.is_file() or find_esde_systems_xml(config.esde_executable) is None:
            raise FileNotFoundError('Select ES-DE.exe from a complete ES-DE installation.')
        if not config.jobs:
            raise RuntimeError('Choose at least one ROM system folder.')
        ffmpeg = resolve_ffmpeg(config.ffmpeg_executable, self.locations.app_root)
        if ffmpeg is None:
            raise FileNotFoundError('ffmpeg.exe is required so every exported image can be guaranteed PNG and videos can be converted safely.')

        stage('prepare', 'Preparing private ES-DE systems')
        rom_root = self.locations.isolated_home / 'ROMs'
        rom_root.mkdir(parents=True, exist_ok=True)
        # Recover cleanly after a prior crash: this directory is bridge-owned and may
        # contain only temporary junctions created by this application.
        for child in tuple(rom_root.iterdir()):
            if is_reparse_point(child):
                remove_windows_junction_safely(child)
        stale_folder_views = self.locations.isolated_home / 'FolderGameViews'
        if stale_folder_views.exists():
            safe_remove_tree(stale_folder_views, self.locations.isolated_home)
        junctions: list[Path] = []
        adapted_jobs: list[SystemJob] = []
        system_paths: list[tuple[SystemEntry, Path]] = []
        used_names: set[str] = set()
        cache_identity_root = self.locations.data_root / 'CacheIdentity'
        cache_identity_root.mkdir(parents=True, exist_ok=True)

        for original_job in config.jobs:
            if not original_job.rom_folder.is_dir():
                raise FileNotFoundError(f'ROM folder not found: {original_job.rom_folder}')
            if str(original_job.rom_folder).startswith('\\\\'):
                raise RuntimeError('Network/UNC ROM folders are not supported by safe junction mode. Use a local or mapped drive.')
            adapted_system, report = extension_compatible_system(original_job.rom_folder, original_job.system)
            matching = count_game_entries(original_job.rom_folder, adapted_system)
            if matching <= 0:
                raise RuntimeError(f'No likely game files or disc-game folders were found for {original_job.system.full_name}: {original_job.rom_folder}')
            junction_name = adapted_system.system_folder or adapted_system.name
            if junction_name.lower() in used_names:
                raise RuntimeError(f'Two selected folders resolve to the same ES-DE system name: {junction_name}. Choose one folder per system.')
            used_names.add(junction_name.lower())
            junction = rom_root / junction_name
            if junction.exists():
                if is_reparse_point(junction):
                    remove_windows_junction_safely(junction)
                else:
                    raise RuntimeError(f'Safety stop: the private ROM location is occupied by a normal folder: {junction}')

            marker = cache_identity_root / f'{safe_filename(adapted_system.name)}.json'
            previous_path = ''
            if marker.is_file():
                try:
                    previous_path = str(json.loads(marker.read_text(encoding='utf-8')).get('rom_folder', ''))
                except Exception:
                    previous_path = ''
            current_path = str(original_job.rom_folder.resolve())
            if previous_path and os.path.normcase(previous_path) != os.path.normcase(current_path):
                self.log(f'ROM library changed for {adapted_system.name}; clearing only its private cached scrape.')
                for profile_root in esde_profile_roots(self.locations.isolated_home):
                    for owned in (
                        profile_root / 'downloaded_media' / adapted_system.name,
                        profile_root / 'gamelists' / adapted_system.name,
                    ):
                        if owned.exists():
                            safe_remove_tree(owned, self.locations.isolated_home)
            marker.write_text(json.dumps({'rom_folder': current_path}, indent=2), encoding='utf-8')

            folder_view_root = self.locations.isolated_home / 'FolderGameViews' / safe_filename(adapted_system.name)
            if original_job.selected_game_paths:
                folder_system, path_map, catalog_count = build_selective_game_catalog(
                    original_job.rom_folder, folder_view_root, adapted_system, original_job.selected_game_paths
                )
                if catalog_count <= 0:
                    raise RuntimeError(f'Smart Resume found no selected games for {adapted_system.full_name}.')
                scrape_path = folder_view_root
                adapted_system = folder_system
                matching = catalog_count
                self.log(f'Smart Resume: private ES-DE sees only {catalog_count} new/incomplete game(s).')
            else:
                folder_system, path_map, catalog_count = build_folder_game_catalog(
                    original_job.rom_folder, folder_view_root, adapted_system
                )
                if catalog_count:
                    scrape_path = folder_view_root
                    adapted_system = folder_system
                    matching = catalog_count
                    self.log(f'Folder Games: {len(path_map)} top-level game folder(s) collapsed to one entry each.')
                else:
                    create_windows_junction(junction, original_job.rom_folder)
                    junctions.append(junction)
                    scrape_path = junction
            output_root = original_job.output_root or original_job.rom_folder
            output_root.mkdir(parents=True, exist_ok=True)
            adapted_job = SystemJob(
                original_job.rom_folder, adapted_system, output_root, path_map,
                original_job.selected_game_paths, original_job.merge_existing_gamelist, original_job.prune_outputs
            )
            adapted_jobs.append(adapted_job)
            system_paths.append((adapted_system, scrape_path))
            self.log(f'{adapted_system.full_name}: {matching} game(s) ready.')
            if report.masquerade_active:
                self.log(f'Extension Masquerade: {adapted_system.name} privately accepts {", ".join(report.added_extensions)}.')

        mirrors: list[LiveSystemMirror] = []
        process: Optional[subprocess.Popen] = None
        try:
            configs = write_multi_compatibility_system_configs(system_paths, self.locations.isolated_home)
            counts = validate_multi_bridge_rom_visibility(configs, system_paths)
            settings_paths = configure_esde_scraper_profiles(self.locations.isolated_home, config.scrape, rom_root)
            canonical_settings = settings_paths[0]
            validate_private_scraper_region(canonical_settings, config.scrape.region)
            settings_mtime_ns = canonical_settings.stat().st_mtime_ns
            self.log(
                f'Private ES-DE profile prepared for {len(adapted_jobs)} system(s), '
                f'{sum(counts.values())} visible game files. Region lock: {config.scrape.region.upper()}.'
            )
            state_root = self.locations.data_root / 'LiveSyncState'
            mirrors = [
                LiveSystemMirror(
                    job=job,
                    isolated_home=self.locations.isolated_home,
                    state_root=state_root,
                    ffmpeg=ffmpeg,
                    options=config.options,
                    log=self.log,
                    progress=progress,
                )
                for job in adapted_jobs
            ]
            stage('esde', 'ES-DE is open — live PNG/video sync is running')
            args = [str(config.esde_executable), '--home', str(self.locations.isolated_home), '--no-update-check', '--debug']
            process = subprocess.Popen(args, cwd=str(config.esde_executable.parent))
            wait_for_esde_region_handshake(
                process, canonical_settings, config.scrape.region, settings_mtime_ns
            )
            self.log(f'ES-DE confirmed scraper region {config.scrape.region.upper()} before scraping.')
            while process.poll() is None:
                for mirror in mirrors:
                    mirror.sync_once()
                time.sleep(0.75)
            self.log(f'ES-DE closed with exit code {process.returncode}. Finishing the last changed files...')
            # Give Windows file handles a moment to settle, then force one final authoritative pass.
            time.sleep(0.5)
            for mirror in mirrors:
                mirror.sync_once(force=True, prune=mirror.job.prune_outputs)
            for mirror in mirrors:
                mirror.raise_for_unresolved_failures()
        finally:
            if not config.scrape.remember_password:
                scrub_screenscraper_password(self.locations.isolated_home)
            stage('cleanup', 'Disconnecting ROM folders safely')
            for junction in reversed(junctions):
                remove_windows_junction_safely(junction)
            folder_views = self.locations.isolated_home / 'FolderGameViews'
            if folder_views.exists():
                safe_remove_tree(folder_views, self.locations.isolated_home)

        outputs = [mirror.output_root for mirror in mirrors]
        total_media = sum(sum(1 for item in (root / 'media').rglob('*') if item.is_file()) if (root / 'media').is_dir() else 0 for root in outputs)
        total_games = sum(mirror.game_count for mirror in mirrors)
        total_videos = sum(mirror.video_count for mirror in mirrors)
        session_activity = sum(mirror.converted + (1 if mirror.gamelist_synced else 0) for mirror in mirrors)
        if session_activity == 0:
            diagnostic = collect_esde_diagnostic(self.locations.isolated_home)
            detail = f'\n\nRecent ES-DE diagnostics:\n{diagnostic}' if diagnostic else ''
            raise RuntimeError('ES-DE closed without producing scraped metadata or selected media. The private profile and ROMs were left safe.' + detail)
        stage('cleanup', 'Deleting temporary ES-DE downloads')
        purge_private_esde_home(self.locations.isolated_home, self.locations.data_root, self.log)
        stage('complete', 'Live scrape sync complete — temporary originals deleted')
        return BatchResult(len(mirrors), total_games, total_media, total_videos, outputs)


    def run_session(
        self,
        config: SessionConfig,
        *,
        stage: StageFn = _noop_stage,
        progress: ProgressFn = _noop_progress,
    ) -> PackageResult:
        if os.name != "nt":
            raise RuntimeError("The isolated ES-DE bridge session currently runs on Windows only.")
        if not config.esde_executable.is_file():
            raise FileNotFoundError("Select the real ES-DE executable.")
        if find_esde_systems_xml(config.esde_executable) is None:
            raise FileNotFoundError("That executable does not appear to belong to a complete ES-DE installation.")
        if not config.rom_folder.is_dir():
            raise FileNotFoundError("Select a valid ROM system folder.")
        session_system, extension_report = extension_compatible_system(config.rom_folder, config.system)
        matching_roms = count_game_entries(config.rom_folder, session_system)
        if matching_roms <= 0:
            expected = " ".join(config.system.extensions[:18]) or "the extensions listed by ES-DE"
            raise RuntimeError(
                f"No likely game files were found for {config.system.full_name}. "
                f"ES-DE normally accepts: {expected}. The bridge can masquerade other game extensions, "
                "but ignores artwork, text files, configuration files, saves, and other sidecars."
            )
        if str(config.rom_folder).startswith("\\\\"):
            raise RuntimeError("Network/UNC ROM folders are not supported by safe junction mode. Use a local or mapped drive.")
        config.output_parent.mkdir(parents=True, exist_ok=True)
        ffmpeg = resolve_ffmpeg(config.ffmpeg_executable, self.locations.app_root)
        ffmpeg_required = (
            (config.options.export_format == "crystal_fantasy" and config.options.convert_videos and "videos" in config.options.selected_media)
            or (config.options.export_format == "console_mode" and bool({"covers", "screenshots"} & set(config.options.selected_media)))
        )
        if ffmpeg_required and ffmpeg is None:
            raise FileNotFoundError("ffmpeg.exe is required by the selected export preset. Select it on the Library page.")

        session_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:8]
        session_root = self.locations.sessions_root / session_id
        # ES-DE officially resolves its default ROM directory beneath the --home path.
        # Keeping the junction here makes first-run onboarding automatic and bridge-owned.
        rom_root = self.locations.isolated_home / "ROMs"
        junction_path = rom_root / config.system.system_folder
        manifest_path = session_root / "session.json"
        session_root.mkdir(parents=True, exist_ok=True)
        rom_root.mkdir(parents=True, exist_ok=True)
        if junction_path.exists():
            if is_reparse_point(junction_path):
                remove_windows_junction_safely(junction_path)
            else:
                raise RuntimeError(
                    f"Safety stop: the bridge ROM location is occupied by a normal folder: {junction_path}. "
                    "Reset the isolated profile or remove that bridge-owned folder manually."
                )
        manifest = {
            "created": datetime.now().isoformat(),
            "esde_executable": str(config.esde_executable),
            "system": config.system.name,
            "rom_folder": str(config.rom_folder),
            "stock_extensions": list(extension_report.original_extensions),
            "masqueraded_extensions": list(extension_report.added_extensions),
            "junction_path": str(junction_path),
            "status": "Preparing",
        }
        self._write_manifest(manifest_path, manifest)

        for profile_root in esde_profile_roots(self.locations.isolated_home):
            for owned in (
                profile_root / "downloaded_media" / config.system.name,
                profile_root / "gamelists" / config.system.name,
            ):
                if owned.exists():
                    safe_remove_tree(owned, self.locations.isolated_home)

        stage("prepare", "Preparing a private ES-DE session")
        self.log(f"Verified {matching_roms} likely game file(s) for {config.system.full_name}.")
        if extension_report.masquerade_active:
            details = ", ".join(
                f"{extension} ({extension_report.counts.get(extension, 0)})"
                for extension in extension_report.added_extensions
            )
            self.log(
                "Extension Masquerade active: private ES-DE will accept " + details +
                ". Original files and filenames remain unchanged."
            )
        self.log(f"Creating temporary ROM junction: {junction_path}")
        create_windows_junction(junction_path, config.rom_folder)
        try:
            configs = write_compatibility_system_configs(
                session_system,
                self.locations.isolated_home,
                junction_path,
            )
            visible_roms = validate_bridge_rom_visibility(configs, session_system, junction_path)
            settings_paths = configure_esde_scraper_profiles(self.locations.isolated_home, config.scrape, rom_root)
            canonical_settings = settings_paths[0]
            validate_private_scraper_region(canonical_settings, config.scrape.region)
            settings_mtime_ns = canonical_settings.stat().st_mtime_ns
            self.log(f"Prepared ES-DE 3.x+ and legacy profile layouts; {visible_roms} ROM(s) visible through the bridge.")
            self.log(
                f"Applied ScreenScraper account, content, language and strict region lock "
                f"{config.scrape.region.upper()} to the private profile."
            )
            self.log(f"Direct ROM path embedded in private system config: {junction_path}")
            self.log(f"Compatibility configs: {configs[0]} | {configs[1]}")
            manifest["status"] = "ES-DE running"
            self._write_manifest(manifest_path, manifest)
            stage("esde", "ES-DE is open — scrape the selected system, then exit ES-DE")
            self.log("Opening isolated ES-DE. Waiting for it to close...")
            args = [
                str(config.esde_executable),
                "--home", str(self.locations.isolated_home),
                "--no-update-check",
                "--debug",
            ]
            process = subprocess.Popen(args, cwd=str(config.esde_executable.parent))
            wait_for_esde_region_handshake(
                process, canonical_settings, config.scrape.region, settings_mtime_ns
            )
            self.log(f"ES-DE confirmed scraper region {config.scrape.region.upper()} before scraping.")
            exit_code = process.wait()
            self.log(f"ES-DE closed with exit code {exit_code}.")
            if not config.scrape.remember_password:
                scrub_screenscraper_password(self.locations.isolated_home)
        finally:
            stage("cleanup", "Safely disconnecting the ROM folder")
            self.log("Removing temporary ROM junction...")
            remove_windows_junction_safely(junction_path)

        manifest["status"] = "Packaging"
        self._write_manifest(manifest_path, manifest)
        active_profile, scraped_root, gamelist_source = locate_scrape_outputs(
            self.locations.isolated_home,
            config.system.name,
        )
        self.log(f"Detected active ES-DE profile layout: {active_profile.name}")
        if not scraped_root.is_dir() and not gamelist_source.is_file():
            diagnostic = collect_esde_diagnostic(self.locations.isolated_home)
            detail = f"\n\nRecent ES-DE diagnostics:\n{diagnostic}" if diagnostic else ""
            raise RuntimeError(
                f"ES-DE closed, but no scraped media or gamelist was found for {config.system.full_name}. "
                "The bridge verified matching ROMs and supplied an absolute one-system path, so check whether "
                "ES-DE remained on its first-run setup screen or the scrape was cancelled. "
                "Nothing in the ROM folder or normal ES-DE profile was changed."
                + detail
            )
        result = build_export_package(
            system=session_system,
            rom_folder=config.rom_folder,
            output_parent=config.output_parent,
            scraped_root=scraped_root,
            gamelist_source=gamelist_source,
            ffmpeg=ffmpeg,
            options=config.options,
            log=self.log,
            stage=stage,
            progress=progress,
        )
        manifest["status"] = "Complete"
        manifest["output"] = str(result.package_root)
        self._write_manifest(manifest_path, manifest)
        stage("cleanup", "Deleting temporary ES-DE downloads")
        purge_private_esde_home(self.locations.isolated_home, self.locations.data_root, self.log)
        if not config.options.keep_staging:
            safe_remove_tree(session_root, self.locations.sessions_root)
        return result

    def package_current_isolated_scrape(
        self,
        config: SessionConfig,
        *,
        stage: StageFn = _noop_stage,
        progress: ProgressFn = _noop_progress,
    ) -> PackageResult:
        ffmpeg = resolve_ffmpeg(config.ffmpeg_executable, self.locations.app_root)
        _, scraped_root, gamelist_source = locate_scrape_outputs(
            self.locations.isolated_home,
            config.system.name,
        )
        if not scraped_root.is_dir() and not gamelist_source.is_file():
            raise RuntimeError("No saved isolated scrape exists for the selected system yet.")
        session_system, _ = extension_compatible_system(config.rom_folder, config.system)
        result = build_export_package(
            system=session_system,
            rom_folder=config.rom_folder,
            output_parent=config.output_parent,
            scraped_root=scraped_root,
            gamelist_source=gamelist_source,
            ffmpeg=ffmpeg,
            options=config.options,
            log=self.log,
            stage=stage,
            progress=progress,
        )
        stage("cleanup", "Deleting temporary ES-DE downloads")
        purge_private_esde_home(self.locations.isolated_home, self.locations.data_root, self.log)
        return result
