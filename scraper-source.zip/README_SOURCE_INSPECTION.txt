CRysTal Fantasy Scraper v0.5.8 — Source Inspection Package
===========================================================

This package contains the exact Python source used by the v0.5.8 Windows build.

Important files:

  source/CRysTal_Fantasy_Scraper.pyw
      Original Windows GUI entry point used by the build.

  source/CRysTal_Fantasy_Scraper.py
      Byte-identical review copy of the .pyw file. The .py extension is provided
      only so GitHub and text editors display it as ordinary Python source.

  source/bridge_core.py
      The main scraper/bridge implementation, including filesystem, XML,
      download, conversion, packaging, and ES-DE integration behavior.

  build/BUILD_FINAL_WINDOWS_EXE.bat
      The PyInstaller build command used to produce the Windows executable.

  tests/test_bridge.py
      The regression tests supplied with v0.5.8.

The .pyw and .py entry-point files contain identical bytes. A .pyw file is
ordinary Python source; Windows simply runs it without opening a console window.

Verification performed for this package:

  - Both Python source files compile with Python 3.
  - 40 regression tests pass.
  - SHA256SUMS.txt records every included file.

No executable is included in this inspection package. Reviewers can inspect the
source directly or build their own executable using the supplied build script.
