from __future__ import annotations

import hashlib
import json
import shutil
import struct
import subprocess
import tempfile
import unittest
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from unittest.mock import patch

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from bridge_core import (
    EXPORT_PRESETS,
    CRYSTAL_RECOMMENDED_MEDIA,
    LiveSystemMirror,
    MISTER_FOLDER_REGISTRY,
    PackageOptions,
    ScrapeOptions,
    SystemEntry,
    SystemJob,
    build_crt_fantasy_package,
    build_console_mode_package,
    build_folder_game_catalog,
    build_selective_game_catalog,
    convert_image_with_ffmpeg,
    canonical_system_id,
    configure_esde_scraper_profiles,
    count_matching_roms,
    count_game_entries,
    analyze_smart_resume,
    discover_folder_games,
    discover_mister_system_folders,
    esde_profile_roots,
    extension_compatible_system,
    install_managed_esde_from_archive,
    install_managed_ffmpeg_from_archive,
    is_managed_esde,
    is_managed_ffmpeg,
    load_esde_systems,
    managed_esde_executable,
    managed_ffmpeg_executable,
    normalized_genre_tags,
    pack_cfv_jpeg_frames,
    parse_gamelist,
    purge_private_esde_home,
    read_private_esde_settings,
    rewrite_gamelist_paths,
    resolve_mister_folder_system,
    merge_gamelist_paths,
    safe_remove_tree,
    scan_source_extensions,
    scrub_screenscraper_password,
    select_esde_windows_portable_asset,
    suggest_system,
    uninstall_managed_esde,
    uninstall_managed_ffmpeg,
    validate_bridge_rom_visibility,
    validate_multi_bridge_rom_visibility,
    write_cfa,
    write_compatibility_system_configs,
    write_multi_compatibility_system_configs,
    validate_private_scraper_region, wait_for_esde_region_handshake,
)


class BridgeTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(prefix="crystal_scraper_test_")
        self.root = Path(self.temp.name)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def make_esde(self) -> Path:
        exe = self.root / "ES-DE" / "ES-DE.exe"
        exe.parent.mkdir(parents=True)
        exe.write_bytes(b"fake")
        systems = exe.parent / "resources" / "systems" / "windows" / "es_systems.xml"
        systems.parent.mkdir(parents=True)
        systems.write_text(
            """<?xml version='1.0'?>
<systemList>
  <system><name>arcade</name><fullname>Arcade</fullname><path>%ROMPATH%/arcade</path><extension>.zip .7z</extension><platform>arcade</platform></system>
  <system><name>megadrive</name><fullname>Sega Mega Drive</fullname><path>%ROMPATH%/megadrive</path><extension>.zip .md .bin</extension><platform>megadrive</platform></system>
  <system><name>n64</name><fullname>Nintendo 64</fullname><path>%ROMPATH%/n64</path><extension>.zip .z64 .n64</extension><platform>n64</platform></system>
</systemList>
""",
            encoding="utf-8",
        )
        return exe

    def make_system(self, name="megadrive", full="Sega Mega Drive", extensions=(".zip", ".bin")) -> SystemEntry:
        return SystemEntry(
            name=name,
            full_name=full,
            rom_path=f"%ROMPATH%/{name}",
            extensions=extensions,
            outer_xml=(
                f"<system><name>{name}</name><fullname>{full}</fullname>"
                f"<path>%ROMPATH%/{name}</path><extension>{' '.join(extensions)}</extension>"
                f"<command label='Test'>fake.exe %ROM%</command><platform>{name}</platform><theme>{name}</theme></system>"
            ),
            source_xml="test",
        )

    def make_gamelist(self, folder: Path, names=("Street Fighter II", "Phantasy Star IV")) -> Path:
        path = folder / "gamelist.xml"
        path.parent.mkdir(parents=True, exist_ok=True)
        games = []
        for name in names:
            extension = ".zip" if "Street" in name else ".bin"
            genre = "Fighting" if "Street" in name else "Role-Playing / JRPG"
            games.append(f"<game><path>./{name}{extension}</path><name>{name}</name><releasedate>19920206T000000</releasedate><genre>{genre}</genre><players>1-2</players><rating>0.9</rating></game>")
        path.write_text("<?xml version='1.0'?><gameList>" + "".join(games) + "</gameList>", encoding="utf-8")
        return path

    def make_scrape_layout(self, isolated: Path, system_name="megadrive") -> tuple[Path, Path]:
        modern, _ = esde_profile_roots(isolated)
        media = modern / "downloaded_media" / system_name
        gamelist = modern / "gamelists" / system_name / "gamelist.xml"
        for folder in ("covers", "screenshots", "physicalmedia", "videos", "marquees"):
            (media / folder).mkdir(parents=True, exist_ok=True)
        return media, gamelist

    def generate_image(self, destination: Path, color: str, suffix: str = ".jpg") -> Path:
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            self.skipTest("ffmpeg not available")
        destination = destination.with_suffix(suffix)
        destination.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run([
            ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi", "-i", f"color=c={color}:s=96x96:d=0.1",
            "-frames:v", "1", str(destination),
        ], check=True)
        return destination


    def test_crystal_recommended_media_uses_back_covers_not_logos(self) -> None:
        options = ScrapeOptions()
        self.assertIn("backcovers", options.media_types)
        self.assertNotIn("marquees", options.media_types)

    def test_esde_release_selector_prefers_windows_portable_zip(self) -> None:
        payload = [{
            "tag_name": "v3.9.0",
            "assets": {"links": [
                {"name": "ES-DE Windows installer.exe", "url": "https://example.invalid/setup.exe"},
                {"name": "ES-DE Linux AppImage", "url": "https://example.invalid/es-de.AppImage"},
                {"name": "ES-DE Windows x64 portable.zip", "direct_asset_url": "https://example.invalid/es-de-win64-portable.zip"},
            ]},
        }]
        asset = select_esde_windows_portable_asset(payload)
        self.assertEqual(asset["url"], "https://example.invalid/es-de-win64-portable.zip")
        self.assertEqual(asset["version"], "v3.9.0")

    def test_managed_esde_install_and_uninstall_are_private(self) -> None:
        archive = self.root / "esde-portable.zip"
        with zipfile.ZipFile(archive, "w") as bundle:
            bundle.writestr("ES-DE/ES-DE.exe", b"fake executable")
            bundle.writestr(
                "ES-DE/resources/systems/windows/es_systems.xml",
                "<?xml version='1.0'?><systemList><system><name>arcade</name><fullname>Arcade</fullname><path>%ROMPATH%/arcade</path><extension>.zip</extension></system></systemList>",
            )
        installed = install_managed_esde_from_archive(
            app_root=self.root, archive=archive, source_url="https://example.invalid/esde.zip", version="test", log=lambda _: None
        )
        self.assertTrue(installed.is_file())
        self.assertTrue(is_managed_esde(installed, self.root))
        self.assertEqual(managed_esde_executable(self.root), installed)
        external = self.make_esde()
        self.assertTrue(uninstall_managed_esde(self.root))
        self.assertFalse(installed.exists())
        self.assertTrue(external.exists())

    def test_only_two_user_export_presets_remain(self) -> None:
        self.assertEqual(set(EXPORT_PRESETS), {"crystal_fantasy", "console_mode"})

    def test_load_systems_aliases_and_suggestion(self) -> None:
        systems = load_esde_systems(self.make_esde())
        self.assertEqual({s.name for s in systems}, {"arcade", "megadrive", "n64"})
        self.assertEqual(next(s for s in systems if s.name == "megadrive").canonical_id, "genesis")
        self.assertEqual(canonical_system_id("Atari Jaguar"), "jaguar")
        roms = self.root / "N64"; roms.mkdir(); (roms / "Mario.z64").write_bytes(b"rom")
        self.assertEqual(suggest_system(roms, systems).name, "n64")

    def test_metadata_is_standard_gamelist_only(self) -> None:
        metadata = parse_gamelist(self.make_gamelist(self.root / "gamelists"), self.make_system())
        self.assertEqual(len(metadata["games"]), 2)
        by_title = {game["title"]: game for game in metadata["games"]}
        self.assertIn("fighting", by_title["Street Fighter II"]["genre_tags"])
        self.assertIn("rpg", by_title["Phantasy Star IV"]["genre_tags"])
        self.assertEqual(normalized_genre_tags("Racing / Driving"), ["racing"])

    def test_extension_masquerade_handles_mra_without_fake_files(self) -> None:
        arcade = self.make_system("arcade", "Arcade", (".zip", ".7z"))
        roms = self.root / "_Arcade"; roms.mkdir()
        (roms / "Out Run.mra").write_text("<misterromdescription/>", encoding="utf-8")
        (roms / "README.txt").write_text("sidecar", encoding="utf-8")
        self.assertEqual(scan_source_extensions(roms), {".mra": 1})
        adapted, report = extension_compatible_system(roms, arcade)
        self.assertTrue(report.masquerade_active)
        self.assertIn(".mra", adapted.extensions)
        isolated = self.root / "private"
        configs = write_compatibility_system_configs(adapted, isolated, roms)
        self.assertEqual(validate_bridge_rom_visibility(configs, adapted, roms), 1)
        self.assertFalse((roms / "Out Run.zip").exists())

    def test_disc_folders_are_one_game_each_and_gamelist_paths_are_restored(self) -> None:
        psx = self.make_system("psx", "Sony PlayStation", (".chd", ".cue", ".m3u"))
        roms = self.root / "PlayStation"
        (roms / "Final Fantasy VII").mkdir(parents=True)
        (roms / "Final Fantasy VII" / "Disc 1.cue").write_text("FILE disc1.bin BINARY")
        (roms / "Final Fantasy VII" / "Disc 2.cue").write_text("FILE disc2.bin BINARY")
        (roms / "Metal Gear Solid").mkdir()
        (roms / "Metal Gear Solid" / "Metal Gear Solid.chd").write_bytes(b"disc")
        (roms / "Documentation").mkdir()
        (roms / "Documentation" / "README.txt").write_text("not a game")
        (roms / "Ridge Racer.chd").write_bytes(b"disc")

        adapted, _ = extension_compatible_system(roms, psx)
        self.assertEqual([p.name for p in discover_folder_games(roms, adapted)], ["Final Fantasy VII", "Metal Gear Solid"])
        self.assertEqual(count_game_entries(roms, adapted), 3)

        catalog = self.root / "catalog"
        catalog_system, path_map, count = build_folder_game_catalog(roms, catalog, adapted)
        self.assertEqual(count, 3)
        self.assertIn(".crystalfolder", catalog_system.extensions)
        self.assertTrue((catalog / "Final Fantasy VII.crystalfolder").is_file())
        self.assertTrue((catalog / "Metal Gear Solid.crystalfolder").is_file())
        self.assertTrue((catalog / "Ridge Racer.chd").is_file())
        self.assertTrue((roms / "Final Fantasy VII" / "Disc 1.cue").is_file())

        isolated = self.root / "private-folder-games"
        configs = write_compatibility_system_configs(catalog_system, isolated, catalog)
        self.assertEqual(validate_bridge_rom_visibility(configs, catalog_system, catalog), 3)

        source_gamelist = self.root / "private-gamelist.xml"
        source_gamelist.write_text(
            "<?xml version='1.0'?><gameList>"
            "<game><path>./Final Fantasy VII.crystalfolder</path><name>Final Fantasy VII</name></game>"
            "<game><path>./Ridge Racer.chd</path><name>Ridge Racer</name></game>"
            "</gameList>", encoding="utf-8"
        )
        exported = self.root / "gamelist.xml"
        rewrite_gamelist_paths(source_gamelist, exported, path_map)
        root = __import__('xml.etree.ElementTree', fromlist=['ElementTree']).parse(exported).getroot()
        paths = [node.findtext('path') for node in root.findall('game')]
        self.assertEqual(paths, ['./Final Fantasy VII', './Ridge Racer.chd'])

    def test_multi_system_private_config(self) -> None:
        genesis = self.make_system()
        arcade = self.make_system("arcade", "Arcade", (".zip", ".mra"))
        g = self.root / "Genesis"; a = self.root / "Arcade"; g.mkdir(); a.mkdir()
        (g / "Sonic.bin").write_bytes(b"rom"); (a / "Out Run.mra").write_text("x")
        isolated = self.root / "multi"
        configs = write_multi_compatibility_system_configs(((genesis, g), (arcade, a)), isolated)
        counts = validate_multi_bridge_rom_visibility(configs, ((genesis, g), (arcade, a)))
        self.assertEqual(counts, {"megadrive": 1, "arcade": 1})
        for config in configs:
            text = config.read_text(encoding="utf-8")
            self.assertIn(str(g.absolute().as_posix()), text)
            self.assertIn(str(a.absolute().as_posix()), text)
            self.assertEqual(text.count("<system>"), 2)

    def test_private_settings_include_credentials_media_and_immediate_gamelists(self) -> None:
        isolated = self.root / "private"
        scrape = ScrapeOptions(
            use_screenscraper_account=True, username="hero", password="secret", remember_password=False,
            ratings=False, media_types=("screenshots", "covers", "physicalmedia"), region="jp", language="ja", overwrite=True,
        )
        paths = configure_esde_scraper_profiles(isolated, scrape, isolated / "ROMs")
        settings = read_private_esde_settings(paths[0])
        self.assertEqual(settings["ScraperUsernameScreenScraper"], "hero")
        self.assertEqual(settings["ScraperPasswordScreenScraper"], "secret")
        self.assertEqual(settings["SaveGamelistsMode"], "always")
        self.assertEqual(settings["ScraperRegion"], "jp")
        self.assertFalse(settings["ScraperRegionFallback"])
        self.assertFalse(settings["ScraperSearchMetadataName"])
        self.assertTrue(settings["ScrapeScreenshots"])
        self.assertFalse(settings["ScrapeVideos"])
        # Current ES-DE writes flat setting nodes; the bridge now matches that exact format.
        self.assertNotIn("<settings>", paths[0].read_text(encoding="utf-8"))
        scrub_screenscraper_password(isolated)
        self.assertEqual(read_private_esde_settings(paths[0])["ScraperPasswordScreenScraper"], "")

    def test_region_lock_rejects_european_default_and_accepts_selected_region(self) -> None:
        isolated = self.root / "region-lock"
        paths = configure_esde_scraper_profiles(
            isolated, ScrapeOptions(region="us", language="en"), isolated / "ROMs"
        )
        canonical = paths[0]
        validate_private_scraper_region(canonical, "us")

        class RunningProcess:
            def poll(self): return None
            def terminate(self): pass
            def wait(self, timeout=None): return 0
            def kill(self): pass

        initial = canonical.stat().st_mtime_ns - 1
        wait_for_esde_region_handshake(RunningProcess(), canonical, "us", initial, timeout=0.2)
        text = canonical.read_text(encoding="utf-8").replace(
            'name="ScraperRegion" value="us"', 'name="ScraperRegion" value="eu"'
        )
        canonical.write_text(text, encoding="utf-8")
        with self.assertRaises(RuntimeError):
            validate_private_scraper_region(canonical, "us")

    def test_cfv_and_cfa_headers_remain_locked(self) -> None:
        frames = []
        for i in range(3):
            frame = self.root / f"frame-{i}.jpg"; frame.write_bytes(b"\xff\xd8" + bytes([i + 1]) * 100 + b"\xff\xd9"); frames.append(frame)
        cfv = self.root / "test.cfv"; pack_cfv_jpeg_frames(frames, cfv)
        values = struct.unpack("<12I", cfv.read_bytes()[:48])
        self.assertEqual(values[3:8], (160, 120, 15, 1, 3))
        pcm = self.root / "test.pcm"; pcm.write_bytes(b"\x00\x00" * 140)
        cfa = self.root / "test.cfa"; write_cfa(pcm, cfa)
        self.assertEqual(struct.unpack("<5I", cfa.read_bytes()[:20]), (0x31414643, 1, 14000, 1, 140))

    def test_crystal_package_forces_all_artwork_to_png(self) -> None:
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg: self.skipTest("ffmpeg not available")
        scraped = self.root / "scraped"
        self.generate_image(scraped / "covers" / "Street Fighter II", "blue", ".jpg")
        self.generate_image(scraped / "screenshots" / "Street Fighter II", "red", ".webp")
        self.generate_image(scraped / "physicalmedia" / "Street Fighter II", "green", ".png")
        gamelist = self.make_gamelist(self.root / "gamelists", ("Street Fighter II",))
        result = build_crt_fantasy_package(
            system=self.make_system(), rom_folder=self.root / "roms", output_parent=self.root / "output",
            scraped_root=scraped, gamelist_source=gamelist, ffmpeg=Path(ffmpeg),
            options=PackageOptions(export_format="crystal_fantasy", selected_media=("covers", "screenshots", "physicalmedia")),
        )
        images = [p for p in (result.package_root / "media").rglob("*") if p.is_file() and p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}]
        self.assertTrue(images)
        self.assertTrue(all(path.suffix.lower() == ".png" for path in images))
        self.assertTrue((result.package_root / "media" / "gamelist.xml").is_file())
        self.assertTrue((result.package_root / "media" / "Street Fighter II.png").is_file())
        self.assertFalse((result.package_root / "media" / "covers").exists())
        self.assertFalse(any("Metadata" in p.name for p in result.package_root.rglob("*")))


    def test_png8_compression_is_indexed_capped_and_size_targeted(self) -> None:
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg: self.skipTest("ffmpeg not available")
        source = self.root / "large-source.png"
        subprocess.run([
            ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
            "-f", "lavfi", "-i", "testsrc2=s=1280x720:d=0.1",
            "-frames:v", "1", str(source),
        ], check=True)
        output = self.root / "Same Filename.png"
        convert_image_with_ffmpeg(Path(ffmpeg), source, output, False, optimize=True)
        data = output.read_bytes()
        self.assertEqual(output.name, "Same Filename.png")
        self.assertEqual(data[:8], b"\x89PNG\r\n\x1a\n")
        width, height = struct.unpack(">II", data[16:24])
        self.assertLessEqual(height, 340)
        self.assertEqual(data[25], 3)  # PNG indexed-colour type
        self.assertLessEqual(output.stat().st_size, 64 * 1024)

    def test_console_mode_uses_exact_png_names(self) -> None:
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg: self.skipTest("ffmpeg not available")
        scraped = self.root / "scraped"
        self.generate_image(scraped / "covers" / "Street Fighter II", "blue", ".jpg")
        self.generate_image(scraped / "screenshots" / "Street Fighter II", "red", ".jpg")
        result = build_console_mode_package(
            system=self.make_system(), output_parent=self.root / "output", scraped_root=scraped,
            gamelist_source=self.make_gamelist(self.root / "gamelists", ("Street Fighter II",)),
            ffmpeg=Path(ffmpeg), selected_media=("covers", "screenshots"), log=lambda _: None,
            stage=lambda *_: None, progress=lambda *_: None,
        )
        self.assertTrue((result.package_root / "media" / "Street Fighter II.png").is_file())
        self.assertTrue((result.package_root / "media" / "Street Fighter II-BG.png").is_file())
        self.assertTrue((result.package_root / "media" / "gamelist.xml").is_file())
        self.assertEqual(result.copied_gamelist, result.package_root / "media" / "gamelist.xml")

    def test_recommended_profile_includes_manuals(self) -> None:
        self.assertIn("manuals", CRYSTAL_RECOMMENDED_MEDIA)
        self.assertNotIn("marquees", CRYSTAL_RECOMMENDED_MEDIA)
        self.assertIn("backcovers", CRYSTAL_RECOMMENDED_MEDIA)

    def test_console_live_sync_always_keeps_gamelist(self) -> None:
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg: self.skipTest("ffmpeg not available")
        isolated = self.root / "isolated-console"
        media, gamelist = self.make_scrape_layout(isolated)
        self.generate_image(media / "covers" / "Street Fighter II", "blue", ".jpg")
        self.make_gamelist(gamelist.parent, ("Street Fighter II",))
        roms = self.root / "console-roms"; roms.mkdir()
        mirror = LiveSystemMirror(
            job=SystemJob(roms, self.make_system(), roms), isolated_home=isolated,
            state_root=self.root / "console-state", ffmpeg=Path(ffmpeg),
            options=PackageOptions(export_format="console_mode", selected_media=("covers",)),
        )
        mirror.sync_once(force=True)
        self.assertTrue((roms / "media" / "gamelist.xml").is_file())
        self.assertTrue(mirror.gamelist_synced)

    def test_live_sync_converts_and_replaces_rescraped_image(self) -> None:
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg: self.skipTest("ffmpeg not available")
        isolated = self.root / "isolated"
        media, gamelist = self.make_scrape_layout(isolated)
        source = self.generate_image(media / "covers" / "Street Fighter II", "blue", ".jpg")
        self.make_gamelist(gamelist.parent, ("Street Fighter II",))
        roms = self.root / "roms"; roms.mkdir()
        mirror = LiveSystemMirror(
            job=SystemJob(roms, self.make_system(), roms), isolated_home=isolated,
            state_root=self.root / "state", ffmpeg=Path(ffmpeg),
            options=PackageOptions(export_format="crystal_fantasy", selected_media=("covers",), optimize_images=True),
        )
        mirror.sync_once(force=True)
        destination = roms / "media" / "Street Fighter II.png"
        self.assertTrue(destination.is_file())
        first_hash = hashlib.sha256(destination.read_bytes()).hexdigest()
        self.generate_image(media / "covers" / "Street Fighter II", "red", ".jpg")
        mirror.sync_once(force=True)
        second_hash = hashlib.sha256(destination.read_bytes()).hexdigest()
        self.assertNotEqual(first_hash, second_hash)
        self.assertTrue((roms / "media" / "gamelist.xml").is_file())
        self.assertTrue(source.is_file())

    def test_live_sync_backs_up_preexisting_output_before_first_overwrite(self) -> None:
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg: self.skipTest("ffmpeg not available")
        isolated = self.root / "isolated"
        media, _ = self.make_scrape_layout(isolated)
        self.generate_image(media / "covers" / "Sonic", "blue", ".jpg")
        roms = self.root / "roms"; (roms / "media").mkdir(parents=True)
        existing = roms / "media" / "Sonic.png"
        existing.write_bytes(b"original-user-file")
        state_root = self.root / "state"
        mirror = LiveSystemMirror(
            job=SystemJob(roms, self.make_system(), roms), isolated_home=isolated,
            state_root=state_root, ffmpeg=Path(ffmpeg),
            options=PackageOptions(export_format="crystal_fantasy", selected_media=("covers",)),
        )
        mirror.sync_once(force=True)
        backups = list((state_root.parent / "SafetyBackups").rglob("Sonic.png"))
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_bytes(), b"original-user-file")
        self.assertNotEqual(existing.read_bytes(), b"original-user-file")

    def test_live_sync_stability_gate_waits_one_poll(self) -> None:
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg: self.skipTest("ffmpeg not available")
        isolated = self.root / "isolated"
        media, _ = self.make_scrape_layout(isolated)
        self.generate_image(media / "covers" / "Sonic", "blue", ".jpg")
        roms = self.root / "roms"; roms.mkdir()
        mirror = LiveSystemMirror(
            job=SystemJob(roms, self.make_system(), roms), isolated_home=isolated,
            state_root=self.root / "state", ffmpeg=Path(ffmpeg),
            options=PackageOptions(export_format="crystal_fantasy", selected_media=("covers",)),
        )
        mirror.sync_once(force=False)
        self.assertFalse((roms / "media" / "Sonic.png").exists())
        mirror.sync_once(force=False)
        self.assertTrue((roms / "media" / "Sonic.png").is_file())

    def test_success_cleanup_deletes_complete_private_esde_home_only(self) -> None:
        data_root = self.root / "appdata"
        isolated = data_root / "IsolatedHome"
        downloaded = isolated / "ES-DE" / "downloaded_media" / "arcade" / "videos" / "Out Run.mp4"
        downloaded.parent.mkdir(parents=True)
        downloaded.write_bytes(b"large-original-media")
        gamelist = isolated / "ES-DE" / "gamelists" / "arcade" / "gamelist.xml"
        gamelist.parent.mkdir(parents=True)
        gamelist.write_text("<gameList/>", encoding="utf-8")
        (isolated / "ES-DE" / "es_log.txt").write_text("private log", encoding="utf-8")

        preferences = data_root / "preferences.json"
        preferences.write_text("{}", encoding="utf-8")
        managed_tool = data_root / "Tools" / "FFmpeg" / "ffmpeg.exe"
        managed_tool.parent.mkdir(parents=True)
        managed_tool.write_bytes(b"managed")
        safety = data_root / "SafetyBackups" / "abc" / "Old.png"
        safety.parent.mkdir(parents=True)
        safety.write_bytes(b"backup")

        released = purge_private_esde_home(isolated, data_root)

        self.assertGreater(released, 0)
        self.assertTrue(isolated.is_dir())
        self.assertEqual(list(isolated.iterdir()), [])
        self.assertTrue(preferences.is_file())
        self.assertTrue(managed_tool.is_file())
        self.assertTrue(safety.is_file())

    def test_unresolved_conversion_failure_blocks_disposable_cleanup(self) -> None:
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            self.skipTest("ffmpeg not available")
        isolated = self.root / "isolated"
        media, _ = self.make_scrape_layout(isolated)
        source = self.generate_image(media / "covers" / "Sonic", "blue", ".jpg")
        roms = self.root / "roms"; roms.mkdir()
        mirror = LiveSystemMirror(
            job=SystemJob(roms, self.make_system(), roms), isolated_home=isolated,
            state_root=self.root / "state", ffmpeg=Path(ffmpeg),
            options=PackageOptions(export_format="crystal_fantasy", selected_media=("covers",)),
        )
        with patch("bridge_core._atomic_png", side_effect=RuntimeError("simulated encoder failure")):
            mirror.sync_once(force=True)
        with self.assertRaisesRegex(RuntimeError, "originals were preserved"):
            mirror.raise_for_unresolved_failures()
        self.assertTrue(source.is_file())
        self.assertTrue(isolated.is_dir())

    def test_managed_ffmpeg_install_verify_and_uninstall_are_private(self) -> None:
        app_root = self.root / "app"; app_root.mkdir()
        archive = self.root / "ffmpeg.zip"
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
            bundle.writestr("ffmpeg-test/bin/ffmpeg.exe", b"fake-ffmpeg")
            bundle.writestr("ffmpeg-test/bin/ffprobe.exe", b"fake-ffprobe")
        checksum = hashlib.sha256(archive.read_bytes()).hexdigest()
        local = self.root / "localappdata"
        with patch.dict("os.environ", {"LOCALAPPDATA": str(local)}):
            installed = install_managed_ffmpeg_from_archive(
                app_root=app_root, archive=archive, expected_sha256=checksum, verify_executable=False,
            )
            self.assertEqual(installed, managed_ffmpeg_executable(app_root))
            self.assertTrue(installed.is_file())
            self.assertTrue(is_managed_ffmpeg(installed, app_root))
            external = self.root / "external" / "ffmpeg.exe"
            external.parent.mkdir(); external.write_bytes(b"external")
            self.assertTrue(uninstall_managed_ffmpeg(app_root))
            self.assertFalse(installed.exists())
            self.assertTrue(external.is_file())

    def test_managed_ffmpeg_rejects_bad_checksum(self) -> None:
        app_root = self.root / "app"; app_root.mkdir()
        archive = self.root / "ffmpeg.zip"
        with zipfile.ZipFile(archive, "w") as bundle:
            bundle.writestr("ffmpeg-test/bin/ffmpeg.exe", b"fake")
        with patch.dict("os.environ", {"LOCALAPPDATA": str(self.root / "local")}):
            with self.assertRaises(RuntimeError):
                install_managed_ffmpeg_from_archive(
                    app_root=app_root, archive=archive, expected_sha256="0" * 64, verify_executable=False,
                )
            self.assertFalse(managed_ffmpeg_executable(app_root).exists())

    def test_safe_delete_refuses_outside_owned_root(self) -> None:
        owned = self.root / "owned"; outside = self.root / "outside"; owned.mkdir(); outside.mkdir()
        with self.assertRaises(RuntimeError): safe_remove_tree(outside, owned)
        self.assertTrue(outside.exists())

    def test_mister_sd_scan_finds_games_arcade_and_0mhz(self) -> None:
        root = self.root / "MiSTer"
        (root / "games" / "NES").mkdir(parents=True)
        (root / "games" / "NES" / "Mario.nes").write_bytes(b"rom")
        (root / "games" / "mame").mkdir()
        (root / "games" / "mame" / "pacman.zip").write_bytes(b"rom")
        (root / "_Arcade").mkdir()
        (root / "_Arcade" / "Out Run.mra").write_text("<mra/>")
        (root / "_DOS Games").mkdir()
        (root / "_DOS Games" / "Doom.mgl").write_text("<mgl/>")
        systems = [
            self.make_system("nes", "Nintendo Entertainment System", (".nes", ".zip")),
            self.make_system("arcade", "Arcade", (".zip", ".7z")),
            self.make_system("dos", "DOS", (".exe", ".bat")),
        ]
        found = discover_mister_system_folders(root, systems)
        by_kind = {candidate.kind: candidate for candidate in found}
        self.assertEqual(by_kind["games"].folder, root / "games" / "NES")
        self.assertEqual(by_kind["arcade"].folder, root / "_Arcade")
        self.assertEqual(by_kind["0mhz"].folder, root / "_DOS Games")
        self.assertTrue(any(candidate.folder.name.lower() == "mame" for candidate in found))

    def test_smart_resume_uses_finished_gamelist_and_media(self) -> None:
        roms = self.root / "Genesis"; roms.mkdir()
        for name in ("Sonic.bin", "Streets of Rage.bin", "Beyond Oasis.bin"):
            (roms / name).write_bytes(b"rom")
        media = roms / "media"; (media / "BG").mkdir(parents=True); (media / "BC").mkdir(); (media / "PM").mkdir()
        (media / "gamelist.xml").write_text(
            "<?xml version='1.0'?><gameList>"
            "<game><path>./Sonic.bin</path><name>Sonic</name></game>"
            "<game><path>./Streets of Rage.bin</path><name>Streets of Rage</name></game>"
            "</gameList>", encoding="utf-8")
        for folder in (media, media / "BG", media / "BC", media / "PM"):
            (folder / "Sonic.png").write_bytes(b"png")
        for folder in (media, media / "BG", media / "PM"):
            (folder / "Streets of Rage.png").write_bytes(b"png")
        options = PackageOptions(
            export_format="crystal_fantasy",
            selected_media=("covers", "screenshots", "backcovers", "physicalmedia"),
        )
        report = analyze_smart_resume(roms, self.make_system(), roms, options)
        self.assertEqual([record.display_stem for record in report.complete], ["Sonic"])
        self.assertEqual([record.display_stem for record in report.incomplete], ["Streets of Rage"])
        self.assertEqual([record.display_stem for record in report.new], ["Beyond Oasis"])

    def test_selective_catalog_and_gamelist_merge_preserve_old_games(self) -> None:
        system = self.make_system()
        roms = self.root / "roms"; roms.mkdir()
        for name in ("Sonic.bin", "Beyond Oasis.bin"):
            (roms / name).write_bytes(b"rom")
        catalog = self.root / "catalog"
        adapted, path_map, count = build_selective_game_catalog(roms, catalog, system, ("Beyond Oasis.bin",))
        self.assertEqual(count, 1)
        self.assertTrue((catalog / "Beyond Oasis.bin").is_file())
        self.assertFalse((catalog / "Sonic.bin").exists())
        old = self.root / "media" / "gamelist.xml"
        old.parent.mkdir(parents=True)
        old.write_text("<?xml version='1.0'?><gameList><game><path>./Sonic.bin</path><name>Sonic</name></game></gameList>", encoding="utf-8")
        fresh = self.root / "fresh.xml"
        fresh.write_text("<?xml version='1.0'?><gameList><game><path>./Beyond Oasis.bin</path><name>Beyond Oasis</name></game></gameList>", encoding="utf-8")
        merge_gamelist_paths(fresh, old, path_map)
        paths = {game.findtext("path") for game in ET.parse(old).getroot().findall("game")}
        self.assertEqual(paths, {"./Sonic.bin", "./Beyond Oasis.bin"})

    def test_default_console_mode_name_replaces_taki_branding(self) -> None:
        self.assertEqual(EXPORT_PRESETS["console_mode"]["title"], "Default Console Mode")

    def test_selective_live_sync_merges_and_never_prunes_old_media(self) -> None:
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            self.skipTest("ffmpeg not available")
        isolated = self.root / "isolated-selective"
        media, gamelist = self.make_scrape_layout(isolated)
        self.generate_image(media / "covers" / "Beyond Oasis", "blue", ".jpg")
        gamelist.parent.mkdir(parents=True, exist_ok=True)
        gamelist.write_text("<?xml version='1.0'?><gameList><game><path>./Beyond Oasis.bin</path><name>Beyond Oasis</name></game></gameList>", encoding="utf-8")
        roms = self.root / "roms-selective"; (roms / "media").mkdir(parents=True)
        old_cover = roms / "media" / "Sonic.png"; old_cover.write_bytes(b"old-cover")
        (roms / "media" / "gamelist.xml").write_text("<?xml version='1.0'?><gameList><game><path>./Sonic.bin</path><name>Sonic</name></game></gameList>", encoding="utf-8")
        job = SystemJob(
            roms, self.make_system(), roms, {}, ("Beyond Oasis.bin",), True, False
        )
        mirror = LiveSystemMirror(
            job=job, isolated_home=isolated, state_root=self.root / "state-selective",
            ffmpeg=Path(ffmpeg), options=PackageOptions(export_format="crystal_fantasy", selected_media=("covers",)),
        )
        mirror.sync_once(force=True, prune=job.prune_outputs)
        self.assertEqual(old_cover.read_bytes(), b"old-cover")
        self.assertTrue((roms / "media" / "Beyond Oasis.png").is_file())
        paths = {game.findtext("path") for game in ET.parse(roms / "media" / "gamelist.xml").getroot().findall("game")}
        self.assertEqual(paths, {"./Sonic.bin", "./Beyond Oasis.bin"})


    def test_mister_media_fat_discovery_never_opens_system_folders(self) -> None:
        systems = [
            SystemEntry("nes", "Nintendo Entertainment System", "%ROMPATH%/NES", (".nes",), "<system/>", "test"),
            SystemEntry("playstation", "Sony PlayStation", "%ROMPATH%/psx", (".chd",), "<system/>", "test"),
            SystemEntry("arcade", "Arcade", "%ROMPATH%/arcade", (".zip",), "<system/>", "test"),
            SystemEntry("dos", "DOS", "%ROMPATH%/dos", (".mgl",), "<system/>", "test"),
        ]
        root = self.root / "mounted"
        fat = root / "media" / "fat"
        (fat / "games" / "NES").mkdir(parents=True)
        (fat / "games" / "PSX").mkdir(parents=True)
        (fat / "_Arcade").mkdir()
        (fat / "_DOS Games").mkdir()
        with patch("bridge_core.has_likely_game_content", side_effect=AssertionError("discovery must not inspect ROM contents")), \
             patch("bridge_core.suggest_system", side_effect=AssertionError("discovery must not extension-scan folders")), \
             patch.object(Path, "rglob", side_effect=AssertionError("discovery must not recurse")):
            found = discover_mister_system_folders(root, systems)
        paths = {candidate.folder for candidate in found}
        self.assertEqual(paths, {fat / "games" / "NES", fat / "games" / "PSX", fat / "_Arcade", fat / "_DOS Games"})

    def test_mister_discovery_is_shallow_and_reports_progress(self) -> None:
        systems = [
            SystemEntry("nes", "Nintendo Entertainment System", "%ROMPATH%/NES", (".nes",), "<system/>", "test"),
            SystemEntry("arcade", "Arcade", "%ROMPATH%/arcade", (".zip",), "<system/>", "test"),
            SystemEntry("dos", "DOS", "%ROMPATH%/dos", (".mgl",), "<system/>", "test"),
        ]
        root = self.root / "sd"; (root / "games" / "NES").mkdir(parents=True)
        (root / "games" / "NES" / "Mario.nes").write_bytes(b"rom")
        (root / "_Arcade").mkdir(); (root / "_Arcade" / "Out Run.mra").write_text("<mra/>")
        progress = []
        with patch("bridge_core.count_game_entries", side_effect=AssertionError("full count must not run during discovery")), \
             patch("bridge_core.extension_compatible_system", side_effect=AssertionError("full extension scan must not run during discovery")):
            found = discover_mister_system_folders(root, systems, progress=lambda current, total, name: progress.append((current, total, name)))
        self.assertEqual({candidate.kind for candidate in found}, {"games", "arcade"})
        self.assertTrue(progress)
        self.assertEqual(progress[-1][0], progress[-1][1])

    def test_named_system_suggestion_does_not_walk_large_tree(self) -> None:
        folder = self.root / "NES"; folder.mkdir()
        system = SystemEntry("nes", "Nintendo Entertainment System", "%ROMPATH%/NES", (".nes",), "<system/>", "test")
        with patch.object(Path, "rglob", side_effect=AssertionError("name match should not recurse")):
            self.assertEqual(suggest_system(folder, [system]), system)

    def test_mister_discovery_returns_all_130_immediate_folders_even_unrecognized(self) -> None:
        systems = [
            SystemEntry("nes", "Nintendo Entertainment System", "%ROMPATH%/NES", (".nes",), "<system/>", "test"),
            SystemEntry("arcade", "Arcade", "%ROMPATH%/arcade", (".zip",), "<system/>", "test"),
            SystemEntry("dos", "DOS", "%ROMPATH%/dos", (".mgl",), "<system/>", "test"),
        ]
        root = self.root / "mounted"
        games = root / "media" / "fat" / "games"
        for index in range(130):
            (games / f"MiSTer Folder {index:03d}").mkdir(parents=True)
        found = discover_mister_system_folders(root, systems)
        game_folders = [candidate for candidate in found if candidate.kind == "games"]
        self.assertEqual(len(game_folders), 130)
        self.assertEqual({candidate.folder.name for candidate in game_folders}, {f"MiSTer Folder {index:03d}" for index in range(130)})
        self.assertTrue(all(candidate.system is None for candidate in game_folders))

    def test_mister_discovery_does_not_hide_previously_ignored_folder_names(self) -> None:
        root = self.root / "mounted"
        games = root / "media" / "fat" / "games"
        for name in ("mame", "media", "BIOS", "Something Totally New"):
            (games / name).mkdir(parents=True)
        found = discover_mister_system_folders(root, [])
        self.assertEqual({candidate.folder.name for candidate in found if candidate.kind == "games"}, {"mame", "media", "BIOS", "Something Totally New"})

    def test_easy_mode_exposes_explicit_wrong_guess_control(self) -> None:
        source = (Path(__file__).parents[1] / "CRysTal_Fantasy_Scraper.pyw").read_text(encoding="utf-8")
        self.assertIn("Wrong guess? Choose manually", source)
        self.assertIn("def _choose_easy_system_manually", source)

    def test_mister_registry_maps_psx_directly_to_esde_psx(self) -> None:
        psx = SystemEntry(
            "psx", "Sony PlayStation", "%ROMPATH%/psx", (".chd",),
            "<system><platform>psx</platform></system>", "test",
        )
        rule, match, note = resolve_mister_folder_system("PSX", [psx])
        self.assertIsNotNone(rule)
        self.assertEqual(rule.display_name, "Sony PlayStation")
        self.assertEqual(match, psx)
        self.assertEqual(note, "")

    def test_mister_registry_knows_broad_official_folder_aliases(self) -> None:
        expected = {
            "psx": "Sony PlayStation",
            "megacd": "Sega CD / Mega-CD",
            "tgfx16cd": "PC Engine CD / TurboGrafx-CD",
            "ao486": "DOS / IBM PC",
            "sufami": "Super Nintendo Entertainment System",
            "atarilynx": "Atari Lynx",
            "x68000": "Sharp X68000",
            "acornatom": "Acorn Atom",
        }
        self.assertGreaterEqual(len(MISTER_FOLDER_REGISTRY), 180)
        for token, display_name in expected.items():
            self.assertIn(token, MISTER_FOLDER_REGISTRY)
            self.assertEqual(MISTER_FOLDER_REGISTRY[token].display_name, display_name)

    def test_mister_registry_marks_support_folders_as_not_scrapeable(self) -> None:
        rule, match, note = resolve_mister_folder_system("BIOS", [])
        self.assertIsNotNone(rule)
        self.assertFalse(rule.scrapeable)
        self.assertIsNone(match)
        self.assertIn("not a game library", note)

    def test_mister_discovery_maps_psx_without_opening_folder(self) -> None:
        root = self.root / "mounted-registry"
        psx_folder = root / "media" / "fat" / "games" / "PSX"
        psx_folder.mkdir(parents=True)
        psx = SystemEntry(
            "psx", "Sony PlayStation", "%ROMPATH%/psx", (".chd",),
            "<system><platform>psx</platform></system>", "test",
        )
        with patch.object(Path, "rglob", side_effect=AssertionError("registry mapping must not inspect ROMs")):
            found = discover_mister_system_folders(root, [psx])
        candidate = next(item for item in found if item.folder == psx_folder)
        self.assertEqual(candidate.system, psx)
        self.assertEqual(candidate.known_platform, "Sony PlayStation")
        self.assertTrue(candidate.scrapeable)



if __name__ == "__main__":
    unittest.main()
